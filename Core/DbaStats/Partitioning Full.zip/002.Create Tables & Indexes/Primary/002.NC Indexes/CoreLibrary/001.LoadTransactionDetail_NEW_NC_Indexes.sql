USE [CoreLibrary]
GO

SET ANSI_PADDING ON
GO

CREATE NONCLUSTERED INDEX [IDX_LoadTransactionDetail_AccountNumber] ON [dbo].[LoadTransactionDetail_New]
(
	[AccountNumber] ASC
)
INCLUDE([CMTTRANTYPE],[Reversed],[PostTime],[TranTime],[MemoIndicator],[TxnSource],[TransactionCurrencyCode],[TransactionAmount]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CL]([RowCreatedDate])
GO


CREATE NONCLUSTERED INDEX [Idx_LoadTransactionDetail_TranId] ON [dbo].[LoadTransactionDetail_New]
(
	[TranId] ASC
)
INCLUDE([Reversed]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CL]([RowCreatedDate])
GO