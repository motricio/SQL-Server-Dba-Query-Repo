USE [CoreIssue]
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [dbbidx_IX_Auth_Primary_AccountNumber]    Script Date: 5/6/2024 8:06:31 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_Auth_Primary_AccountNumber] ON [dbo].[Auth_Primary_New]
(
	[AccountNumber] ASC
)
INCLUDE([AuthStatus],[OutstandingAmount],[TranId],[TransactionAmount]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [dbbidx_IX_Auth_Primary_AuthStatus]    Script Date: 5/6/2024 8:06:31 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_Auth_Primary_AuthStatus] ON [dbo].[Auth_Primary_New]
(
	[AuthStatus] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

/****** Object:  Index [dbbidx_IX_Auth_Primary_BatchAcctId]    Script Date: 5/6/2024 8:06:31 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_Auth_Primary_BatchAcctId] ON [dbo].[Auth_Primary_New]
(
	[BatchAcctId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

/****** Object:  Index [dbbidx_IX_Auth_Primary_CoreAuthTranId]    Script Date: 5/6/2024 8:06:31 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_Auth_Primary_CoreAuthTranId] ON [dbo].[Auth_Primary_New]
(
	[CoreAuthTranId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [dbbidx_IX_Auth_Primary_CT_PAN_MTI_AS_TT]    Script Date: 5/6/2024 8:06:31 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_Auth_Primary_CT_PAN_MTI_AS_TT] ON [dbo].[Auth_Primary_New]
(
	[PrimaryAccountNumber] ASC,
	[MessageTypeIdentifier] ASC,
	[AuthStatus] ASC,
	[TranTime] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [dbbidx_IX_Auth_Primary_CT_TDT_STAN_TI_MTI]    Script Date: 5/6/2024 8:06:32 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_Auth_Primary_CT_TDT_STAN_TI_MTI] ON [dbo].[Auth_Primary_New]
(
	[TransmissionDateTime] ASC,
	[SystemTraceAuditNumber] ASC,
	[TranId] ASC,
	[MessageTypeIdentifier] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

/****** Object:  Index [dbbidx_IX_Auth_Primary_DateLocalTransaction]    Script Date: 5/6/2024 8:06:32 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_Auth_Primary_DateLocalTransaction] ON [dbo].[Auth_Primary_New]
(
	[PAN_Hash] ASC,
	[DateLocalTransaction] DESC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [dbbidx_IX_Auth_Primary_MessageTypeIdentifier]    Script Date: 5/6/2024 8:06:32 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_Auth_Primary_MessageTypeIdentifier] ON [dbo].[Auth_Primary_New]
(
	[MessageTypeIdentifier] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [dbbidx_IX_Auth_Primary_PostingFlag]    Script Date: 5/6/2024 8:06:32 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_Auth_Primary_PostingFlag] ON [dbo].[Auth_Primary_New]
(
	[PostingFlag] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

/****** Object:  Index [dbbidx_IX_Auth_Primary_PostTime]    Script Date: 5/6/2024 8:06:32 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_Auth_Primary_PostTime] ON [dbo].[Auth_Primary_New]
(
	[PostTime] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [dbbidx_IX_Auth_Primary_RetrievalReferenceNumber]    Script Date: 5/6/2024 8:06:32 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_Auth_Primary_RetrievalReferenceNumber] ON [dbo].[Auth_Primary_New]
(
	[RetrievalReferenceNumber] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

/****** Object:  Index [dbbidx_IX_Auth_Primary_RevTgt]    Script Date: 5/6/2024 8:06:32 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_Auth_Primary_RevTgt] ON [dbo].[Auth_Primary_New]
(
	[RevTgt] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [dbbidx_IX_Auth_Primary_StateStatus]    Script Date: 5/6/2024 8:06:32 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_Auth_Primary_StateStatus] ON [dbo].[Auth_Primary_New]
(
	[StateStatus] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [dbbidx_IX_Auth_Primary_SystemTraceAuditNumber]    Script Date: 5/6/2024 8:06:32 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_Auth_Primary_SystemTraceAuditNumber] ON [dbo].[Auth_Primary_New]
(
	[SystemTraceAuditNumber] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

/****** Object:  Index [dbbidx_IX_Auth_Primary_TransmissionDateTime]    Script Date: 5/6/2024 8:06:32 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_Auth_Primary_TransmissionDateTime] ON [dbo].[Auth_Primary_New]
(
	[TransmissionDateTime] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

/****** Object:  Index [dbbidx_IX_Auth_Primary_TranTime]    Script Date: 5/6/2024 8:06:32 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_Auth_Primary_TranTime] ON [dbo].[Auth_Primary_New]
(
	[TranTime] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

/****** Object:  Index [dbbidx_IX_Auth_Primary_TxnAcctId]    Script Date: 5/6/2024 8:06:32 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_Auth_Primary_TxnAcctId] ON [dbo].[Auth_Primary_New]
(
	[TxnAcctId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [dbbidx_IX_Auth_UniqueID]    Script Date: 5/6/2024 8:06:32 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_Auth_UniqueID] ON [dbo].[Auth_Primary_New]
(
	[UniqueID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

/****** Object:  Index [dbbidx_IX_TxnLifeCycleUniqueID]    Script Date: 5/6/2024 8:06:32 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_TxnLifeCycleUniqueID] ON [dbo].[Auth_Primary_New]
(
	[TransactionLifeCycleUniqueID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [dbbidx_pan_auth_primary]    Script Date: 5/6/2024 8:06:32 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_pan_auth_primary] ON [dbo].[Auth_Primary_New]
(
	[PrimaryAccountNumber] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

/****** Object:  Index [dbbidx_panhash_auth_primary]    Script Date: 5/6/2024 8:06:32 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_panhash_auth_primary] ON [dbo].[Auth_Primary_New]
(
	[PAN_Hash] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

/****** Object:  Index [dbx_Auth_Primary_TranID]    Script Date: 5/6/2024 8:06:32 PM ******/
CREATE NONCLUSTERED INDEX [dbx_Auth_Primary_TranID] ON [dbo].[Auth_Primary_New]
(
	[TranId] ASC
)
INCLUDE([TimeLocalTransaction],[DateLocalTransaction],[SKey],[AuthStatus],[TransactionAmount],[ResponseCode],[TxnSrcAmt],[IResponseCode],[OutstandingAmount],[CardAcceptorIdCode],[MerchantNameandAddress],[CustomAcctID]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

/****** Object:  Index [idx_AP_txnacctid_PostTime_tranid]    Script Date: 5/6/2024 8:06:33 PM ******/
CREATE NONCLUSTERED INDEX [idx_AP_txnacctid_PostTime_tranid] ON [dbo].[Auth_Primary_New]
(
	[TxnAcctId] ASC,
	[PostTime] ASC,
	[TranId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [idx_Auth_Primary_AStatusTxnTimeTxnSrc]    Script Date: 5/6/2024 8:06:33 PM ******/
CREATE NONCLUSTERED INDEX [idx_Auth_Primary_AStatusTxnTimeTxnSrc] ON [dbo].[Auth_Primary_New]
(
	[TranTime] ASC,
	[TxnSource] ASC,
	[AuthStatus] ASC,
	[ReconciliationIndicator] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [IDX_DBA_Perf6]    Script Date: 5/6/2024 8:06:33 PM ******/
CREATE NONCLUSTERED INDEX [IDX_DBA_Perf6] ON [dbo].[Auth_Primary_New]
(
	[AccountNumber] ASC,
	[CMTTRANTYPE] ASC,
	[AuthStatus] ASC,
	[TxnCategory] ASC
)
INCLUDE([TranId],[TranTime],[PostTime],[TxnCode_Internal],[TxnSource],[TransactionAmount],[TransmissionDateTime],[TimeLocalTransaction],[MerchantType],[CardAcceptorNameLocation],[TxnSrcAmt],[POSCountryCode],[CoreAuthTranId],[OutstandingAmount],[CardAcceptorIdCode],[MerchantNameandAddress],[SKey]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [Ix_Auth_Primary_TxnSource_CmtTrantype]    Script Date: 5/6/2024 8:06:33 PM ******/
CREATE NONCLUSTERED INDEX [Ix_Auth_Primary_TxnSource_CmtTrantype] ON [dbo].[Auth_Primary_New]
(
	[TranId] ASC,
	[TxnSource] ASC,
	[CMTTRANTYPE] ASC,
	[InstitutionID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

/****** Object:  Index [RD_NC_Auth_Primary_TranId]    Script Date: 5/6/2024 8:06:33 PM ******/
CREATE NONCLUSTERED INDEX [RD_NC_Auth_Primary_TranId] ON [dbo].[Auth_Primary_New]
(
	[TranId] ASC
)
INCLUDE([MerchantNameandAddress]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [RD_NC_auth_primary_Tranid_Proccode_MerchantType]    Script Date: 5/6/2024 8:06:33 PM ******/
CREATE NONCLUSTERED INDEX [RD_NC_auth_primary_Tranid_Proccode_MerchantType] ON [dbo].[Auth_Primary_New]
(
	[TranId] ASC,
	[ProcCode] ASC,
	[MerchantType] ASC
)
INCLUDE([PINExist]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [RD_NC_Auth_Primary_TxnSource]    Script Date: 5/6/2024 8:06:34 PM ******/
CREATE NONCLUSTERED INDEX [RD_NC_Auth_Primary_TxnSource] ON [dbo].[Auth_Primary_New]
(
	[TxnSource] ASC
)
INCLUDE([TranId],[PostTime],[ProcCode],[MerchantType],[DateLocalTransaction],[AuthStatus],[ReconciliationIndicator],[MessageTypeIdentifier]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

/****** Object:  Index [RD_NC_AuthPrimary_InsPosttime]    Script Date: 5/6/2024 8:06:34 PM ******/
CREATE NONCLUSTERED INDEX [RD_NC_AuthPrimary_InsPosttime] ON [dbo].[Auth_Primary_New]
(
	[InstitutionID] ASC,
	[PostTime] ASC
)
INCLUDE([TranId],[CMTTRANTYPE],[AccountNumber],[AuthStatus],[PrimaryAccountNumber],[ProcCode],[TransactionAmount],[MerchantType],[AuthorizationResponseCode],[ResponseCode],[TransactionCurrencyCode],[ApprovalCode],[POSCountryCode],[AcquiringInstCountryCode],[TxnCategory],[CoreAuthTranId],[MessageTypeIdentifier],[ProductID],[CardAcceptorIdCode]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

/****** Object:  Index [RD_NC_authPrimary_Tranid]    Script Date: 5/6/2024 8:06:34 PM ******/
CREATE NONCLUSTERED INDEX [RD_NC_authPrimary_Tranid] ON [dbo].[Auth_Primary_New]
(
	[TranId] ASC
)
INCLUDE([CardDataEntryMode],[CMTTRANTYPE],[ApprovalCode],[AuthorizationResponseCode],[TransactionCurrencyCode],[CardAcceptorIdCode]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [RD_NC_authPrimary_TransactionLifeCycleUniqueID]    Script Date: 5/6/2024 8:06:34 PM ******/
CREATE NONCLUSTERED INDEX [RD_NC_authPrimary_TransactionLifeCycleUniqueID] ON [dbo].[Auth_Primary_New]
(
	[TransactionLifeCycleUniqueID] ASC,
	[CMTTRANTYPE] ASC
)
INCLUDE([CardDataEntryMode]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

/****** Object:  Index [UC_AuthPrimaryTranID]    Script Date: 5/6/2024 8:06:34 PM ******/
/*ALTER TABLE [dbo].[Auth_Primary_New] ADD  CONSTRAINT [UC_AuthPrimaryTranID] UNIQUE NONCLUSTERED 
(
	[TranId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO
*/
