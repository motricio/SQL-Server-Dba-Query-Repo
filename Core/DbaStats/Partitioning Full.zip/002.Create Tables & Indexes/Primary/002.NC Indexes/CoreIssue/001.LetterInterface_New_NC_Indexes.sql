USE [CoreIssue]
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [dbbidx_IX_CT_Composite_StatusModule]    Script Date: 5/6/2024 6:50:43 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_CT_Composite_StatusModule] ON [dbo].[LetterInterface_New]
(
	[LetterStatus] ASC,
	[CorecardModule] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([LetterDraftedDate])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [dbbidx_IX_LetterGenAdditionalLetterText]    Script Date: 5/6/2024 6:50:43 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_LetterGenAdditionalLetterText] ON [dbo].[LetterInterface_New]
(
	[AdditionalLetterText] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([LetterDraftedDate])
GO

/****** Object:  Index [dbbidx_IX_LetterGenATID]    Script Date: 5/6/2024 6:50:43 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_LetterGenATID] ON [dbo].[LetterInterface_New]
(
	[ATID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([LetterDraftedDate])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [dbbidx_IX_LetterGenCardNumber]    Script Date: 5/6/2024 6:50:43 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_LetterGenCardNumber] ON [dbo].[LetterInterface_New]
(
	[CardNumber] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([LetterDraftedDate])
GO

/****** Object:  Index [dbbidx_IX_LetterGenCaseNumber]    Script Date: 5/6/2024 6:50:43 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_LetterGenCaseNumber] ON [dbo].[LetterInterface_New]
(
	[CaseNumber] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([LetterDraftedDate])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [dbbidx_IX_LetterGenCorecardModule]    Script Date: 5/6/2024 6:50:44 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_LetterGenCorecardModule] ON [dbo].[LetterInterface_New]
(
	[CorecardModule] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([LetterDraftedDate])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [dbbidx_IX_LetterGenLetterDraftedBy]    Script Date: 5/6/2024 6:50:44 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_LetterGenLetterDraftedBy] ON [dbo].[LetterInterface_New]
(
	[LetterDraftedBy] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([LetterDraftedDate])
GO

/****** Object:  Index [dbbidx_IX_LetterGenLetterDraftedDate]    Script Date: 5/6/2024 6:50:44 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_LetterGenLetterDraftedDate] ON [dbo].[LetterInterface_New]
(
	[LetterDraftedDate] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([LetterDraftedDate])
GO

/****** Object:  Index [dbbidx_IX_LetterGenLetterSentDate]    Script Date: 5/6/2024 6:50:44 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_LetterGenLetterSentDate] ON [dbo].[LetterInterface_New]
(
	[LetterSentDate] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([LetterDraftedDate])
GO

/****** Object:  Index [dbbidx_IX_LetterGenLetterTemplateID]    Script Date: 5/6/2024 6:50:44 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_LetterGenLetterTemplateID] ON [dbo].[LetterInterface_New]
(
	[LetterTemplateID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([LetterDraftedDate])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [dbbidx_IX_LetterGenLetterTemplateIDDesc]    Script Date: 5/6/2024 6:50:44 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_LetterGenLetterTemplateIDDesc] ON [dbo].[LetterInterface_New]
(
	[LetterTemplateIDDesc] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([LetterDraftedDate])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [dbbidx_IX_LetterGenLetterTemplateStatus]    Script Date: 5/6/2024 6:50:44 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_LetterGenLetterTemplateStatus] ON [dbo].[LetterInterface_New]
(
	[LetterTemplateStatus] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([LetterDraftedDate])
GO

/****** Object:  Index [dbbidx_IX_LetterGenLetterTemplateVersion]    Script Date: 5/6/2024 6:50:44 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_LetterGenLetterTemplateVersion] ON [dbo].[LetterInterface_New]
(
	[LetterTemplateVersion] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([LetterDraftedDate])
GO

/****** Object:  Index [dbbidx_IX_LetterGenOutcomeDefId]    Script Date: 5/6/2024 6:50:44 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_LetterGenOutcomeDefId] ON [dbo].[LetterInterface_New]
(
	[LetterOutcomeDefId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([LetterDraftedDate])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [dbbidx_IX_LetterGenQueueName]    Script Date: 5/6/2024 6:50:44 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_LetterGenQueueName] ON [dbo].[LetterInterface_New]
(
	[LetterQueueName] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([LetterDraftedDate])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [idx_LetterInterface_NextDate_Status_MT_Lid_A]    Script Date: 5/6/2024 6:50:44 PM ******/
CREATE NONCLUSTERED INDEX [idx_LetterInterface_NextDate_Status_MT_Lid_A] ON [dbo].[LetterInterface_New]
(
	[LetterStatus] ASC,
	[NextDate] ASC,
	[LetterID] ASC,
	[messageType] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([LetterDraftedDate])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [ix_LetterInterface_AcctNumber]    Script Date: 5/6/2024 6:50:44 PM ******/
CREATE NONCLUSTERED INDEX [ix_LetterInterface_AcctNumber] ON [dbo].[LetterInterface_New]
(
	[AcctNumber] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([LetterDraftedDate])
GO

/****** Object:  Index [ix_LetterInterface_NextDate_LetterID]    Script Date: 5/6/2024 6:50:44 PM ******/
CREATE NONCLUSTERED INDEX [ix_LetterInterface_NextDate_LetterID] ON [dbo].[LetterInterface_New]
(
	[NextDate] ASC,
	[LetterID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([LetterDraftedDate])
GO
