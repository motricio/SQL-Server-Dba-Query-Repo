USE [CoreIssue]
GO

CREATE NONCLUSTERED INDEX [IDX_GLPostingTransactions_AccountNumber] ON [dbo].[GLPostingTransactions_New]
(
	[AccountNumber] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI] ([PostTime])
GO
SET ANSI_PADDING ON
GO

CREATE NONCLUSTERED INDEX [idx_glPostingtransactions_Tid_Tamt_CtType] ON [dbo].[GLPostingTransactions_New]
(
	[TranId] ASC,
	[TransactionAmount] ASC,
	[CMTTRANTYPE] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI] ([PostTime])
GO
SET ANSI_PADDING ON
GO

CREATE NONCLUSTERED INDEX [IDX_GLPostingTransactions_Tranid_TransactionAmount_CMTTrantype] ON [dbo].[GLPostingTransactions_New]
(
	[TranId] ASC,
	[TransactionAmount] ASC,
	[CMTTRANTYPE] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI] ([PostTime])
GO

SET ANSI_PADDING ON
GO

CREATE NONCLUSTERED INDEX [idx_glPostingtransactions_TxnAcctId_Tid_AuthTid] ON [dbo].[GLPostingTransactions_New]
(
	[TxnAcctId] ASC,
	[TranId] ASC,
	[AuthTranId] ASC,
	[MessageTypeIdentifier] ASC,
	[Authstatus] ASC,
	[PostingFlag] ASC
)
INCLUDE([SweepStatus],[TransactionAmount]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI] ([PostTime])
GO
SET ANSI_PADDING ON
GO