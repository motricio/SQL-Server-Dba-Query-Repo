USE [CoreIssue]
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [dbbidx_IX_BaseSegment]    Script Date: 5/6/2024 8:41:41 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_BaseSegment] ON [dbo].[CCard_Primary_NEW]
(
	[AccountNumber] ASC
)
INCLUDE([TranId],[TranTime],[TransactionAmount],[SKey],[CMTTRANTYPE],[Reversed],[SrcIdentifier],[RevTgt],[PostingFlag],[PostTime],[TxnSource],[CustomAcctID],[SpecialMerchantIdentifier]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

/****** Object:  Index [dbbidx_IX_Batchaacctid]    Script Date: 5/6/2024 8:41:42 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_Batchaacctid] ON [dbo].[CCard_Primary_NEW]
(
	[BatchAcctId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [dbbidx_IX_CmtTranType]    Script Date: 5/6/2024 8:41:42 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_CmtTranType] ON [dbo].[CCard_Primary_NEW]
(
	[CMTTRANTYPE] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [dbbidx_IX_CT_Composite_PAN_MTI_AS_TT]    Script Date: 5/6/2024 8:41:42 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_CT_Composite_PAN_MTI_AS_TT] ON [dbo].[CCard_Primary_NEW]
(
	[PrimaryAccountNumber] ASC,
	[MessageTypeIdentifier] ASC,
	[AuthStatus] ASC,
	[TranTime] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [dbbidx_IX_CT_Composite_TDT_STAN_TI_MTI]    Script Date: 5/6/2024 8:41:42 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_CT_Composite_TDT_STAN_TI_MTI] ON [dbo].[CCard_Primary_NEW]
(
	[TransmissionDateTime] ASC,
	[SystemTraceAuditNumber] ASC,
	[TranId] ASC,
	[MessageTypeIdentifier] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

/****** Object:  Index [dbbidx_IX_CT_OriginalPostTime]    Script Date: 5/6/2024 8:41:42 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_CT_OriginalPostTime] ON [dbo].[CCard_Primary_NEW]
(
	[OriginalPostTime] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

/****** Object:  Index [dbbidx_IX_CT_TransactionTime]    Script Date: 5/6/2024 8:41:42 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_CT_TransactionTime] ON [dbo].[CCard_Primary_NEW]
(
	[TranTime] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

/****** Object:  Index [dbbidx_IX_PostTime]    Script Date: 5/6/2024 8:41:42 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_PostTime] ON [dbo].[CCard_Primary_NEW]
(
	[PostTime] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

/****** Object:  Index [dbbidx_IX_Rejectbatchacctid]    Script Date: 5/6/2024 8:41:42 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_Rejectbatchacctid] ON [dbo].[CCard_Primary_NEW]
(
	[RejectBatchAcctId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [dbbidx_IX_RetrievelRefNumber]    Script Date: 5/6/2024 8:41:42 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_RetrievelRefNumber] ON [dbo].[CCard_Primary_NEW]
(
	[RetrievalReferenceNumber] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

/****** Object:  Index [dbbidx_IX_RevTgt]    Script Date: 5/6/2024 8:41:42 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_RevTgt] ON [dbo].[CCard_Primary_NEW]
(
	[RevTgt] ASC
)
INCLUDE([TranId],[CMTTRANTYPE],[PostingFlag]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [dbbidx_IX_SrcIdentifier]    Script Date: 5/6/2024 8:41:42 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_SrcIdentifier] ON [dbo].[CCard_Primary_NEW]
(
	[SrcIdentifier] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [dbbidx_IX_SystemTraceAuditNumber_WH]    Script Date: 5/6/2024 8:41:42 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_SystemTraceAuditNumber_WH] ON [dbo].[CCard_Primary_NEW]
(
	[SystemTraceAuditNumber] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

/****** Object:  Index [dbbidx_IX_TranOrignator]    Script Date: 5/6/2024 8:41:42 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_TranOrignator] ON [dbo].[CCard_Primary_NEW]
(
	[tranorig] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

/****** Object:  Index [dbbidx_IX_TranRef]    Script Date: 5/6/2024 8:41:42 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_TranRef] ON [dbo].[CCard_Primary_NEW]
(
	[TranRef] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

/****** Object:  Index [dbbidx_IX_TransactionAmount]    Script Date: 5/6/2024 8:41:42 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_TransactionAmount] ON [dbo].[CCard_Primary_NEW]
(
	[TransactionAmount] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

/****** Object:  Index [dbbidx_IX_TransmissionDateTime_WH]    Script Date: 5/6/2024 8:41:42 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_TransmissionDateTime_WH] ON [dbo].[CCard_Primary_NEW]
(
	[TransmissionDateTime] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [dbbidx_pan_ccard_primary]    Script Date: 5/6/2024 8:41:42 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_pan_ccard_primary] ON [dbo].[CCard_Primary_NEW]
(
	[PrimaryAccountNumber] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

/****** Object:  Index [dbbidx_panhash_ccard_primary]    Script Date: 5/6/2024 8:41:42 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_panhash_ccard_primary] ON [dbo].[CCard_Primary_NEW]
(
	[PAN_Hash] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

/****** Object:  Index [dbx_CCard_Primary_TranID]    Script Date: 5/6/2024 8:41:42 PM ******/
CREATE NONCLUSTERED INDEX [dbx_CCard_Primary_TranID] ON [dbo].[CCard_Primary_NEW]
(
	[TranId] ASC
)
INCLUDE([TransmissionDateTime],[TranTime],[CMTTRANTYPE],[TransactionAmount],[creditplanmaster],[TxnCode_Internal],[TransactionDescription],[CardAcceptorBusinessCode],[MerchantType],[RetrievalReferenceNumber],[AuthTranId],[SKey]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [idx_CCard_Primary_AcctNo_FileID_TGID]    Script Date: 5/6/2024 8:41:43 PM ******/
CREATE NONCLUSTERED INDEX [idx_CCard_Primary_AcctNo_FileID_TGID] ON [dbo].[CCard_Primary_NEW]
(
	[AccountNumber] ASC,
	[LoadFileID] ASC,
	[TransactionGroupID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

/****** Object:  Index [idx_CCard_Primary_TransactionGroupID]    Script Date: 5/6/2024 8:41:43 PM ******/
CREATE NONCLUSTERED INDEX [idx_CCard_Primary_TransactionGroupID] ON [dbo].[CCard_Primary_NEW]
(
	[TransactionGroupID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

/****** Object:  Index [idx_CCard_Primary_TxnAcctId_ATID]    Script Date: 5/6/2024 8:41:43 PM ******/
CREATE NONCLUSTERED INDEX [idx_CCard_Primary_TxnAcctId_ATID] ON [dbo].[CCard_Primary_NEW]
(
	[TxnAcctId] ASC,
	[ATID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

/****** Object:  Index [IDX_DBA_perf07]    Script Date: 5/6/2024 8:41:43 PM ******/
CREATE NONCLUSTERED INDEX [IDX_DBA_perf07] ON [dbo].[CCard_Primary_NEW]
(
	[TranId] ASC
)
INCLUDE([PostTime],[CMTTRANTYPE],[tranorig],[TransactionAmount],[TransmissionDateTime],[PostingRef],[TxnSource],[TransactionDescription],[MerchantType],[MerchantCity],[MerchantCountryCode],[MerchantStProvCode],[AuthTranId],[Transactionidentifier],[SKey]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [IDX_DBA_Perf3]    Script Date: 5/6/2024 8:41:43 PM ******/
CREATE NONCLUSTERED INDEX [IDX_DBA_Perf3] ON [dbo].[CCard_Primary_NEW]
(
	[CMTTRANTYPE] ASC
)
INCLUDE([TranId],[TransactionAmount],[TxnSource],[InstitutionID],[AuthTranId]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

/****** Object:  Index [ix_CCard_Primary_AuthTranId]    Script Date: 5/6/2024 8:41:43 PM ******/
CREATE NONCLUSTERED INDEX [ix_CCard_Primary_AuthTranId] ON [dbo].[CCard_Primary_NEW]
(
	[AuthTranId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [IX_temp_ccard_Primary_CheckNumber]    Script Date: 5/6/2024 8:41:43 PM ******/
CREATE NONCLUSTERED INDEX [IX_temp_ccard_Primary_CheckNumber] ON [dbo].[CCard_Primary_NEW]
(
	[CheckNumber] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [RD_NC_CCard_Primary_ARTxnType]    Script Date: 5/6/2024 8:41:43 PM ******/
CREATE NONCLUSTERED INDEX [RD_NC_CCard_Primary_ARTxnType] ON [dbo].[CCard_Primary_NEW]
(
	[ARTxnType] ASC
)
INCLUDE([TranId],[TranTime],[TransactionAmount],[AccountNumber],[TxnCode_Internal],[PostingRef],[RejectBatchAcctId],[TxnSource],[TransactionDescription],[SystemTraceAuditNumber],[ProductID],[InstitutionID],[AuthTranId]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

/****** Object:  Index [rd_nc_CCard_Primary_PostTime]    Script Date: 5/6/2024 8:41:43 PM ******/
CREATE NONCLUSTERED INDEX [rd_nc_CCard_Primary_PostTime] ON [dbo].[CCard_Primary_NEW]
(
	[PostTime] ASC
)
INCLUDE([TranId],[AccountNumber],[TxnCode_Internal],[TxnSource],[MerchantType],[ProductID],[InstitutionID]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [RD_NC_CCard_Primary_RejectBatchAcctId_ARTxnType]    Script Date: 5/6/2024 8:41:43 PM ******/
CREATE NONCLUSTERED INDEX [RD_NC_CCard_Primary_RejectBatchAcctId_ARTxnType] ON [dbo].[CCard_Primary_NEW]
(
	[RejectBatchAcctId] ASC,
	[ARTxnType] ASC,
	[InstitutionID] ASC,
	[ProductID] ASC
)
INCLUDE([AccountNumber],[TranId],[TranTime],[TxnCode_Internal],[TransactionAmount],[TransactionDescription],[SystemTraceAuditNumber],[PostingRef],[TxnSource],[AuthTranId]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

/****** Object:  Index [RD_NC_Ccard_Primary_TranID_IncludeTransmissinoDtTxnDesc]    Script Date: 5/6/2024 8:41:43 PM ******/
CREATE NONCLUSTERED INDEX [RD_NC_Ccard_Primary_TranID_IncludeTransmissinoDtTxnDesc] ON [dbo].[CCard_Primary_NEW]
(
	[TranId] ASC
)
INCLUDE([TransmissionDateTime],[TransactionDescription]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

/****** Object:  Index [RD_NC_CCard_Primary_TranId_ProductID]    Script Date: 5/6/2024 8:41:43 PM ******/
CREATE NONCLUSTERED INDEX [RD_NC_CCard_Primary_TranId_ProductID] ON [dbo].[CCard_Primary_NEW]
(
	[TranId] ASC,
	[ProductID] ASC
)
INCLUDE([TransactionDescription],[AuthTranId],[AccountNumber]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [RD_NC_CCard_Primary_TxnSource]    Script Date: 5/6/2024 8:41:44 PM ******/
CREATE NONCLUSTERED INDEX [RD_NC_CCard_Primary_TxnSource] ON [dbo].[CCard_Primary_NEW]
(
	[TxnSource] ASC
)
INCLUDE([TranId],[AccountNumber],[AuthTranId],[TransactionAmount]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [RD_NC_CcardPrima_PIDCMTSKEY]    Script Date: 5/6/2024 8:41:44 PM ******/
CREATE NONCLUSTERED INDEX [RD_NC_CcardPrima_PIDCMTSKEY] ON [dbo].[CCard_Primary_NEW]
(
	[ProductID] ASC,
	[CMTTRANTYPE] ASC,
	[SKey] ASC
)
INCLUDE([TranId],[PostTime],[TranRef],[RevTgt],[tranorig],[TransactionAmount],[NetworkName],[AccountNumber],[TxnCode_Internal],[PostingFlag],[TxnSource],[InstitutionID],[AuthTranId],[CardNumber4Digits]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [RD_NC_CCArdPrimary_CMTTranType_ArTxnType_Include]    Script Date: 5/6/2024 8:41:44 PM ******/
CREATE NONCLUSTERED INDEX [RD_NC_CCArdPrimary_CMTTranType_ArTxnType_Include] ON [dbo].[CCard_Primary_NEW]
(
	[CMTTRANTYPE] ASC,
	[ARTxnType] ASC
)
INCLUDE([PostTime],[AccountNumber]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [RD_NC_CCardPrimary_Posttime_ARTxnType]    Script Date: 5/6/2024 8:41:44 PM ******/
CREATE NONCLUSTERED INDEX [RD_NC_CCardPrimary_Posttime_ARTxnType] ON [dbo].[CCard_Primary_NEW]
(
	[PostTime] ASC,
	[ARTxnType] ASC
)
INCLUDE([TranId],[CMTTRANTYPE],[TransactionAmount],[AccountNumber],[TxnSource],[MerchantType],[ProductID],[InstitutionID]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

/****** Object:  Index [RD_NC_ccardprimary_Tranid_CM]    Script Date: 5/6/2024 8:41:44 PM ******/
CREATE NONCLUSTERED INDEX [RD_NC_ccardprimary_Tranid_CM] ON [dbo].[CCard_Primary_NEW]
(
	[TranId] ASC
)
INCLUDE([TranTime],[PostTime],[PrimaryAccountNumber],[NetworkName],[AccountNumber],[TxnSource],[TransactionCurrencyCode],[MerchantType],[MerchantCity],[MerchantCountryCode],[MerchantStProvCode],[MerchantID],[InterchangeFeeAmount],[AuthTranId],[TransactionLifeCycleUniqueID],[ProductID],[InstitutionID]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

/****** Object:  Index [RD_NC_ccardprimary_Tranid_Include]    Script Date: 5/6/2024 8:41:44 PM ******/
CREATE NONCLUSTERED INDEX [RD_NC_ccardprimary_Tranid_Include] ON [dbo].[CCard_Primary_NEW]
(
	[TranId] ASC
)
INCLUDE([AccountNumber],[TransactionDescription],[ProductID],[AuthTranId]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

/****** Object:  Index [RD_NC_CCArdPrimary_TranID_IncludeAcNoCardNumberTxnSource]    Script Date: 5/6/2024 8:41:44 PM ******/
CREATE NONCLUSTERED INDEX [RD_NC_CCArdPrimary_TranID_IncludeAcNoCardNumberTxnSource] ON [dbo].[CCard_Primary_NEW]
(
	[TranId] ASC
)
INCLUDE([AccountNumber],[CardNumber4Digits],[TxnSource]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO

/****** Object:  Index [UC_CCardTranID]    Script Date: 5/6/2024 8:41:44 PM ******/
/*ALTER TABLE [dbo].[CCard_Primary_NEW] ADD  CONSTRAINT [UC_CCardTranID] UNIQUE NONCLUSTERED 
(
	[TranId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [DataPartitionScheme_PROD_CI]([PostTime])
GO
*/

