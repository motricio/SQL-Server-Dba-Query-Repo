USE [CoreAuth]
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [ix_FraudAuthAccounts_Accountnumber]    Script Date: 5/6/2024 5:31:03 PM ******/
CREATE NONCLUSTERED INDEX [ix_FraudAuthAccounts_Accountnumber] ON [dbo].[FraudAuthAccounts_New]
(
	[AccountNumber] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CA]([AuthTime])
GO

/****** Object:  Index [IX_FraudAuthAccounts_EmbAcctid_AuthTime]    Script Date: 5/6/2024 5:31:04 PM ******/
CREATE NONCLUSTERED INDEX [IX_FraudAuthAccounts_EmbAcctid_AuthTime] ON [dbo].[FraudAuthAccounts_New]
(
	[EmbAcctid] ASC,
	[AuthTime] ASC
)
INCLUDE([TxnCode_Internal],[TranType],[FeeWaiveIndicator]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CA]([AuthTime])
GO

/****** Object:  Index [IX_FraudAuthAccounts_TranId]    Script Date: 5/6/2024 5:31:04 PM ******/
CREATE NONCLUSTERED INDEX [IX_FraudAuthAccounts_TranId] ON [dbo].[FraudAuthAccounts_New]
(
	[TranId] ASC
)
INCLUDE([TxnCode_InternalClr],[ProductID]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CA]([AuthTime])
GO