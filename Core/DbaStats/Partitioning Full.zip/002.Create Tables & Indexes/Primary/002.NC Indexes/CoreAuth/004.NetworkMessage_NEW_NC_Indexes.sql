USE [CoreAuth]
GO

/****** Object:  Index [idx_Cauth_NetworkMsg_TransTime]    Script Date: 5/6/2024 5:42:59 PM ******/
CREATE NONCLUSTERED INDEX [idx_Cauth_NetworkMsg_TransTime] ON [dbo].[NetworkMessage_New]
(
	[TransmissionDateTime] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CA]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [idx_NetworkMessage_STAN_FIIDCode_NMICode]    Script Date: 5/6/2024 5:42:59 PM ******/
CREATE NONCLUSTERED INDEX [idx_NetworkMessage_STAN_FIIDCode_NMICode] ON [dbo].[NetworkMessage_New]
(
	[MessageTypeIdentifier] ASC,
	[TransmissionDateTime] ASC,
	[PhysicalSource] ASC,
	[SystemTraceAuditNumber] ASC,
	[ForwardingInsitutionIDCode] ASC,
	[NetworkMgmtInfoCode] ASC
)
INCLUDE([SecRelControlInfo],[KeyNetworkID],[KCV],[UniqueID]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CA]([PostTime])
GO
