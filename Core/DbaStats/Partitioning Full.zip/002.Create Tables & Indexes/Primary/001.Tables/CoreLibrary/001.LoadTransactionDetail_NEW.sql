USE [CoreLibrary]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[LoadTransactionDetail_New](
	[Skey] [int] IDENTITY(1,1) NOT NULL,
	[TranTime] [datetime] NULL,
	[PostTime] [datetime] NULL,
	[TranId] [decimal](19, 0) NOT NULL, -- Updated as NOT NULL because is part of new PK.
	[TxnAcctId] [int] NULL,
	[ATID] [int] NULL,
	[CMTTRANTYPE] [varchar](9) NULL,
	[TransactionAmount] [money] NULL,
	[AccountNumber] [varchar](19) NULL,
	[PrimaryAccountNumber] [varbinary](100) NULL,
	[PAN_Hash] [int] NULL,
	[PrimaryCurrencyCode] [char](25) NULL,
	[BillingCurrencyCode] [varchar](25) NULL,
	[TransactionCurrencyCode] [varchar](5) NULL,
	[TxnSource] [varchar](4) NULL,
	[SrcIdentifier] [varchar](10) NULL,
	[AdminPortalMobileSharing] [char](9) NULL,
	[Reversed] [int] NULL,
	[RevTGT] [decimal](19, 0) NULL,
	[ProductID] [int] NULL,
	[InstituteID] [int] NULL,
	[ArTxnType] [varchar](4) NULL,
	[ExhangeRate] [money] NULL,
	[MarkupRate] [money] NULL,
	[PostingFlag] [char](2) NULL,
	[PostingRef] [varchar](200) NULL,
	[MemoIndicator] [char](30) NULL,
	[EmbossingAID] [int] NULL,
	[RowChangedDate] DATETIME NOT NULL DEFAULT GETDATE(),
	[ChangeVersion] ROWVERSION NOT NULL,
	[RowCreatedDate] DATETIME NOT NULL DEFAULT GETDATE(),
 CONSTRAINT [csPk_LoadTransactionDetail_New] PRIMARY KEY CLUSTERED 
(
	[TranId] ASC,
	[RowCreatedDate] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CL]([RowCreatedDate])
) ON [DataPartitionScheme_PROD_CL]([RowCreatedDate])
GO