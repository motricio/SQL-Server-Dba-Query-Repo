SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
USE [CoreIssue]
GO
CREATE TABLE [dbo].[GLPostingTransactions_New](
	[Skey] [decimal](19, 0) IDENTITY(1,1) NOT FOR REPLICATION NOT NULL,
	[AccountNumber] [char](19) NULL,
	[BaseAcctid] [int] NULL,
	[WalletAcctID] [int] NULL,
	[TxnAcctId] [int] NULL,
	[TranId] [decimal](19, 0) NULL,  -- Kept original because of PK columns change.
	[AuthTranId] [decimal](19, 0) NULL,
	[TransactionLifeCycleUniqueID] [decimal](19, 0) NULL,
	[GLExternalTranRefNumber] [varchar](30) NULL,
	[PostTime] [datetime] NOT NULL,
	[TransmissionDateTime] [datetime] NOT NULL, -- Updated on scripts sent by Kshitij and tested on PPG Test Env - 2023.
	[SettlementDate] [datetime] NULL,
	[TransactionAmount] [money] NULL,
	[TransactionCurrencyCode] [char](3) NULL,
	[SettlementAmount] [money] NULL,
	[SettlementCurrencyCode] [char](3) NULL,
	[MessageTypeIdentifier] [char](4) NULL,
	[TxnSource] [char](4) NULL,
	[CMTTRANTYPE] [char](8) NULL,
	[MTCGrpName] [int] NULL,
	[TransactionCode] [varchar](20) NULL,
	[ActualTranCode] [char](20) NULL,
	[GLGroupID] [decimal](19, 0) NULL,
	[DebitGL] [decimal](19, 0) NULL,
	[DebitGL_Currency] [char](3) NULL,
	[CreditGL] [decimal](19, 0) NULL,
	[CreditGL_Currency] [char](3) NULL,
	[DebitGL_Settlement] [decimal](19, 0) NULL,
	[DebitGL_Settlement_Currency] [char](3) NULL,
	[CreditGL_Settlement] [decimal](19, 0) NULL,
	[CreditGL_Settlement_Currency] [char](3) NULL,
	[ExchangeRate] [float] NULL,
	[GLProductID] [int] NULL,
	[InstitutionId] [int] NULL,
	[TransactionsLogTime] [datetime] NULL,
	[SweepStatus] [varchar](100) NULL,
	[Reversed] [int] NULL,
	[Authstatus] [char](5) NULL,
	[TransactionDescription] [varchar](100) NULL,
	[PeriodDateTime] [datetime] NULL,
	[PostingFlag] [char](5) NULL,
	[ProcCode] [char](2) NULL,
	[SrcIdentifier] [varchar](25) NULL,
	[CardNumber4Digits] [char](4) NULL,
	[RevTgt] [decimal](19, 0) NULL,
	[ReimbursementFee_11] [varchar](11) NULL,
	[FreeFormTextJapan] [varchar](135) NULL,
	[RowChangedDate] DATETIME NOT NULL DEFAULT GETDATE(),
	[ChangeVersion] ROWVERSION NOT NULL,
	[RowCreatedDate] DATETIME NOT NULL DEFAULT GETDATE(),
 CONSTRAINT [csPk_GLPostingTransactions_New] PRIMARY KEY CLUSTERED 
(
	[Skey] ASC, [PostTime] ASC -- new columns indicated by Kshitij after meeting.
    -- [TranId] ASC, [RowCreatedDate] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI]([PostTime])
) ON [DataPartitionScheme_PROD_CI]([PostTime]) -- also changed the partition column.
GO