USE [CoreAuth]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[NetworkMessage_New](
	[MessageTypeIdentifier] [char](4) NULL,
	[PrimaryAccountNumber] [varbinary](100) NULL,
	[TransmissionDateTime] [datetime] NULL,
	[SystemTraceAuditNumber] [char](6) NULL,
	[ForwardingInsitutionIDCode] [char](11) NULL,
	[ResponseCode] [char](3) NULL,
	[AdditionalResponseDataW] [varchar](25) NULL,
	[KeyClassIDTK] [char](2) NULL,
	[KeyIndexNumber] [char](2) NULL,
	[KeyCycleNumber] [char](2) NULL,
	[TheFinancialNetworkCode] [char](3) NULL,
	[NetworkReferenceNumber] [varchar](9) NULL,
	[BankNetReferenceNumber] [char](9) NULL,
	[Acquirerreferencenumber] [char](23) NULL,
	[GCMSProcDateCycleNum] [char](5) NULL,
	[NetworkMgmtInfoCode] [char](3) NULL,
	[MessageSecurityCode] [char](8) NULL,
	[PrivateData126] [varchar](150) NULL,
	[PrivateUse127] [varchar](100) NULL,
	[PAN_Hash] [int] NULL,
	[AVSResponse] [varchar](1) NULL,
	[CIDResonse] [char](1) NULL,
	[SourceofAuth] [varchar](1) NULL,
	[StandinLimit] [varchar](4) NULL,
	[FieldinError] [varchar](3) NULL,
	[AddresschangeNoti] [varchar](3) NULL,
	[AcquiringInsitutionIDCode] [char](11) NULL,
	[RetrievalReferenceNumber] [varchar](12) NULL,
	[TransportData] [char](100) NULL,
	[ReceivingInstIDCode] [char](11) NULL,
	[VersionNumber] [varchar](2) NULL,
	[EffectiveYear] [varchar](2) NULL,
	[ReleaseNumber] [varchar](1) NULL,
	[SecRelControlInfo] [char](16) NULL,
	[NetwrkMgmtInfoCode] [char](255) NULL,
	[MDSPrivateData2] [varchar](26) NULL,
	[FraudRiskInd] [char](6) NULL,
	[FraudScore] [varchar](3) NULL,
	[CurrencyIndicator] [varchar](1) NULL,
	[CrossBorderIndicator] [varchar](1) NULL,
	[MDSPrivateData1] [varchar](10) NULL,
	[SettlementServiceData] [varchar](3) NULL,
	[InterchangeRateIndicator] [varchar](2) NULL,
	[InfoTextConnex124W] [varchar](999) NULL,
	[IPAddress] [varchar](50) NULL,
	[PhysicalSource] [varchar](9) NULL,
	[UniqueID] [int] IDENTITY(1,1) NOT NULL,
	[PostTime] [datetime] NOT NULL,   -- changed because it will be the partitioning column.
	[AuthType] [char](7) NULL,
	[EmbAcctID] [int] NULL,
	[KeyNetworkID] [decimal](19, 0) NULL,
	[KCV] [varchar](32) NULL,
	[SourceMachineName] [varchar](50) NULL,
	[SinkMachineName] [varchar](50) NULL,
	[RowChangedDate] DATETIME NOT NULL DEFAULT GETDATE(),
	[ChangeVersion] ROWVERSION NOT NULL,
 CONSTRAINT [csPk_NetworkMessage_New] PRIMARY KEY CLUSTERED 
(
	[UniqueID] ASC, [PostTime] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CA]([PostTime])
) ON [DataPartitionScheme_PROD_CA]([PostTime])
GO

 