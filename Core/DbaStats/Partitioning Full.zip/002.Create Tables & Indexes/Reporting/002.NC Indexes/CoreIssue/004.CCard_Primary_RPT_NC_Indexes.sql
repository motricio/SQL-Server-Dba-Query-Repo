USE [CoreIssueRPT]
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [dbbidx_IX_BaseSegment]    Script Date: 5/8/2024 12:04:52 AM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_BaseSegment] ON [dbo].[CCard_Primary_RPT]
(
	[AccountNumber] ASC
)
INCLUDE([TranId],[TranTime],[PostTime],[CMTTRANTYPE],[Reversed],[RevTgt],[TransactionAmount],[PostingFlag],[TxnSource],[SKey],[SrcIdentifier],[CustomAcctID]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [dbbidx_IX_CmtTranType]    Script Date: 5/8/2024 12:04:52 AM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_CmtTranType] ON [dbo].[CCard_Primary_RPT]
(
	[CMTTRANTYPE] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [dbbidx_IX_CT_Composite_TDT_STAN_TI_MTI]    Script Date: 5/8/2024 12:04:52 AM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_CT_Composite_TDT_STAN_TI_MTI] ON [dbo].[CCard_Primary_RPT]
(
	[TransmissionDateTime] ASC,
	[SystemTraceAuditNumber] ASC,
	[TranId] ASC,
	[MessageTypeIdentifier] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

/****** Object:  Index [dbbidx_IX_CT_TransactionTime]    Script Date: 5/8/2024 12:04:53 AM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_CT_TransactionTime] ON [dbo].[CCard_Primary_RPT]
(
	[TranTime] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

/****** Object:  Index [dbbidx_IX_PostTime]    Script Date: 5/8/2024 12:04:53 AM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_PostTime] ON [dbo].[CCard_Primary_RPT]
(
	[PostTime] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

/****** Object:  Index [dbbidx_IX_RevTgt]    Script Date: 5/8/2024 12:04:53 AM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_RevTgt] ON [dbo].[CCard_Primary_RPT]
(
	[RevTgt] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

/****** Object:  Index [dbbidx_IX_TranOrignator]    Script Date: 5/8/2024 12:04:53 AM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_TranOrignator] ON [dbo].[CCard_Primary_RPT]
(
	[tranorig] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

/****** Object:  Index [dbbidx_IX_TranRef]    Script Date: 5/8/2024 12:04:53 AM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_TranRef] ON [dbo].[CCard_Primary_RPT]
(
	[TranRef] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

/****** Object:  Index [dbbidx_panhash_ccard_primary]    Script Date: 5/8/2024 12:04:53 AM ******/
CREATE NONCLUSTERED INDEX [dbbidx_panhash_ccard_primary] ON [dbo].[CCard_Primary_RPT]
(
	[PAN_Hash] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

/****** Object:  Index [IDX_DBA_perf07]    Script Date: 5/8/2024 12:04:53 AM ******/
CREATE NONCLUSTERED INDEX [IDX_DBA_perf07] ON [dbo].[CCard_Primary_RPT]
(
	[TranId] ASC
)
INCLUDE([PostTime],[CMTTRANTYPE],[tranorig],[TransactionAmount],[TransmissionDateTime],[PostingRef],[TxnSource],[TransactionDescription],[Transactionidentifier],[MerchantType],[MerchantCity],[MerchantCountryCode],[MerchantStProvCode],[AuthTranId],[SKey]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [IDX_DBA_Perf3]    Script Date: 5/8/2024 12:04:53 AM ******/
CREATE NONCLUSTERED INDEX [IDX_DBA_Perf3] ON [dbo].[CCard_Primary_RPT]
(
	[CMTTRANTYPE] ASC
)
INCLUDE([TranId],[TransactionAmount],[TxnSource],[InstitutionID],[AuthTranId]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

/****** Object:  Index [ix_CCard_Primary_AuthTranId]    Script Date: 5/8/2024 12:04:53 AM ******/
CREATE NONCLUSTERED INDEX [ix_CCard_Primary_AuthTranId] ON [dbo].[CCard_Primary_RPT]
(
	[AuthTranId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [RD_NC_CCard_EmbAcctid]    Script Date: 5/8/2024 12:04:53 AM ******/
CREATE NONCLUSTERED INDEX [RD_NC_CCard_EmbAcctid] ON [dbo].[CCard_Primary_RPT]
(
	[TranTime] ASC,
	[CMTTRANTYPE] ASC
)
INCLUDE([AccountNumber],[ProductID],[EmbAcctId]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [RD_NC_ccard_primary_AccountNumber]    Script Date: 5/8/2024 12:04:53 AM ******/
CREATE NONCLUSTERED INDEX [RD_NC_ccard_primary_AccountNumber] ON [dbo].[CCard_Primary_RPT]
(
	[AccountNumber] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [RD_NC_CCard_Primary_ARTxnType]    Script Date: 5/8/2024 12:04:53 AM ******/
CREATE NONCLUSTERED INDEX [RD_NC_CCard_Primary_ARTxnType] ON [dbo].[CCard_Primary_RPT]
(
	[ARTxnType] ASC
)
INCLUDE([TranId],[TranTime],[TransactionAmount],[AccountNumber],[TxnCode_Internal],[PostingRef],[RejectBatchAcctId],[TxnSource],[TransactionDescription],[SystemTraceAuditNumber],[ProductID],[InstitutionID],[AuthTranId]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [RD_NC_ccard_primary_AuthStatus_TranTime]    Script Date: 5/8/2024 12:04:53 AM ******/
CREATE NONCLUSTERED INDEX [RD_NC_ccard_primary_AuthStatus_TranTime] ON [dbo].[CCard_Primary_RPT]
(
	[PrimaryAccountNumber] ASC,
	[MessageTypeIdentifier] ASC,
	[AuthStatus] ASC,
	[TranTime] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

/****** Object:  Index [RD_NC_CCard_Primary_AuthTranId]    Script Date: 5/8/2024 12:04:53 AM ******/
CREATE NONCLUSTERED INDEX [RD_NC_CCard_Primary_AuthTranId] ON [dbo].[CCard_Primary_RPT]
(
	[AuthTranId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [RD_NC_ccard_Primary_CheckNumber]    Script Date: 5/8/2024 12:04:53 AM ******/
CREATE NONCLUSTERED INDEX [RD_NC_ccard_Primary_CheckNumber] ON [dbo].[CCard_Primary_RPT]
(
	[CheckNumber] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [rd_nc_ccard_primary_cmttrantype_sf]    Script Date: 5/8/2024 12:04:53 AM ******/
CREATE NONCLUSTERED INDEX [rd_nc_ccard_primary_cmttrantype_sf] ON [dbo].[CCard_Primary_RPT]
(
	[CMTTRANTYPE] ASC
)
INCLUDE([TranId],[TranTime],[TranRef],[TransactionAmount],[AccountNumber],[TxnSource],[ProductID],[InstitutionID],[CardNumber4Digits]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [RD_NC_ccard_primary_cmttype]    Script Date: 5/8/2024 12:04:53 AM ******/
CREATE NONCLUSTERED INDEX [RD_NC_ccard_primary_cmttype] ON [dbo].[CCard_Primary_RPT]
(
	[CMTTRANTYPE] ASC
)
INCLUDE([TranId],[TransactionAmount],[TxnSource],[InstitutionID],[AuthTranId]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [RD_NC_ccard_primary_cmttype_txnsource]    Script Date: 5/8/2024 12:04:53 AM ******/
CREATE NONCLUSTERED INDEX [RD_NC_ccard_primary_cmttype_txnsource] ON [dbo].[CCard_Primary_RPT]
(
	[CMTTRANTYPE] ASC,
	[TxnSource] ASC,
	[TranTime] ASC
)
INCLUDE([TranId],[TxnAcctId]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

/****** Object:  Index [RD_NC_ccard_primary_PAN_Hash]    Script Date: 5/8/2024 12:04:53 AM ******/
CREATE NONCLUSTERED INDEX [RD_NC_ccard_primary_PAN_Hash] ON [dbo].[CCard_Primary_RPT]
(
	[PAN_Hash] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

/****** Object:  Index [rd_nc_CCard_Primary_PostTime]    Script Date: 5/8/2024 12:04:53 AM ******/
CREATE NONCLUSTERED INDEX [rd_nc_CCard_Primary_PostTime] ON [dbo].[CCard_Primary_RPT]
(
	[PostTime] ASC
)
INCLUDE([TranId],[AccountNumber],[TxnCode_Internal],[TxnSource],[MerchantType],[ProductID],[InstitutionID]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [RD_NC_CCard_Primary_Posttime_ArtxnType]    Script Date: 5/8/2024 12:04:53 AM ******/
CREATE NONCLUSTERED INDEX [RD_NC_CCard_Primary_Posttime_ArtxnType] ON [dbo].[CCard_Primary_RPT]
(
	[PostTime] ASC,
	[ARTxnType] ASC
)
INCLUDE([TranId],[CMTTRANTYPE],[TransactionAmount],[TxnSource],[TransactionCurrencyCode],[SettlementAmount],[ProductID],[InstitutionID],[AuthTranId]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [RD_NC_ccard_primary_pstflag_txnamount]    Script Date: 5/8/2024 12:04:53 AM ******/
CREATE NONCLUSTERED INDEX [RD_NC_ccard_primary_pstflag_txnamount] ON [dbo].[CCard_Primary_RPT]
(
	[PostingFlag] ASC,
	[CMTTRANTYPE] ASC,
	[TransactionAmount] ASC
)
INCLUDE([TranId],[PostTime],[TranRef],[RevTgt],[tranorig],[MessageTypeIdentifier],[NetworkName],[AuthStatus],[AccountNumber],[TxnCode_Internal],[PostingRef],[ARTxnType],[TxnSource],[MerchantType],[ProductID],[InstitutionID],[AuthTranId]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [RD_NC_ccard_primary_psttime_pid_txnamount]    Script Date: 5/8/2024 12:04:53 AM ******/
CREATE NONCLUSTERED INDEX [RD_NC_ccard_primary_psttime_pid_txnamount] ON [dbo].[CCard_Primary_RPT]
(
	[ProductID] ASC,
	[PostTime] ASC,
	[CMTTRANTYPE] ASC,
	[TransactionAmount] ASC
)
INCLUDE([TranId],[TranRef],[AccountNumber],[PostingFlag],[InstitutionID],[AuthTranId],[CardNumber4Digits]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [RD_NC_CCard_Primary_RejectBatchAcctId_ARTxnType]    Script Date: 5/8/2024 12:04:53 AM ******/
CREATE NONCLUSTERED INDEX [RD_NC_CCard_Primary_RejectBatchAcctId_ARTxnType] ON [dbo].[CCard_Primary_RPT]
(
	[RejectBatchAcctId] ASC,
	[ARTxnType] ASC,
	[InstitutionID] ASC,
	[ProductID] ASC
)
INCLUDE([TranId],[TranTime],[TransactionAmount],[AccountNumber],[TxnCode_Internal],[PostingRef],[TxnSource],[TransactionDescription],[SystemTraceAuditNumber],[AuthTranId]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

/****** Object:  Index [RD_NC_ccard_primary_RevTgt]    Script Date: 5/8/2024 12:04:53 AM ******/
CREATE NONCLUSTERED INDEX [RD_NC_ccard_primary_RevTgt] ON [dbo].[CCard_Primary_RPT]
(
	[RevTgt] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

/****** Object:  Index [rd_nc_ccard_primary_sf]    Script Date: 5/8/2024 12:04:53 AM ******/
CREATE NONCLUSTERED INDEX [rd_nc_ccard_primary_sf] ON [dbo].[CCard_Primary_RPT]
(
	[TranId] ASC
)
INCLUDE([TranTime],[TranRef],[TransactionAmount],[AccountNumber],[TxnSource],[ProductID],[InstitutionID],[CardNumber4Digits]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [RD_NC_CCard_Primary_Sour_Inst_LM]    Script Date: 5/8/2024 12:04:53 AM ******/
CREATE NONCLUSTERED INDEX [RD_NC_CCard_Primary_Sour_Inst_LM] ON [dbo].[CCard_Primary_RPT]
(
	[TxnSource] ASC,
	[InstitutionID] ASC,
	[CMTTRANTYPE] ASC
)
INCLUDE([TranId],[PostTime],[TransactionAmount],[AccountNumber],[TransactionCurrencyCode],[SettlementAmount],[CardAcceptorTerminalID],[CurrCodeCardHolderBilling],[CardholderBillingAmount],[SystemTraceAuditNumber],[RetrievalReferenceNumber],[AuthTranId]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

/****** Object:  Index [RD_NC_ccard_primary_TmsDateTime]    Script Date: 5/8/2024 12:04:54 AM ******/
CREATE NONCLUSTERED INDEX [RD_NC_ccard_primary_TmsDateTime] ON [dbo].[CCard_Primary_RPT]
(
	[TransmissionDateTime] ASC,
	[WarehouseTxnDate] ASC
)
INCLUDE([TranId],[CMTTRANTYPE],[TransactionAmount],[AccountNumber],[creditplanmaster],[TxnCode_Internal],[PaymentCreditFlag],[TransactionCurrencyCode],[ProductID],[InstitutionID]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

/****** Object:  Index [RD_NC_CCard_Primary_TranID]    Script Date: 5/8/2024 12:04:54 AM ******/
CREATE NONCLUSTERED INDEX [RD_NC_CCard_Primary_TranID] ON [dbo].[CCard_Primary_RPT]
(
	[TranId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

/****** Object:  Index [RD_NC_Ccard_Primary_TranID_IncludeTransmissinoDtTxnDesc]    Script Date: 5/8/2024 12:04:54 AM ******/
CREATE NONCLUSTERED INDEX [RD_NC_Ccard_Primary_TranID_IncludeTransmissinoDtTxnDesc] ON [dbo].[CCard_Primary_RPT]
(
	[TranId] ASC
)
INCLUDE([TransmissionDateTime],[TransactionDescription]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

/****** Object:  Index [RD_NC_CCard_Primary_TranId_ProductID]    Script Date: 5/8/2024 12:04:54 AM ******/
CREATE NONCLUSTERED INDEX [RD_NC_CCard_Primary_TranId_ProductID] ON [dbo].[CCard_Primary_RPT]
(
	[TranId] ASC,
	[ProductID] ASC
)
INCLUDE([AccountNumber],[TransactionDescription],[AuthTranId]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [RD_NC_ccard_primary_tranid_txnacctid_txnsource]    Script Date: 5/8/2024 12:04:54 AM ******/
CREATE NONCLUSTERED INDEX [RD_NC_ccard_primary_tranid_txnacctid_txnsource] ON [dbo].[CCard_Primary_RPT]
(
	[TranId] ASC,
	[CMTTRANTYPE] ASC,
	[TxnAcctId] ASC,
	[TxnSource] ASC,
	[TranTime] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

/****** Object:  Index [RD_NC_ccard_primary_tranid1]    Script Date: 5/8/2024 12:04:54 AM ******/
CREATE NONCLUSTERED INDEX [RD_NC_ccard_primary_tranid1] ON [dbo].[CCard_Primary_RPT]
(
	[TranId] ASC
)
INCLUDE([PostTime],[CMTTRANTYPE],[tranorig],[TransactionAmount],[TransmissionDateTime],[PostingRef],[TxnSource],[TransactionDescription],[Transactionidentifier],[MerchantType],[MerchantCity],[MerchantCountryCode],[MerchantStProvCode],[AuthTranId],[SKey]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [RD_NC_ccard_primary_TransmissionDateTime_TransactionDescription]    Script Date: 5/8/2024 12:04:54 AM ******/
CREATE NONCLUSTERED INDEX [RD_NC_ccard_primary_TransmissionDateTime_TransactionDescription] ON [dbo].[CCard_Primary_RPT]
(
	[TranId] ASC,
	[AccountNumber] ASC
)
INCLUDE([TransmissionDateTime],[TransactionDescription]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

/****** Object:  Index [RD_NC_ccard_primary_TranTime]    Script Date: 5/8/2024 12:04:54 AM ******/
CREATE NONCLUSTERED INDEX [RD_NC_ccard_primary_TranTime] ON [dbo].[CCard_Primary_RPT]
(
	[TranTime] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [RD_NC_ccard_primary_txmtime_tranid]    Script Date: 5/8/2024 12:04:54 AM ******/
CREATE NONCLUSTERED INDEX [RD_NC_ccard_primary_txmtime_tranid] ON [dbo].[CCard_Primary_RPT]
(
	[TransmissionDateTime] ASC,
	[SystemTraceAuditNumber] ASC,
	[TranId] ASC,
	[MessageTypeIdentifier] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [RD_NC_Ccard_primary_Txnsource]    Script Date: 5/8/2024 12:04:54 AM ******/
CREATE NONCLUSTERED INDEX [RD_NC_Ccard_primary_Txnsource] ON [dbo].[CCard_Primary_RPT]
(
	[TxnSource] ASC,
	[SrcIdentifier] ASC,
	[InstitutionID] ASC
)
INCLUDE([TranId],[TranTime],[PostingFlag],[PostingRef],[ProductID],[PaymentMethod]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [RD_NC_CCard_Primary_TxnSource_Inst_LM]    Script Date: 5/8/2024 12:04:54 AM ******/
CREATE NONCLUSTERED INDEX [RD_NC_CCard_Primary_TxnSource_Inst_LM] ON [dbo].[CCard_Primary_RPT]
(
	[TxnSource] ASC,
	[InstitutionID] ASC,
	[CMTTRANTYPE] ASC
)
INCLUDE([TranId],[PostTime],[TransactionAmount],[AccountNumber],[TransactionCurrencyCode],[SettlementAmount],[CardAcceptorTerminalID],[CurrCodeCardHolderBilling],[CardholderBillingAmount],[SystemTraceAuditNumber],[RetrievalReferenceNumber],[AuthTranId]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [RD_NC_ccard_primary_txnsource_tranid]    Script Date: 5/8/2024 12:04:54 AM ******/
CREATE NONCLUSTERED INDEX [RD_NC_ccard_primary_txnsource_tranid] ON [dbo].[CCard_Primary_RPT]
(
	[TxnSource] ASC,
	[TranId] ASC,
	[CMTTRANTYPE] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [RD_NC_CCard_Primary_TxnSource1]    Script Date: 5/8/2024 12:04:54 AM ******/
CREATE NONCLUSTERED INDEX [RD_NC_CCard_Primary_TxnSource1] ON [dbo].[CCard_Primary_RPT]
(
	[TxnSource] ASC
)
INCLUDE([TranId],[PostTime],[CMTTRANTYPE],[Reversed],[TransactionAmount],[AccountNumber],[CardAcceptorTerminalID],[RetrievalReferenceNumber],[AuthTranId]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [RD_NC_CCard_Primary_TxnSrc_Cmttantype]    Script Date: 5/8/2024 12:04:54 AM ******/
CREATE NONCLUSTERED INDEX [RD_NC_CCard_Primary_TxnSrc_Cmttantype] ON [dbo].[CCard_Primary_RPT]
(
	[TxnSource] ASC,
	[CMTTRANTYPE] ASC
)
INCLUDE([TranId],[RevTgt],[TransactionAmount],[AccountNumber],[TransactionCurrencyCode],[SettlementAmount],[CardAcceptorTerminalID],[CurrCodeCardHolderBilling],[CardholderBillingAmount],[SystemTraceAuditNumber],[RetrievalReferenceNumber],[AuthTranId]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

/****** Object:  Index [RD_NC_Ccard_TranID_IncludeAcctidOth]    Script Date: 5/8/2024 12:04:54 AM ******/
CREATE NONCLUSTERED INDEX [RD_NC_Ccard_TranID_IncludeAcctidOth] ON [dbo].[CCard_Primary_RPT]
(
	[TranId] ASC
)
INCLUDE([TxnAcctId],[tranorig],[TransactionDescription],[TransactionCurrencyCode],[PAN_Hash],[AuthTranId],[CardNumber4Digits],[CustomAcctID]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [RD_NC_CCard_TxnSource_Include]    Script Date: 5/8/2024 12:04:54 AM ******/
CREATE NONCLUSTERED INDEX [RD_NC_CCard_TxnSource_Include] ON [dbo].[CCard_Primary_RPT]
(
	[TxnSource] ASC
)
INCLUDE([TranId],[CMTTRANTYPE],[TransactionAmount],[TxnCode_Internal],[InstitutionID],[AuthTranId]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [RD_NC_CcardPrima_PIDCMTSKEY]    Script Date: 5/8/2024 12:04:54 AM ******/
CREATE NONCLUSTERED INDEX [RD_NC_CcardPrima_PIDCMTSKEY] ON [dbo].[CCard_Primary_RPT]
(
	[ProductID] ASC,
	[CMTTRANTYPE] ASC,
	[SKey] ASC
)
INCLUDE([TranId],[PostTime],[TranRef],[RevTgt],[tranorig],[TransactionAmount],[NetworkName],[AccountNumber],[TxnCode_Internal],[PostingFlag],[TxnSource],[InstitutionID],[AuthTranId],[CardNumber4Digits]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [RD_NC_ccardprimary_Accountnumber]    Script Date: 5/8/2024 12:04:54 AM ******/
CREATE NONCLUSTERED INDEX [RD_NC_ccardprimary_Accountnumber] ON [dbo].[CCard_Primary_RPT]
(
	[AccountNumber] ASC,
	[PostTime] ASC
)
INCLUDE([TranId],[EmbAcctId]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [RD_NC_ccardprimary_cmttrantype]    Script Date: 5/8/2024 12:04:54 AM ******/
CREATE NONCLUSTERED INDEX [RD_NC_ccardprimary_cmttrantype] ON [dbo].[CCard_Primary_RPT]
(
	[CMTTRANTYPE] ASC,
	[PostTime] ASC
)
INCLUDE([TransactionAmount],[AccountNumber],[TransactionCurrencyCode],[EmbAcctId]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [RD_NC_CCArdPrimary_CMTTranType_ArTxnType_Include]    Script Date: 5/8/2024 12:04:54 AM ******/
CREATE NONCLUSTERED INDEX [RD_NC_CCArdPrimary_CMTTranType_ArTxnType_Include] ON [dbo].[CCard_Primary_RPT]
(
	[CMTTRANTYPE] ASC,
	[ARTxnType] ASC
)
INCLUDE([PostTime],[AccountNumber]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

/****** Object:  Index [RD_NC_ccardprimary_embacctid]    Script Date: 5/8/2024 12:04:54 AM ******/
CREATE NONCLUSTERED INDEX [RD_NC_ccardprimary_embacctid] ON [dbo].[CCard_Primary_RPT]
(
	[EmbAcctId] ASC
)
INCLUDE([PostTime],[AccountNumber]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [RD_NC_CCArdPrimary_PostingFlag_CMTTranType_TxnAmount_Include]    Script Date: 5/8/2024 12:04:54 AM ******/
CREATE NONCLUSTERED INDEX [RD_NC_CCArdPrimary_PostingFlag_CMTTranType_TxnAmount_Include] ON [dbo].[CCard_Primary_RPT]
(
	[PostingFlag] ASC,
	[CMTTRANTYPE] ASC,
	[TransactionAmount] ASC
)
INCLUDE([TranId],[PostTime],[TranRef],[tranorig],[MessageTypeIdentifier],[NetworkName],[AuthStatus],[AccountNumber],[TxnCode_Internal],[PostingRef],[ARTxnType],[TxnSource],[MerchantType],[AuthTranId]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [RD_NC_CCardPrimary_Posttime_ARTxnType]    Script Date: 5/8/2024 12:04:54 AM ******/
CREATE NONCLUSTERED INDEX [RD_NC_CCardPrimary_Posttime_ARTxnType] ON [dbo].[CCard_Primary_RPT]
(
	[PostTime] ASC,
	[ARTxnType] ASC
)
INCLUDE([TranId],[CMTTRANTYPE],[TransactionAmount],[AccountNumber],[TxnSource],[MerchantType],[ProductID],[InstitutionID]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [RD_NC_ccardprimary_Tranid_CM]    Script Date: 5/8/2024 12:04:55 AM ******/
CREATE NONCLUSTERED INDEX [RD_NC_ccardprimary_Tranid_CM] ON [dbo].[CCard_Primary_RPT]
(
	[InstitutionID] ASC,
	[CMTTRANTYPE] ASC,
	[TxnSource] ASC,
	[ARTxnType] ASC
)
INCLUDE([TranId],[PostTime],[TransactionAmount],[AccountNumber],[TransactionCurrencyCode],[SettlementAmount],[CardAcceptorTerminalID],[AuthTranId]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

/****** Object:  Index [RD_NC_ccardprimary_Tranid_Include]    Script Date: 5/8/2024 12:04:55 AM ******/
CREATE NONCLUSTERED INDEX [RD_NC_ccardprimary_Tranid_Include] ON [dbo].[CCard_Primary_RPT]
(
	[TranId] ASC
)
INCLUDE([AccountNumber],[TransactionDescription],[ProductID],[AuthTranId]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

/****** Object:  Index [RD_NC_CCArdPrimary_TranID_IncludeAcNoCardNumberTxnSource]    Script Date: 5/8/2024 12:04:55 AM ******/
CREATE NONCLUSTERED INDEX [RD_NC_CCArdPrimary_TranID_IncludeAcNoCardNumberTxnSource] ON [dbo].[CCard_Primary_RPT]
(
	[TranId] ASC
)
INCLUDE([AccountNumber],[TxnSource],[CardNumber4Digits]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [RD_NC_CP_ACNo_Tid_Include_4PanATid_ETC]    Script Date: 5/8/2024 12:04:55 AM ******/
CREATE NONCLUSTERED INDEX [RD_NC_CP_ACNo_Tid_Include_4PanATid_ETC] ON [dbo].[CCard_Primary_RPT]
(
	[AccountNumber] ASC,
	[FeesAcctATID] ASC,
	[FeesAcctID] ASC,
	[TranId] ASC
)
INCLUDE([TxnAcctId],[ATID],[PAN_Hash],[CardNumber4Digits],[TranAmountWithMarkup],[TransferAmountMarkupCurrency],[PaymentMethod]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [RD_NC_CP_PCFACNo_Tid_Include_4PanATid_ETC]    Script Date: 5/8/2024 12:04:55 AM ******/
CREATE NONCLUSTERED INDEX [RD_NC_CP_PCFACNo_Tid_Include_4PanATid_ETC] ON [dbo].[CCard_Primary_RPT]
(
	[PaymentCreditFlag] ASC,
	[AccountNumber] ASC,
	[TranId] ASC
)
INCLUDE([TxnAcctId],[ATID],[PAN_Hash],[CardNumber4Digits],[TranAmountWithMarkup],[TransferAmountMarkupCurrency],[PaymentMethod]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [RD_NC_DBA_ccard_primary__TxnSource]    Script Date: 5/8/2024 12:04:55 AM ******/
CREATE NONCLUSTERED INDEX [RD_NC_DBA_ccard_primary__TxnSource] ON [dbo].[CCard_Primary_RPT]
(
	[TxnSource] ASC
)
INCLUDE([CMTTRANTYPE],[AuthTranId]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [RD_NC_DBA_ccard_primary__TxnSource_CMTTRANTYPE]    Script Date: 5/8/2024 12:04:55 AM ******/
CREATE NONCLUSTERED INDEX [RD_NC_DBA_ccard_primary__TxnSource_CMTTRANTYPE] ON [dbo].[CCard_Primary_RPT]
(
	[TxnSource] ASC,
	[CMTTRANTYPE] ASC
)
INCLUDE([TranId],[TransactionAmount],[AccountNumber],[AuthTranId]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO