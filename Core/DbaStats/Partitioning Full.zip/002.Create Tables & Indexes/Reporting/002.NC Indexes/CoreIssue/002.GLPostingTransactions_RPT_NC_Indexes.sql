USE [CoreIssueRPT]
GO


CREATE NONCLUSTERED INDEX [RD_NC_GLPostingTransactions_PostingFlagPostTime] ON [dbo].[GLPostingTransactions_RPT]
(
	[PostingFlag] ASC,
	[PostTime] ASC
)
INCLUDE([TranId],[TransactionAmount],[TransactionCurrencyCode],[SettlementAmount],[SettlementCurrencyCode],[MessageTypeIdentifier],[TxnSource],[CMTTRANTYPE],[TransactionCode],[ActualTranCode],[GLGroupID],[DebitGL],[DebitGL_Currency],[CreditGL],[CreditGL_Currency],[DebitGL_Settlement],[DebitGL_Settlement_Currency],[CreditGL_Settlement],[CreditGL_Settlement_Currency],[GLProductID],[InstitutionId],[SweepStatus],[ProcCode],[SrcIdentifier],[ReimbursementFee_11]) 
WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) 
ON [CIDataPartitionScheme]([PostTime])
GO