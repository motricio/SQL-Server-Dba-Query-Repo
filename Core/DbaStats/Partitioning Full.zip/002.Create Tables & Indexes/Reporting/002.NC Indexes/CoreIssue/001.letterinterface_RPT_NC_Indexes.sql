USE [CoreIssueRPT]
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [dbbidx_IX_CT_Composite_StatusModule]    Script Date: 5/7/2024 11:18:52 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_CT_Composite_StatusModule] ON [dbo].[letterinterface_RPT]
(
	[LetterStatus] ASC,
	[CorecardModule] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([LetterDraftedDate])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [dbbidx_IX_LetterGenAdditionalLetterText]    Script Date: 5/7/2024 11:18:54 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_LetterGenAdditionalLetterText] ON [dbo].[letterinterface_RPT]
(
	[AdditionalLetterText] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([LetterDraftedDate])
GO

/****** Object:  Index [dbbidx_IX_LetterGenATID]    Script Date: 5/7/2024 11:18:54 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_LetterGenATID] ON [dbo].[letterinterface_RPT]
(
	[ATID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([LetterDraftedDate])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [dbbidx_IX_LetterGenCardNumber]    Script Date: 5/7/2024 11:18:54 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_LetterGenCardNumber] ON [dbo].[letterinterface_RPT]
(
	[CardNumber] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([LetterDraftedDate])
GO

/****** Object:  Index [dbbidx_IX_LetterGenCaseNumber]    Script Date: 5/7/2024 11:18:54 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_LetterGenCaseNumber] ON [dbo].[letterinterface_RPT]
(
	[CaseNumber] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([LetterDraftedDate])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [dbbidx_IX_LetterGenCorecardModule]    Script Date: 5/7/2024 11:18:54 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_LetterGenCorecardModule] ON [dbo].[letterinterface_RPT]
(
	[CorecardModule] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([LetterDraftedDate])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [dbbidx_IX_LetterGenLetterDraftedBy]    Script Date: 5/7/2024 11:18:54 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_LetterGenLetterDraftedBy] ON [dbo].[letterinterface_RPT]
(
	[LetterDraftedBy] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([LetterDraftedDate])
GO

/****** Object:  Index [dbbidx_IX_LetterGenLetterDraftedDate]    Script Date: 5/7/2024 11:18:54 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_LetterGenLetterDraftedDate] ON [dbo].[letterinterface_RPT]
(
	[LetterDraftedDate] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([LetterDraftedDate])
GO

/****** Object:  Index [dbbidx_IX_LetterGenLetterSentDate]    Script Date: 5/7/2024 11:18:54 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_LetterGenLetterSentDate] ON [dbo].[letterinterface_RPT]
(
	[LetterSentDate] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([LetterDraftedDate])
GO

/****** Object:  Index [dbbidx_IX_LetterGenLetterTemplateID]    Script Date: 5/7/2024 11:18:54 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_LetterGenLetterTemplateID] ON [dbo].[letterinterface_RPT]
(
	[LetterTemplateID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([LetterDraftedDate])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [dbbidx_IX_LetterGenLetterTemplateIDDesc]    Script Date: 5/7/2024 11:18:54 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_LetterGenLetterTemplateIDDesc] ON [dbo].[letterinterface_RPT]
(
	[LetterTemplateIDDesc] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([LetterDraftedDate])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [dbbidx_IX_LetterGenLetterTemplateStatus]    Script Date: 5/7/2024 11:18:54 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_LetterGenLetterTemplateStatus] ON [dbo].[letterinterface_RPT]
(
	[LetterTemplateStatus] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([LetterDraftedDate])
GO

/****** Object:  Index [dbbidx_IX_LetterGenLetterTemplateVersion]    Script Date: 5/7/2024 11:18:54 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_LetterGenLetterTemplateVersion] ON [dbo].[letterinterface_RPT]
(
	[LetterTemplateVersion] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([LetterDraftedDate])
GO

/****** Object:  Index [dbbidx_IX_LetterGenOutcomeDefId]    Script Date: 5/7/2024 11:18:54 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_LetterGenOutcomeDefId] ON [dbo].[letterinterface_RPT]
(
	[LetterOutcomeDefId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([LetterDraftedDate])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [dbbidx_IX_LetterGenQueueName]    Script Date: 5/7/2024 11:18:54 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_LetterGenQueueName] ON [dbo].[letterinterface_RPT]
(
	[LetterQueueName] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([LetterDraftedDate])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [idx_LetterInterface_NextDate_Status_MT_Lid_A]    Script Date: 5/7/2024 11:18:54 PM ******/
CREATE NONCLUSTERED INDEX [idx_LetterInterface_NextDate_Status_MT_Lid_A] ON [dbo].[letterinterface_RPT]
(
	[LetterStatus] ASC,
	[NextDate] ASC,
	[LetterID] ASC,
	[messageType] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([LetterDraftedDate])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [ix_LetterInterface_AcctNumber]    Script Date: 5/7/2024 11:18:54 PM ******/
CREATE NONCLUSTERED INDEX [ix_LetterInterface_AcctNumber] ON [dbo].[letterinterface_RPT]
(
	[AcctNumber] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([LetterDraftedDate])
GO

/****** Object:  Index [ix_LetterInterface_NextDate_LetterID]    Script Date: 5/7/2024 11:18:54 PM ******/
CREATE NONCLUSTERED INDEX [ix_LetterInterface_NextDate_LetterID] ON [dbo].[letterinterface_RPT]
(
	[NextDate] ASC,
	[LetterID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([LetterDraftedDate])
GO


