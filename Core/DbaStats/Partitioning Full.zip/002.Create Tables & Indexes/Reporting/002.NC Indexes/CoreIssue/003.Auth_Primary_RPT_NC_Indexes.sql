USE [CoreIssueRPT]
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [dbbidx_IX_Auth_Primary_AccountNumber]    Script Date: 5/7/2024 11:51:12 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_Auth_Primary_AccountNumber] ON [dbo].[Auth_Primary_RPT]
(
	[AccountNumber] ASC
)
INCLUDE([TranId],[AuthStatus],[TransactionAmount],[OutstandingAmount]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

/****** Object:  Index [dbbidx_IX_Auth_Primary_CoreAuthTranId]    Script Date: 5/7/2024 11:51:12 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_Auth_Primary_CoreAuthTranId] ON [dbo].[Auth_Primary_RPT]
(
	[CoreAuthTranId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [dbbidx_IX_Auth_Primary_CT_PAN_MTI_AS_TT]    Script Date: 5/7/2024 11:51:12 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_Auth_Primary_CT_PAN_MTI_AS_TT] ON [dbo].[Auth_Primary_RPT]
(
	[PrimaryAccountNumber] ASC,
	[MessageTypeIdentifier] ASC,
	[AuthStatus] ASC,
	[TranTime] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [dbbidx_IX_Auth_Primary_MessageTypeIdentifier]    Script Date: 5/7/2024 11:51:12 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_Auth_Primary_MessageTypeIdentifier] ON [dbo].[Auth_Primary_RPT]
(
	[MessageTypeIdentifier] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

/****** Object:  Index [dbbidx_IX_Auth_Primary_PostTime]    Script Date: 5/7/2024 11:51:12 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_Auth_Primary_PostTime] ON [dbo].[Auth_Primary_RPT]
(
	[PostTime] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [dbbidx_IX_Auth_Primary_RetrievalReferenceNumber]    Script Date: 5/7/2024 11:51:12 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_Auth_Primary_RetrievalReferenceNumber] ON [dbo].[Auth_Primary_RPT]
(
	[RetrievalReferenceNumber] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

/****** Object:  Index [dbbidx_IX_Auth_Primary_RevTgt]    Script Date: 5/7/2024 11:51:12 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_Auth_Primary_RevTgt] ON [dbo].[Auth_Primary_RPT]
(
	[RevTgt] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

/****** Object:  Index [dbbidx_IX_Auth_Primary_TranTime]    Script Date: 5/7/2024 11:51:12 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_Auth_Primary_TranTime] ON [dbo].[Auth_Primary_RPT]
(
	[TranTime] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

/****** Object:  Index [dbbidx_IX_TxnLifeCycleUniqueID]    Script Date: 5/7/2024 11:51:12 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_TxnLifeCycleUniqueID] ON [dbo].[Auth_Primary_RPT]
(
	[TransactionLifeCycleUniqueID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

/****** Object:  Index [dbx_Auth_Primary_TranID]    Script Date: 5/7/2024 11:51:12 PM ******/
CREATE NONCLUSTERED INDEX [dbx_Auth_Primary_TranID] ON [dbo].[Auth_Primary_RPT]
(
	[TranId] ASC
)
INCLUDE([AuthStatus],[TransactionAmount],[TimeLocalTransaction],[DateLocalTransaction],[ResponseCode],[TxnSrcAmt],[IResponseCode],[OutstandingAmount],[CardAcceptorIdCode],[MerchantNameandAddress],[SKey],[CustomAcctID]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [IDX_DBA_Perf6]    Script Date: 5/7/2024 11:51:12 PM ******/
CREATE NONCLUSTERED INDEX [IDX_DBA_Perf6] ON [dbo].[Auth_Primary_RPT]
(
	[AccountNumber] ASC,
	[CMTTRANTYPE] ASC,
	[AuthStatus] ASC,
	[TxnCategory] ASC
)
INCLUDE([TranId],[TranTime],[PostTime],[TxnCode_Internal],[TxnSource],[TransactionAmount],[TransmissionDateTime],[TimeLocalTransaction],[MerchantType],[CardAcceptorNameLocation],[TxnSrcAmt],[POSCountryCode],[CoreAuthTranId],[OutstandingAmount],[CardAcceptorIdCode],[MerchantNameandAddress],[SKey]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [Ix_Auth_Primary_TxnSource_CmtTrantype]    Script Date: 5/7/2024 11:51:12 PM ******/
CREATE NONCLUSTERED INDEX [Ix_Auth_Primary_TxnSource_CmtTrantype] ON [dbo].[Auth_Primary_RPT]
(
	[TranId] ASC,
	[TxnSource] ASC,
	[CMTTRANTYPE] ASC,
	[InstitutionID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [RD_NC_Auth_Primary_AccountNumber]    Script Date: 5/7/2024 11:51:12 PM ******/
CREATE NONCLUSTERED INDEX [RD_NC_Auth_Primary_AccountNumber] ON [dbo].[Auth_Primary_RPT]
(
	[AccountNumber] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

/****** Object:  Index [RD_NC_Auth_Primary_CoreAuthTranId]    Script Date: 5/7/2024 11:51:12 PM ******/
CREATE NONCLUSTERED INDEX [RD_NC_Auth_Primary_CoreAuthTranId] ON [dbo].[Auth_Primary_RPT]
(
	[CoreAuthTranId] ASC
)
INCLUDE([TranId],[TransactionLifeCycleUniqueID]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

/****** Object:  Index [RD_NC_Auth_Primary_IndexPosttime]    Script Date: 5/7/2024 11:51:12 PM ******/
CREATE NONCLUSTERED INDEX [RD_NC_Auth_Primary_IndexPosttime] ON [dbo].[Auth_Primary_RPT]
(
	[PostTime] ASC
)
INCLUDE([TranId],[CMTTRANTYPE],[AccountNumber],[PostingRef],[AuthStatus],[ProcCode],[TransactionAmount],[MerchantType],[ResponseCode],[ApprovalCode],[NetworkName],[POSCountryCode],[TxnCategory],[MessageTypeIdentifier],[InstitutionID],[ProductID]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [RD_NC_Auth_Primary_many]    Script Date: 5/7/2024 11:51:12 PM ******/
CREATE NONCLUSTERED INDEX [RD_NC_Auth_Primary_many] ON [dbo].[Auth_Primary_RPT]
(
	[PrimaryAccountNumber] ASC,
	[MessageTypeIdentifier] ASC,
	[AuthStatus] ASC,
	[TranTime] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [RD_NC_auth_primary_many2]    Script Date: 5/7/2024 11:51:12 PM ******/
CREATE NONCLUSTERED INDEX [RD_NC_auth_primary_many2] ON [dbo].[Auth_Primary_RPT]
(
	[ProcCode] ASC,
	[PostTime] ASC,
	[TransactionAmount] ASC,
	[POSCountryCode] ASC
)
INCLUDE([TranId],[AccountNumber],[PostingRef],[ResponseCode],[ApprovalCode],[NetworkName],[CardNumber4Digits],[TxnCategory],[CoreAuthTranId],[InstitutionID],[ProductID]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [RD_NC_auth_primary_many3]    Script Date: 5/7/2024 11:51:13 PM ******/
CREATE NONCLUSTERED INDEX [RD_NC_auth_primary_many3] ON [dbo].[Auth_Primary_RPT]
(
	[ProcCode] ASC,
	[ProductID] ASC,
	[PostTime] ASC,
	[TransactionAmount] ASC
)
INCLUDE([TranId],[AccountNumber],[PostingRef],[ResponseCode],[ApprovalCode],[NetworkName],[POSCountryCode],[CardNumber4Digits],[TxnCategory],[CoreAuthTranId],[InstitutionID]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [RD_NC_auth_primary_many4]    Script Date: 5/7/2024 11:51:13 PM ******/
CREATE NONCLUSTERED INDEX [RD_NC_auth_primary_many4] ON [dbo].[Auth_Primary_RPT]
(
	[AccountNumber] ASC,
	[CMTTRANTYPE] ASC,
	[AuthStatus] ASC,
	[TxnCategory] ASC
)
INCLUDE([TranId],[TranTime],[PostTime],[TxnCode_Internal],[TxnSource],[TransactionAmount],[TransmissionDateTime],[TimeLocalTransaction],[MerchantType],[CardAcceptorNameLocation],[TxnSrcAmt],[POSCountryCode],[CoreAuthTranId],[OutstandingAmount],[CardAcceptorIdCode],[MerchantNameandAddress],[SKey]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [RD_NC_Auth_Primary_many5]    Script Date: 5/7/2024 11:51:13 PM ******/
CREATE NONCLUSTERED INDEX [RD_NC_Auth_Primary_many5] ON [dbo].[Auth_Primary_RPT]
(
	[TranId] ASC,
	[TxnSource] ASC,
	[CMTTRANTYPE] ASC,
	[InstitutionID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [RD_NC_Auth_Primary_MessageTypeIdentifier]    Script Date: 5/7/2024 11:51:13 PM ******/
CREATE NONCLUSTERED INDEX [RD_NC_Auth_Primary_MessageTypeIdentifier] ON [dbo].[Auth_Primary_RPT]
(
	[MessageTypeIdentifier] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

/****** Object:  Index [RD_NC_auth_primary_pan_hash]    Script Date: 5/7/2024 11:51:13 PM ******/
CREATE NONCLUSTERED INDEX [RD_NC_auth_primary_pan_hash] ON [dbo].[Auth_Primary_RPT]
(
	[PAN_Hash] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

/****** Object:  Index [RD_NC_Auth_Primary_PostTime]    Script Date: 5/7/2024 11:51:13 PM ******/
CREATE NONCLUSTERED INDEX [RD_NC_Auth_Primary_PostTime] ON [dbo].[Auth_Primary_RPT]
(
	[PostTime] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [rd_nc_auth_primary_posttime,responsemti,responstrantype]    Script Date: 5/7/2024 11:51:13 PM ******/
CREATE NONCLUSTERED INDEX [rd_nc_auth_primary_posttime,responsemti,responstrantype] ON [dbo].[Auth_Primary_RPT]
(
	[PostTime] ASC,
	[ResponseMTI] ASC,
	[ResponseTranType] ASC
)
INCLUDE([TranId],[AccountNumber],[TxnSource],[PrimaryAccountNumber],[TransactionAmount],[MerchantType],[AcquiringInsitutionIDCode],[ResponseCode],[CardAcceptorNameLocation],[TransactionCurrencyCode],[ApprovalCode],[PAN_Hash],[InstitutionID],[ProductID]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [RD_NC_Auth_Primary_PostTime_ProcCode]    Script Date: 5/7/2024 11:51:13 PM ******/
CREATE NONCLUSTERED INDEX [RD_NC_Auth_Primary_PostTime_ProcCode] ON [dbo].[Auth_Primary_RPT]
(
	[PostTime] ASC,
	[ProcCode] ASC
)
INCLUDE([AuthStatus]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [rd_nc_auth_primary_posttime_responsemti_responstrantype]    Script Date: 5/7/2024 11:51:13 PM ******/
CREATE NONCLUSTERED INDEX [rd_nc_auth_primary_posttime_responsemti_responstrantype] ON [dbo].[Auth_Primary_RPT]
(
	[PostTime] ASC,
	[ResponseMTI] ASC,
	[ResponseTranType] ASC
)
INCLUDE([TranId],[AccountNumber],[TxnSource],[PrimaryAccountNumber],[TransactionAmount],[MerchantType],[AcquiringInsitutionIDCode],[ResponseCode],[CardAcceptorNameLocation],[TransactionCurrencyCode],[ApprovalCode],[PAN_Hash],[InstitutionID],[ProductID]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [RD_NC_auth_primary_PrimaryAccountNumber]    Script Date: 5/7/2024 11:51:13 PM ******/
CREATE NONCLUSTERED INDEX [RD_NC_auth_primary_PrimaryAccountNumber] ON [dbo].[Auth_Primary_RPT]
(
	[PrimaryAccountNumber] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [RD_NC_Auth_Primary_ProcCode_PostTime]    Script Date: 5/7/2024 11:51:13 PM ******/
CREATE NONCLUSTERED INDEX [RD_NC_Auth_Primary_ProcCode_PostTime] ON [dbo].[Auth_Primary_RPT]
(
	[ProcCode] ASC,
	[PostTime] ASC
)
INCLUDE([AuthStatus]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

/****** Object:  Index [RD_NC_Auth_Primary_ProductID_PostTime]    Script Date: 5/7/2024 11:51:13 PM ******/
CREATE NONCLUSTERED INDEX [RD_NC_Auth_Primary_ProductID_PostTime] ON [dbo].[Auth_Primary_RPT]
(
	[ProductID] ASC,
	[PostTime] ASC
)
INCLUDE([TranId],[CMTTRANTYPE],[AccountNumber],[PostingRef],[AuthStatus],[ProcCode],[TransactionAmount],[MerchantType],[ResponseCode],[ApprovalCode],[NetworkName],[POSCountryCode],[CardNumber4Digits],[TxnCategory],[MessageTypeIdentifier],[PINExist],[InstitutionID]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [RD_NC_Auth_Primary_RetrievalReferenceNumber]    Script Date: 5/7/2024 11:51:13 PM ******/
CREATE NONCLUSTERED INDEX [RD_NC_Auth_Primary_RetrievalReferenceNumber] ON [dbo].[Auth_Primary_RPT]
(
	[RetrievalReferenceNumber] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

/****** Object:  Index [RD_NC_Auth_Primary_RevTgt]    Script Date: 5/7/2024 11:51:13 PM ******/
CREATE NONCLUSTERED INDEX [RD_NC_Auth_Primary_RevTgt] ON [dbo].[Auth_Primary_RPT]
(
	[RevTgt] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [RD_NC_Auth_Primary_StateStatus_CoreAuthTranId]    Script Date: 5/7/2024 11:51:13 PM ******/
CREATE NONCLUSTERED INDEX [RD_NC_Auth_Primary_StateStatus_CoreAuthTranId] ON [dbo].[Auth_Primary_RPT]
(
	[StateStatus] ASC,
	[CoreAuthTranId] ASC,
	[MessageTypeIdentifier] ASC
)
INCLUDE([TranId],[TransactionLifeCycleUniqueID]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [RD_NC_Auth_Primary_SystemTraceAuditNumber]    Script Date: 5/7/2024 11:51:13 PM ******/
CREATE NONCLUSTERED INDEX [RD_NC_Auth_Primary_SystemTraceAuditNumber] ON [dbo].[Auth_Primary_RPT]
(
	[SystemTraceAuditNumber] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

/****** Object:  Index [RD_NC_auth_primary_tanid]    Script Date: 5/7/2024 11:51:13 PM ******/
CREATE NONCLUSTERED INDEX [RD_NC_auth_primary_tanid] ON [dbo].[Auth_Primary_RPT]
(
	[TranId] ASC
)
INCLUDE([TransactionAmount],[TransactionCurrencyCode]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

/****** Object:  Index [RD_NC_Auth_Primary_TranId]    Script Date: 5/7/2024 11:51:13 PM ******/
CREATE NONCLUSTERED INDEX [RD_NC_Auth_Primary_TranId] ON [dbo].[Auth_Primary_RPT]
(
	[TranId] ASC
)
INCLUDE([MerchantNameandAddress]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [RD_NC_auth_primary_Tranid_Proccode_MerchantType]    Script Date: 5/7/2024 11:51:13 PM ******/
CREATE NONCLUSTERED INDEX [RD_NC_auth_primary_Tranid_Proccode_MerchantType] ON [dbo].[Auth_Primary_RPT]
(
	[TranId] ASC,
	[ProcCode] ASC,
	[MerchantType] ASC
)
INCLUDE([PINExist]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

/****** Object:  Index [RD_NC_Auth_Primary_TranID1]    Script Date: 5/7/2024 11:51:13 PM ******/
CREATE NONCLUSTERED INDEX [RD_NC_Auth_Primary_TranID1] ON [dbo].[Auth_Primary_RPT]
(
	[TranId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

/****** Object:  Index [RD_NC_Auth_Primary_TxnAcctId]    Script Date: 5/7/2024 11:51:13 PM ******/
CREATE NONCLUSTERED INDEX [RD_NC_Auth_Primary_TxnAcctId] ON [dbo].[Auth_Primary_RPT]
(
	[TxnAcctId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [RD_NC_Auth_Primary_TxnID_TxnSource]    Script Date: 5/7/2024 11:51:13 PM ******/
CREATE NONCLUSTERED INDEX [RD_NC_Auth_Primary_TxnID_TxnSource] ON [dbo].[Auth_Primary_RPT]
(
	[SKey] ASC,
	[TranId] ASC,
	[TxnSource] ASC
)
INCLUDE([MessageTypeIdentifier]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [RD_NC_Auth_Primary_TxnSource]    Script Date: 5/7/2024 11:51:13 PM ******/
CREATE NONCLUSTERED INDEX [RD_NC_Auth_Primary_TxnSource] ON [dbo].[Auth_Primary_RPT]
(
	[TxnSource] ASC
)
INCLUDE([TranId],[ProcCode],[MerchantType],[MessageTypeIdentifier]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [RD_NC_Auth_Primary_txnsource_ProductID]    Script Date: 5/7/2024 11:51:13 PM ******/
CREATE NONCLUSTERED INDEX [RD_NC_Auth_Primary_txnsource_ProductID] ON [dbo].[Auth_Primary_RPT]
(
	[TranId] ASC,
	[AccountNumber] ASC,
	[AuthStatus] ASC
)
INCLUDE([PostTime],[PostingRef],[TxnSource],[TransactionAmount],[TransmissionDateTime],[MerchantType],[ResponseCode],[ProductID]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [RD_NC_Auth_Primary1_Many]    Script Date: 5/7/2024 11:51:13 PM ******/
CREATE NONCLUSTERED INDEX [RD_NC_Auth_Primary1_Many] ON [dbo].[Auth_Primary_RPT]
(
	[TxnSource] ASC,
	[CMTTRANTYPE] ASC
)
INCLUDE([TranId]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

/****** Object:  Index [RD_NC_AuthPrimary_InsPosttime]    Script Date: 5/7/2024 11:51:13 PM ******/
CREATE NONCLUSTERED INDEX [RD_NC_AuthPrimary_InsPosttime] ON [dbo].[Auth_Primary_RPT]
(
	[InstitutionID] ASC,
	[PostTime] ASC
)
INCLUDE([TranId],[CMTTRANTYPE],[AccountNumber],[AuthStatus],[PrimaryAccountNumber],[ProcCode],[TransactionAmount],[MerchantType],[AuthorizationResponseCode],[ResponseCode],[TransactionCurrencyCode],[ApprovalCode],[POSCountryCode],[AcquiringInstCountryCode],[TxnCategory],[CoreAuthTranId],[MessageTypeIdentifier],[ProductID],[CardAcceptorIdCode]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

/****** Object:  Index [RD_NC_authPrimary_Tranid]    Script Date: 5/7/2024 11:51:13 PM ******/
CREATE NONCLUSTERED INDEX [RD_NC_authPrimary_Tranid] ON [dbo].[Auth_Primary_RPT]
(
	[TranId] ASC
)
INCLUDE([CMTTRANTYPE],[CardDataEntryMode],[AuthorizationResponseCode],[TransactionCurrencyCode],[ApprovalCode],[CardAcceptorIdCode]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

/****** Object:  Index [RD_NC_AuthPrimary_Tranid_incCurrCodeTxnSrcAmt]    Script Date: 5/7/2024 11:51:13 PM ******/
CREATE NONCLUSTERED INDEX [RD_NC_AuthPrimary_Tranid_incCurrCodeTxnSrcAmt] ON [dbo].[Auth_Primary_RPT]
(
	[TranId] ASC
)
INCLUDE([CMTTRANTYPE],[ATID],[PostingRef],[AuthStatus],[TransactionAmount],[MerchantType],[TransactionCurrencyCode],[TxnSrcAmt],[NetworkName],[POSCountryCode],[TxnCategory],[MessageTypeIdentifier]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [RD_NC_authPrimary_TransactionLifeCycleUniqueID]    Script Date: 5/7/2024 11:51:14 PM ******/
CREATE NONCLUSTERED INDEX [RD_NC_authPrimary_TransactionLifeCycleUniqueID] ON [dbo].[Auth_Primary_RPT]
(
	[TransactionLifeCycleUniqueID] ASC,
	[CMTTRANTYPE] ASC
)
INCLUDE([CardDataEntryMode]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [RD_NC_DBA_Auth_Primary__AuthStatus_PINExist_InstitutionID_ProcCode]    Script Date: 5/7/2024 11:51:14 PM ******/
CREATE NONCLUSTERED INDEX [RD_NC_DBA_Auth_Primary__AuthStatus_PINExist_InstitutionID_ProcCode] ON [dbo].[Auth_Primary_RPT]
(
	[AuthStatus] ASC,
	[PINExist] ASC,
	[InstitutionID] ASC,
	[ProcCode] ASC
)
INCLUDE([TranId],[TranTime],[PostTime],[CMTTRANTYPE],[TxnAcctId],[RevTgt],[StateStatus],[AccountNumber],[TxnCode_Internal],[PostingRef],[TransactionAmount],[MerchantType],[CardDataEntryMode],[ResponseCode],[CalcOTB],[TransactionLifeCycleUniqueID],[ProductID]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [RD_NC_DBA_Auth_Primary__CMTTRANTYPE_TxnSource]    Script Date: 5/7/2024 11:51:14 PM ******/
CREATE NONCLUSTERED INDEX [RD_NC_DBA_Auth_Primary__CMTTRANTYPE_TxnSource] ON [dbo].[Auth_Primary_RPT]
(
	[CMTTRANTYPE] ASC,
	[TxnSource] ASC
)
INCLUDE([TranId]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [RD_NC_DBA_Auth_Primary__PostingRef_InstitutionID_ResponseCode]    Script Date: 5/7/2024 11:51:14 PM ******/
CREATE NONCLUSTERED INDEX [RD_NC_DBA_Auth_Primary__PostingRef_InstitutionID_ResponseCode] ON [dbo].[Auth_Primary_RPT]
(
	[PostingRef] ASC,
	[InstitutionID] ASC,
	[ResponseCode] ASC
)
INCLUDE([UniqueID],[GroupId],[TranId],[TranTime],[PostTime],[CMTTRANTYPE],[TranRef],[TxnAcctId],[ATID],[Reversed],[RevTgt],[StateStatus],[StatementDate],[priority],[AccountNumber],[CPMgroup],[creditplanmaster],[TxnCode_Internal],[PostingFlag],[PostingReason],[BatchAcctId],[RejectBatchAcctId],[ARTxnType],[TxnSource],[PaymentCreditFlag],[AuthStatus],[PrimaryCurrencyCode],[SecondaryCurrencyCode],[TertiaryCurrencyCode],[tranorig],[PrimaryAccountNumber],[ProcCode],[ProcCodeFromAccType],[ProcCodeToAccType],[TransactionAmount],[TransmissionDateTime],[SystemTraceAuditNumber],[TimeLocalTransaction],[DateLocalTransaction],[ExpirationDate],[CaptureDate],[MerchantType],[CardDataEntryMode],[AcquiringInsitutionIDCode],[RetrievalReferenceNumber],[AuthorizationResponseCode],[CardAcceptorTerminalID],[CardAcceptorNameLocation],[TransactionCurrencyCode],[TxnSrcAmt],[ApprovalCode],[OriginalAmount_],[ResponseMTI],[RequestRC],[ResponseTranType],[NetworkName],[FunctionCode],[POSCountryCode],[OriginalDEs],[IResponseCode],[CalcOTB],[PurgeDate],[AcquiringInstCountryCode],[ForwardingInstCountryCode],[AcqTranId],[AuthDecisionControlLog],[CustomerId],[PAN_Hash],[CardNumber4Digits],[TransactionLifeCycleUniqueID],[TxnCategory],[CoreAuthTranId],[MessageIndicator],[OutstandingAmount],[MessageTypeIdentifier],[PINExist],[EffectiveDate_ForAgeOff],[POSTermOpEnv],[PhysicalSource],[ProductID],[ReconciliationIndicator],[EffectiveDate],[AuthMatchedFlag],[PlusChekIndicator],[AVReqOptCode],[CardAcceptorIdCode],[ReconciliationDate],[MerchantNameandAddress],[SKey],[MatchAgedOffPreAuth],[MulCountSeqNo],[BalanceAdjustment],[AuthInitiatingTime],[AuthProcessedTime],[FeeWaiveIndicator],[TxnCode_InternalClr]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [RD_NC_DBA_Auth_Primary__ProductID_PostTime_ResponseMTI_ResponseTranType]    Script Date: 5/7/2024 11:51:14 PM ******/
CREATE NONCLUSTERED INDEX [RD_NC_DBA_Auth_Primary__ProductID_PostTime_ResponseMTI_ResponseTranType] ON [dbo].[Auth_Primary_RPT]
(
	[ProductID] ASC,
	[PostTime] ASC,
	[ResponseMTI] ASC,
	[ResponseTranType] ASC
)
INCLUDE([TranId],[AccountNumber],[TxnSource],[PrimaryAccountNumber],[TransactionAmount],[MerchantType],[AcquiringInsitutionIDCode],[ResponseCode],[CardAcceptorNameLocation],[TransactionCurrencyCode],[ApprovalCode],[PAN_Hash],[InstitutionID]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [RD_NC_DBA_Auth_Primary__TxnSource]    Script Date: 5/7/2024 11:51:15 PM ******/
CREATE NONCLUSTERED INDEX [RD_NC_DBA_Auth_Primary__TxnSource] ON [dbo].[Auth_Primary_RPT]
(
	[TxnSource] ASC,
	[CMTTRANTYPE] ASC
)
INCLUDE([TranId]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [RD_NC_DBA_Auth_Primary__TxnSource_InstitutionID_CMTTRANTYPE]    Script Date: 5/7/2024 11:51:15 PM ******/
CREATE NONCLUSTERED INDEX [RD_NC_DBA_Auth_Primary__TxnSource_InstitutionID_CMTTRANTYPE] ON [dbo].[Auth_Primary_RPT]
(
	[TxnSource] ASC,
	[InstitutionID] ASC,
	[CMTTRANTYPE] ASC
)
INCLUDE([TranId],[AccountNumber],[TransactionAmount]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CI_RPT]([PostTime])
GO
