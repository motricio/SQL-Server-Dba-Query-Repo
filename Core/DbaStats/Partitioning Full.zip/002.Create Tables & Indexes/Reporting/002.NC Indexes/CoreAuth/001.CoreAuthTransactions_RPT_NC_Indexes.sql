USE [CoreauthRPT]
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [dbbidx_dbbidx_IX_CoreAuthTransactions_ApprovalCode]    Script Date: 5/7/2024 10:40:32 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_dbbidx_IX_CoreAuthTransactions_ApprovalCode] ON [dbo].[CoreAuthTransactions_RPT]
(
	[ApprovalCode] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CA]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [dbbidx_dbbidx_IX_CoreAuthTransactions_AuthStatus]    Script Date: 5/7/2024 10:40:32 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_dbbidx_IX_CoreAuthTransactions_AuthStatus] ON [dbo].[CoreAuthTransactions_RPT]
(
	[AuthStatus] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CA]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [dbbidx_dbbidx_IX_CoreAuthTransactions_AuthUniqueID]    Script Date: 5/7/2024 10:40:32 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_dbbidx_IX_CoreAuthTransactions_AuthUniqueID] ON [dbo].[CoreAuthTransactions_RPT]
(
	[AuthUniqueId] ASC,
	[TxnAcctId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CA]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [dbbidx_dbbidx_IX_CoreAuthTransactions_CardNumber4Digits]    Script Date: 5/7/2024 10:40:32 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_dbbidx_IX_CoreAuthTransactions_CardNumber4Digits] ON [dbo].[CoreAuthTransactions_RPT]
(
	[CardNumber4Digits] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CA]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [dbbidx_dbbidx_IX_CoreAuthTransactions_MessageTypeIdentifier]    Script Date: 5/7/2024 10:40:32 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_dbbidx_IX_CoreAuthTransactions_MessageTypeIdentifier] ON [dbo].[CoreAuthTransactions_RPT]
(
	[MessageTypeIdentifier] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CA]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [dbbidx_dbbidx_IX_CoreAuthTransactions_SwitchKeyTxnAcctIDs]    Script Date: 5/7/2024 10:40:32 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_dbbidx_IX_CoreAuthTransactions_SwitchKeyTxnAcctIDs] ON [dbo].[CoreAuthTransactions_RPT]
(
	[SwitchKey] ASC,
	[TxnAcctId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CA]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [dbbidx_dbbidx_IX_CoreAuthTransactions_TxnAcctIDAuthStatus]    Script Date: 5/7/2024 10:40:32 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_dbbidx_IX_CoreAuthTransactions_TxnAcctIDAuthStatus] ON [dbo].[CoreAuthTransactions_RPT]
(
	[TxnAcctId] ASC,
	[AuthStatus] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CA]([PostTime])
GO

/****** Object:  Index [dbx_CAuth_TranID]    Script Date: 5/7/2024 10:40:32 PM ******/
CREATE NONCLUSTERED INDEX [dbx_CAuth_TranID] ON [dbo].[CoreAuthTransactions_RPT]
(
	[TranId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CA]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [idx_CA_PostTime_TxnSource]    Script Date: 5/7/2024 10:40:32 PM ******/
CREATE NONCLUSTERED INDEX [idx_CA_PostTime_TxnSource] ON [dbo].[CoreAuthTransactions_RPT]
(
	[PostTime] ASC,
	[TxnSource] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CA]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [Idx_CoreAuthTransactions_TranId_AuthType]    Script Date: 5/7/2024 10:40:32 PM ******/
CREATE NONCLUSTERED INDEX [Idx_CoreAuthTransactions_TranId_AuthType] ON [dbo].[CoreAuthTransactions_RPT]
(
	[TranId] ASC,
	[AuthType] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CA]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [IDX_DBA_Perf7]    Script Date: 5/7/2024 10:40:32 PM ******/
CREATE NONCLUSTERED INDEX [IDX_DBA_Perf7] ON [dbo].[CoreAuthTransactions_RPT]
(
	[AccountNumber] ASC,
	[TranType] ASC,
	[AuthStatus] ASC,
	[TxnCategory] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CA]([PostTime])
GO

/****** Object:  Index [idx_TxnAcctid_TransmissionDateTime]    Script Date: 5/7/2024 10:40:32 PM ******/
CREATE NONCLUSTERED INDEX [idx_TxnAcctid_TransmissionDateTime] ON [dbo].[CoreAuthTransactions_RPT]
(
	[TxnAcctId] ASC,
	[TransmissionDateTime] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CA]([PostTime])
GO

/****** Object:  Index [idxCoreAuthTran_RevTgt]    Script Date: 5/7/2024 10:40:32 PM ******/
CREATE NONCLUSTERED INDEX [idxCoreAuthTran_RevTgt] ON [dbo].[CoreAuthTransactions_RPT]
(
	[RevTgt] ASC
)
INCLUDE([TranId],[ActualReversalAmount]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CA]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [ix_CAT_AccountNumber]    Script Date: 5/7/2024 10:40:32 PM ******/
CREATE NONCLUSTERED INDEX [ix_CAT_AccountNumber] ON [dbo].[CoreAuthTransactions_RPT]
(
	[AccountNumber] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CA]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [ix_CAT_Stan_txnacct_TDT]    Script Date: 5/7/2024 10:40:32 PM ******/
CREATE NONCLUSTERED INDEX [ix_CAT_Stan_txnacct_TDT] ON [dbo].[CoreAuthTransactions_RPT]
(
	[SystemTraceAuditNumber] ASC,
	[TxnAcctId] ASC,
	[TransmissionDateTime] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CA]([PostTime])
GO

/****** Object:  Index [ix_CAT_TLCUID]    Script Date: 5/7/2024 10:40:32 PM ******/
CREATE NONCLUSTERED INDEX [ix_CAT_TLCUID] ON [dbo].[CoreAuthTransactions_RPT]
(
	[TransactionLifeCycleUniqueID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CA]([PostTime])
GO

/****** Object:  Index [ix_CAT_Txnacct_TTime_Ttype]    Script Date: 5/7/2024 10:40:32 PM ******/
CREATE NONCLUSTERED INDEX [ix_CAT_Txnacct_TTime_Ttype] ON [dbo].[CoreAuthTransactions_RPT]
(
	[TxnAcctId] ASC,
	[TranTime] ASC
)
INCLUDE([AuthStatus],[OutstandingAmount],[TranType],[CompletionAmount],[CashBackAmount],[PartialApprTerminalSprtInd],[CalcOTB],[TransactionAmount],[CrossBorderTxnIndicator],[POSCardPresenceIndicator],[PinExist],[MerchantType],[TxnCategory],[ProcCode],[TerminalType],[PhysicalSource],[TransactionLifeCycleUniqueID],[TranId]) WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CA]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [IX_CoreAuthTransactions_TraceId]    Script Date: 5/7/2024 10:40:33 PM ******/
CREATE NONCLUSTERED INDEX [IX_CoreAuthTransactions_TraceId] ON [dbo].[CoreAuthTransactions_RPT]
(
	[TraceId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CA]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [ix_dbbidx_IX_CoreAuthTransactions_OriginalKey]    Script Date: 5/7/2024 10:40:33 PM ******/
CREATE NONCLUSTERED INDEX [ix_dbbidx_IX_CoreAuthTransactions_OriginalKey] ON [dbo].[CoreAuthTransactions_RPT]
(
	[OriginalKey] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CA]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [ix_dbbidx_IX_CoreAuthTransactions_SwitchKey]    Script Date: 5/7/2024 10:40:33 PM ******/
CREATE NONCLUSTERED INDEX [ix_dbbidx_IX_CoreAuthTransactions_SwitchKey] ON [dbo].[CoreAuthTransactions_RPT]
(
	[SwitchKey] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CA]([PostTime])
GO