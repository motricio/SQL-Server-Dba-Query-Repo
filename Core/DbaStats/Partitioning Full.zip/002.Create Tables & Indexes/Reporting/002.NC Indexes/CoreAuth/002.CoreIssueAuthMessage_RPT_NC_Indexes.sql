USE [CoreauthRPT]
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [dbbidx_IX_dePostTranTime]    Script Date: 5/7/2024 10:49:47 PM ******/
CREATE NONCLUSTERED INDEX [dbbidx_IX_dePostTranTime] ON [dbo].[CoreissueAuthMessage_RPT]
(
	[PostTime] ASC,
	[JobStatus] ASC,
	[AuthType] ASC,
	[TranId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CA]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [idx_CIM_Identity_Jobstatus]    Script Date: 5/7/2024 10:49:47 PM ******/
CREATE NONCLUSTERED INDEX [idx_CIM_Identity_Jobstatus] ON [dbo].[CoreissueAuthMessage_RPT]
(
	[JobStatus] ASC,
	[IdentityField] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CA]([PostTime])
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [idx_CoreISSAuthM_Tranid_auth_Job_N]    Script Date: 5/7/2024 10:49:47 PM ******/
CREATE NONCLUSTERED INDEX [idx_CoreISSAuthM_Tranid_auth_Job_N] ON [dbo].[CoreissueAuthMessage_RPT]
(
	[TranId] ASC,
	[AuthType] ASC,
	[JobStatus] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CA]([PostTime])
GO