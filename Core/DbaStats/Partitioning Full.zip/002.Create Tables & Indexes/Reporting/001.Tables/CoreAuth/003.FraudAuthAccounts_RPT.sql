USE [CoreauthRPT]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[FraudAuthAccounts_RPT](
	[AuthScanID] [decimal](19, 0) IDENTITY(1,1) NOT FOR REPLICATION NOT NULL,
	[TranId] [decimal](19, 0) NULL,
	[AccountNumber] [char](19) NULL,
	[EmbAcctid] [decimal](19, 0) NULL,
	[TransactionAmount] [money] NULL,
	[ProductID] [decimal](19, 0) NULL,
	[AuthTime] [datetime] NOT NULL,
	[CardAcceptorIdCode] [varchar](15) NULL,
	[CardAcceptorTerminalID] [varchar](16) NULL,
	[CardAcceptorNameLocation] [varchar](40) NULL,
	[MerchantName] [varchar](25) NULL,
	[TxnCategory] [varchar](5) NULL,
	[ScanStatus] [tinyint] NULL,
	[BadCVVData] [char](5) NULL,
	[ProcCode] [char](2) NULL,
	[ApprovalCode] [char](6) NULL,
	[InternationalTxn] [char](2) NULL,
	[IncTxnState] [char](3) NULL,
	[IncTxnCountry] [char](3) NULL,
	[CardStatus] [int] NULL,
	[PostingRef] [varchar](1250) NULL,
	[NoOfPinTry] [char](3) NULL,
	[TxnCode_InternalClr] [varchar](20) NULL,
	[TxnCode_Internal] [varchar](8) NULL,
	[FeeWaiveIndicator] [varchar](50) NULL,
	[AuthStatus] [varchar](5) NULL,
	[TranType] [char](16) NULL,
	[TransactionLifeCycleUniqueID] [decimal](19, 0) NULL,
    [RowChangedDate] DATETIME NOT NULL,
	[ChangeVersion] BINARY(8) NULL,
 CONSTRAINT [csPk_FraudAuthAccounts_RPT] PRIMARY KEY CLUSTERED 
(
	[AuthScanID] ASC, [AuthTime] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_INCREMENTAL = ON, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CA]([AuthTime])
) ON [DataPartitionScheme_PROD_CA]([AuthTime])
GO