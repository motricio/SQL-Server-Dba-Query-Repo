USE [CoreauthRPT]
GO

CREATE TABLE [dbo].[CoreissueAuthMessage_RPT](
	[AuthType] [varchar](20) NOT NULL,
	[TranId] [varchar](19) NOT NULL,
	[NetworkSource] [varchar](5) NULL,
	[MessageTypeIdentifierResponse] [char](4) NULL,
	[MsgDummy] [varchar](4) NULL,
	[AuthVarianceException] [char](1) NULL,
	[TranType] [char](16) NULL,
	[EffectiveDate_ForAgeOff] [datetime] NULL,
	[IResponseCode] [varchar](4) NULL,
	[TransactionLifeCycleUniqueID] [varchar](19) NULL,
	[MsgIndicator] [varchar](2) NULL,
	[PurgeDate] [datetime] NULL,
	[MessageTypeIdentifier] [char](4) NULL,
	[TranTypeClr] [char](5) NULL,
	[TxnCategory] [char](4) NULL,
	[TxnCode_Internal] [varchar](9) NULL,
	[TxnCode_InternalClr] [varchar](20) NULL,
	[Authstatus] [varchar](1) NULL,
	[RevTgt] [varchar](19) NULL,
	[calcOTB] [money] NULL,
	[AuthDecisionControlLog] [char](50) NULL,
	[PostingRef] [varchar](100) NULL,
	[ResponseTranType] [varchar](16) NULL,
	[OutstandingAmount] [money] NULL,
	[JobStatus] [varchar](10) NULL,
	[RequestApprovalCode] [char](6) NULL,
	[PostTime] [datetime] NOT NULL,
	[TxnAcctId] [varchar](19) NULL,
	[InvoiceNumber] [char](12) NULL,
	[CurrentBalance] [money] NULL,
	[TotalOutStgAuthAmt] [money] NULL,
	[TransactionAmount] [money] NULL,
	[ReversalAmount] [money] NULL,
	[IdentityField] [decimal](19, 0) IDENTITY(1,1) NOT FOR REPLICATION NOT NULL,
	[BufferAddl] [varchar](8000) NULL,
	[WalletTransaction] [tinyint] NULL,
	[WalletAcctid] [int] NULL,
	[FeeOperation] [varchar](2000) NULL,
	[BufferNew] [varbinary](8000) NULL,
	[MachineName] [varchar](1250) NULL,
	[ExecutedADC] [varchar](1500) NULL,
	[RequestMsgBuffer] [varbinary](8000) NULL,
	[ResponseMsgBuffer] [varbinary](8000) NULL,
	[RowChangedDate] [datetime] NOT NULL,
	[ChangeVersion] [binary](8) NULL,
 CONSTRAINT [csPk_CoreissueAuthMessage_RPT] PRIMARY KEY CLUSTERED 
(
	[IdentityField] ASC, [PostTime] ASC
) WITH (STATISTICS_INCREMENTAL = ON, PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [DataPartitionScheme_PROD_CA]([PostTime])
) ON [DataPartitionScheme_PROD_CA]([PostTime])
GO

