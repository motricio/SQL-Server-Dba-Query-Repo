USE [CoreLibrary]
GO

Exec Sp_Rename	'[CoreLibrary].[dbo].[LoadTransactionDetail].[csPk_LoadTransactionDetail]','csPk_LoadTransactionDetail_Old';
Exec Sp_Rename	'[CoreLibrary].[dbo].[LoadTransactionDetail]','LoadTransactionDetail_Old';
Exec Sp_Rename	'[CoreLibrary].[dbo].[LoadTransactionDetail_New].[csPk_LoadTransactionDetail_New]','csPk_LoadTransactionDetail';
Exec Sp_Rename	'[CoreLibrary].[dbo].[LoadTransactionDetail_New]','LoadTransactionDetail';
GO
/****************************************************************************************************/