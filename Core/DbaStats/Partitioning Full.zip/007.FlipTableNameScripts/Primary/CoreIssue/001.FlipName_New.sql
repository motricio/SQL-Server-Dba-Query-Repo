USE [CoreIssue]
GO

Exec Sp_Rename	'[CoreIssue].[dbo].[LetterInterface].[csPk_LetterInterface]','csPk_LetterInterface_Old';
Exec Sp_Rename	'[CoreIssue].[dbo].[LetterInterface]','LetterInterface_Old';
Exec Sp_Rename	'[CoreIssue].[dbo].[LetterInterface_New].[csPk_LetterInterface_New]','csPk_LetterInterface';
Exec Sp_Rename	'[CoreIssue].[dbo].[LetterInterface_New]','LetterInterface';
GO
/****************************************************************************************************/
Exec Sp_Rename	'[CoreIssue].[dbo].[GLPostingTransactions].[csPk_GLPostingTransactions]','csPk_GLPostingTransactions_Old';
Exec Sp_Rename	'[CoreIssue].[dbo].[GLPostingTransactions]','GLPostingTransactions_Old';
Exec Sp_Rename	'[CoreIssue].[dbo].[GLPostingTransactions_New].[csPk_GLPostingTransactions_New]','csPk_GLPostingTransactions';
Exec Sp_Rename	'[CoreIssue].[dbo].[GLPostingTransactions_New]','GLPostingTransactions';
GO
/****************************************************************************************************/
Exec Sp_Rename	'[CoreIssue].[dbo].[Auth_Primary].[csPk_Auth_Primary]','csPk_Auth_Primary_Old';
Exec Sp_Rename	'[CoreIssue].[dbo].[Auth_Primary]','Auth_Primary_Old';
Exec Sp_Rename	'[CoreIssue].[dbo].[Auth_Primary_New].[csPk_Auth_Primary_New]','csPk_Auth_Primary';
Exec Sp_Rename	'[CoreIssue].[dbo].[Auth_Primary_New]','Auth_Primary';
GO
/****************************************************************************************************/
Exec Sp_Rename	'[CoreIssue].[dbo].[CCard_Primary].[csPk_CCard_Primary]','csPk_CCard_Primary_Old';
Exec Sp_Rename	'[CoreIssue].[dbo].[CCard_Primary]','CCard_Primary_Old';
Exec Sp_Rename	'[CoreIssue].[dbo].[CCard_Primary_New].[csPk_CCard_Primary_New]','csPk_CCard_Primary';
Exec Sp_Rename	'[CoreIssue].[dbo].[CCard_Primary_New]','CCard_Primary';
GO
/****************************************************************************************************/