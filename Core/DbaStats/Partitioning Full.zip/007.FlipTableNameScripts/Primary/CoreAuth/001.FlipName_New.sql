USE [CoreAuth]
GO

Exec Sp_Rename	'[CoreAuth].[dbo].[CoreAuthTransactions].[csPk_CoreAuthTransactions]','csPk_CoreAuthTransactions_Old';
Exec Sp_Rename	'[CoreAuth].[dbo].[CoreAuthTransactions]','CoreAuthTransactions_Old';
Exec Sp_Rename	'[CoreAuth].[dbo].[CoreAuthTransactions_New].[csPk_CoreAuthTransactions_New]','csPk_CoreAuthTransactions';
Exec Sp_Rename	'[CoreAuth].[dbo].[CoreAuthTransactions_New]','CoreAuthTransactions';
GO
/****************************************************************************************************/
Exec Sp_Rename	'[CoreAuth].[dbo].[CoreissueAuthMessage].[csPk_CoreissueAuthMessage]','csPk_CoreissueAuthMessage_Old';
Exec Sp_Rename	'[CoreAuth].[dbo].[CoreissueAuthMessage]','CoreissueAuthMessage_Old';
Exec Sp_Rename	'[CoreAuth].[dbo].[CoreissueAuthMessage_New].[csPk_CoreissueAuthMessage_New]','csPk_CoreissueAuthMessage';
Exec Sp_Rename	'[CoreAuth].[dbo].[CoreissueAuthMessage_New]','CoreissueAuthMessage';
GO
/****************************************************************************************************/
Exec Sp_Rename	'[CoreAuth].[dbo].[FraudAuthAccounts].[csPk_FraudAuthAccounts]','csPk_FraudAuthAccounts_Old';
Exec Sp_Rename	'[CoreAuth].[dbo].[FraudAuthAccounts]','FraudAuthAccounts_Old';
Exec Sp_Rename	'[CoreAuth].[dbo].[FraudAuthAccounts_New].[csPk_FraudAuthAccounts_New]','csPk_FraudAuthAccounts';
Exec Sp_Rename	'[CoreAuth].[dbo].[FraudAuthAccounts_New]','FraudAuthAccounts';
GO
/****************************************************************************************************/
Exec Sp_Rename	'[CoreAuth].[dbo].[NetworkMessage].[csPk_NetworkMessage]','csPk_NetworkMessage_Old';
Exec Sp_Rename	'[CoreAuth].[dbo].[NetworkMessage]','NetworkMessage_Old';
Exec Sp_Rename	'[CoreAuth].[dbo].[NetworkMessage_New].[csPk_NetworkMessage_New]','csPk_NetworkMessage';
Exec Sp_Rename	'[CoreAuth].[dbo].[NetworkMessage_New]','NetworkMessage';
GO
/****************************************************************************************************/