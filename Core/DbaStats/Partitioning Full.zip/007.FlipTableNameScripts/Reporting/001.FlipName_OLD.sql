USE [CoreIssueRPT]
GO

Exec Sp_Rename	'[CoreIssueRPT].[dbo].[GLPostingTransactions].[csPk_GLPostingTransactions]','csPk_GLPostingTransactions_Old';
Exec Sp_Rename	'[CoreIssueRPT].[dbo].[GLPostingTransactions]','GLPostingTransactions_Old';
Exec Sp_Rename	'[CoreIssueRPT].[dbo].[GLPostingTransactions_RPT].[csPk_GLPostingTransactions_RPT]','csPk_GLPostingTransactions';
Exec Sp_Rename	'[CoreIssueRPT].[dbo].[GLPostingTransactions_RPT]','GLPostingTransactions';