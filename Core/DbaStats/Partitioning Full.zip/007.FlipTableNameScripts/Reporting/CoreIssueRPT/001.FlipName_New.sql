USE [CoreIssueRPT]
GO

Exec Sp_Rename	'[CoreIssueRPT].[dbo].[LetterInterface].[csPk_LetterInterface]','csPk_LetterInterface_Old';
Exec Sp_Rename	'[CoreIssueRPT].[dbo].[LetterInterface]','LetterInterface_Old';
Exec Sp_Rename	'[CoreIssueRPT].[dbo].[LetterInterface_RPT].[csPk_LetterInterface_RPT]','csPk_LetterInterface';
Exec Sp_Rename	'[CoreIssueRPT].[dbo].[LetterInterface_RPT]','LetterInterface';
GO
/****************************************************************************************************/
Exec Sp_Rename	'[CoreIssueRPT].[dbo].[GLPostingTransactions].[csPk_GLPostingTransactions]','csPk_GLPostingTransactions_Old';
Exec Sp_Rename	'[CoreIssueRPT].[dbo].[GLPostingTransactions]','GLPostingTransactions_Old';
Exec Sp_Rename	'[CoreIssueRPT].[dbo].[GLPostingTransactions_RPT].[csPk_GLPostingTransactions_RPT]','csPk_GLPostingTransactions';
Exec Sp_Rename	'[CoreIssueRPT].[dbo].[GLPostingTransactions_RPT]','GLPostingTransactions';
GO
/****************************************************************************************************/
Exec Sp_Rename	'[CoreIssueRPT].[dbo].[Auth_Primary].[csPk_Auth_Primary]','csPk_Auth_Primary_Old';
Exec Sp_Rename	'[CoreIssueRPT].[dbo].[Auth_Primary]','Auth_Primary_Old';
Exec Sp_Rename	'[CoreIssueRPT].[dbo].[Auth_Primary_RPT].[csPk_Auth_Primary_RPT]','csPk_Auth_Primary';
Exec Sp_Rename	'[CoreIssueRPT].[dbo].[Auth_Primary_RPT]','Auth_Primary';
GO
/****************************************************************************************************/
Exec Sp_Rename	'[CoreIssueRPT].[dbo].[CCard_Primary].[csPk_CCard_Primary]','csPk_CCard_Primary_Old';
Exec Sp_Rename	'[CoreIssueRPT].[dbo].[CCard_Primary]','CCard_Primary_Old';
Exec Sp_Rename	'[CoreIssueRPT].[dbo].[CCard_Primary_RPT].[csPk_CCard_Primary_RPT]','csPk_CCard_Primary';
Exec Sp_Rename	'[CoreIssueRPT].[dbo].[CCard_Primary_RPT]','CCard_Primary';
GO
/****************************************************************************************************/