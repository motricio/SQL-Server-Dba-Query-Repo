USE [CoreAuthRPT]
GO

Exec Sp_Rename	'[CoreAuthRPT].[dbo].[CoreAuthTransactions].[csPk_CoreAuthTransactions]','csPk_CoreAuthTransactions_Old';
Exec Sp_Rename	'[CoreAuthRPT].[dbo].[CoreAuthTransactions]','CoreAuthTransactions_Old';
Exec Sp_Rename	'[CoreAuthRPT].[dbo].[CoreAuthTransactions_RPT].[csPk_CoreAuthTransactions_RPT]','csPk_CoreAuthTransactions';
Exec Sp_Rename	'[CoreAuthRPT].[dbo].[CoreAuthTransactions_RPT]','CoreAuthTransactions';
GO
/****************************************************************************************************/
Exec Sp_Rename	'[CoreAuthRPT].[dbo].[CoreissueAuthMessage].[csPk_CoreissueAuthMessage]','csPk_CoreissueAuthMessage_Old';
Exec Sp_Rename	'[CoreAuthRPT].[dbo].[CoreissueAuthMessage]','CoreissueAuthMessage_Old';
Exec Sp_Rename	'[CoreAuthRPT].[dbo].[CoreissueAuthMessage_RPT].[csPk_CoreissueAuthMessage_RPT]','csPk_CoreissueAuthMessage';
Exec Sp_Rename	'[CoreAuthRPT].[dbo].[CoreissueAuthMessage_RPT]','CoreissueAuthMessage';
GO
/****************************************************************************************************/
Exec Sp_Rename	'[CoreAuthRPT].[dbo].[FraudAuthAccounts].[csPk_FraudAuthAccounts]','csPk_FraudAuthAccounts_Old';
Exec Sp_Rename	'[CoreAuthRPT].[dbo].[FraudAuthAccounts]','FraudAuthAccounts_Old';
Exec Sp_Rename	'[CoreAuthRPT].[dbo].[FraudAuthAccounts_RPT].[csPk_FraudAuthAccounts_RPT]','csPk_FraudAuthAccounts';
Exec Sp_Rename	'[CoreAuthRPT].[dbo].[FraudAuthAccounts_RPT]','FraudAuthAccounts';
GO
/****************************************************************************************************/