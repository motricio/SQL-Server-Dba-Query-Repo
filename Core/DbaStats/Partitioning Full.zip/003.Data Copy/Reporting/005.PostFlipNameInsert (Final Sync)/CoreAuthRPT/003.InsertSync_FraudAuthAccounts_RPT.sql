---Insert Sync For FraudAuthAccounts
USE [CoreAuthRPT]

SET IDENTITY_INSERT CoreAuthRPT.dbo.FraudAuthAccounts ON

INSERT INTO CoreAuthRPT.dbo.FraudAuthAccounts
([AuthScanID],[TranId],[AccountNumber],[EmbAcctid],[TransactionAmount],[ProductID],[AuthTime],[CardAcceptorIdCode],[CardAcceptorTerminalID],[CardAcceptorNameLocation],[MerchantName],[TxnCategory],[ScanStatus],[BadCVVData],[ProcCode],[ApprovalCode],[InternationalTxn],[IncTxnState],[IncTxnCountry],[CardStatus],[PostingRef],[NoOfPinTry],[TxnCode_InternalClr],[TxnCode_Internal],[FeeWaiveIndicator],[AuthStatus],[TranType],[TransactionLifeCycleUniqueID],[RowChangedDate])
SELECT 
FAA.[AuthScanID],FAA.[TranId],FAA.[AccountNumber],FAA.[EmbAcctid],FAA.[TransactionAmount],FAA.[ProductID],FAA.[AuthTime],FAA.[CardAcceptorIdCode],FAA.[CardAcceptorTerminalID],FAA.[CardAcceptorNameLocation],FAA.[MerchantName],FAA.[TxnCategory],FAA.[ScanStatus],FAA.[BadCVVData],FAA.[ProcCode],FAA.[ApprovalCode],FAA.[InternationalTxn],FAA.[IncTxnState],FAA.[IncTxnCountry],FAA.[CardStatus],FAA.[PostingRef],FAA.[NoOfPinTry],FAA.[TxnCode_InternalClr],FAA.[TxnCode_Internal],FAA.[FeeWaiveIndicator],FAA.[AuthStatus],FAA.[TranType],FAA.[TransactionLifeCycleUniqueID],FAA.[AuthTime] as RowChangedDate
FROM CoreAuthRPT.dbo.FraudAuthAccounts_OLD FAA WITH(NOLOCK) 
LEFT JOIN CoreAuthRPT.dbo.FraudAuthAccounts CN ON (FAA.AuthScanID = CN.AuthScanID 
AND FAA.AuthTime = CN.AuthTime)
WHERE 
FAA.AuthTime > '2024-01-22 23:59:57.000' /*DATE MUST BE CHANGED BY FLIP TABLE NAME EXECUTION DATE*/
AND CN.AuthScanID IS NULL AND CN.AuthTime IS NULL

SET IDENTITY_INSERT CoreAuthRPT.dbo.FraudAuthAccounts OFF