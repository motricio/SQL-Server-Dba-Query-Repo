---Insert Sync For CoreissueAuthMessage
USE [CoreAuthRPT]

INSERT INTO CoreAuthRPT.dbo.CoreissueAuthMessage 
([AuthType],[TranId],[NetworkSource],[MessageTypeIdentifierResponse],[MsgDummy],[AuthVarianceException],[TranType],[EffectiveDate_ForAgeOff],[IResponseCode],[TransactionLifeCycleUniqueID],[MsgIndicator],[PurgeDate],[MessageTypeIdentifier],[TranTypeClr],[TxnCategory],[TxnCode_Internal],[TxnCode_InternalClr],[Authstatus],[RevTgt],[calcOTB],[AuthDecisionControlLog],[PostingRef],[ResponseTranType],[OutstandingAmount],[JobStatus],[RequestApprovalCode],[PostTime],[TxnAcctId],[InvoiceNumber],[CurrentBalance],[TotalOutStgAuthAmt],[TransactionAmount],[ReversalAmount],[BufferAddl],[WalletTransaction],[WalletAcctid],[FeeOperation],[BufferNew],[MachineName],[ExecutedADC],[RequestMsgBuffer],[ResponseMsgBuffer],[RowChangedDate])    			
SELECT
CAM.AuthType,CAM.TranId,CAM.NetworkSource,CAM.MessageTypeIdentifierResponse,CAM.MsgDummy,CAM.AuthVarianceException,CAM.TranType,CAM.EffectiveDate_ForAgeOff,CAM.IResponseCode,CAM.TransactionLifeCycleUniqueID,CAM.MsgIndicator,CAM.PurgeDate,CAM.MessageTypeIdentifier,CAM.TranTypeClr,CAM.TxnCategory,CAM.TxnCode_Internal,CAM.TxnCode_InternalClr,CAM.Authstatus,CAM.RevTgt,CAM.calcOTB,CAM.AuthDecisionControlLog,CAM.PostingRef,CAM.ResponseTranType,CAM.OutstandingAmount,CAM.JobStatus,CAM.RequestApprovalCode,CAM.PostTime,CAM.TxnAcctId,CAM.InvoiceNumber,CAM.CurrentBalance,CAM.TotalOutStgAuthAmt,CAM.TransactionAmount,CAM.ReversalAmount,CAM.BufferAddl,CAM.WalletTransaction,CAM.WalletAcctid,CAM.FeeOperation,CAM.BufferNew,CAM.MachineName,CAM.ExecutedADC,CAM.RequestMsgBuffer,CAM.ResponseMsgBuffer, CAM.PostTime as RowChangedDate
FROM CoreAuthRPT.dbo.CoreissueAuthMessage_OLD CAM WITH(NOLOCK) 
LEFT JOIN CoreAuthRPT.dbo.CoreissueAuthMessage CN ON (CAM.IdentityField = CN.IdentityField AND CAM.PostTime = CN.PostTime)
WHERE 
CAM.PostTime > '2024-10-22 23:59:57.000' /*DATE MUST BE CHANGED BY FLIP TABLE NAME EXECUTION DATE*/
AND CN.IdentityField IS NULL
AND CN.PostTime IS NULL