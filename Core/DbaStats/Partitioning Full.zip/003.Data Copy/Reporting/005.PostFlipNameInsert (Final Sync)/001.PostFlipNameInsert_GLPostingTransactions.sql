USE [CoreIssueRPT]

drop table if exists #GLPostingTransactions
drop table if exists #GLDuplicates

SELECT GL.TranId, GL.[PostTime]
into #GLPostingTransactions
FROM CoreIssueRPT.dbo.GLPostingTransactions GL WITH(NOLOCK)
WHERE GL.[PostTime]> '2024-01-22 23:59:57.000'

SELECT TranId, [PostTime]
into #GLDuplicates
FROM #GLPostingTransactions
group by TranId, [PostTime]
having count (*) >1

INSERT INTO Admin.dbo.dba_Partition_Duplicates_RPT_Control(TranId, [table], [PostTime])
SELECT T.TranId, 'GLPostingTransactions', T.[PostTime]
FROM #GLDuplicates T LEFT JOIN Admin.dbo.dba_Partition_Duplicates_RPT_Control D ON T.TranId = D.TranId AND T.PostTime = D.PostTime
WHERE 
D.TranId IS NULL
AND D.PostTime IS NULL
AND D.[TABLE] IS NULL

DELETE T
FROM #GLPostingTransactions T INNER JOIN Admin.dbo.dba_Partition_Duplicates_RPT_Control D ON T.TranId = D.TranId AND T.PostTime = D.PostTime
WHERE D.[table] = 'GLPostingTransactions'

SET IDENTITY_INSERT GLPostingTransactions ON    

INSERT INTO GLPostingTransactions ([Skey], [AccountNumber], [BaseAcctid], [WalletAcctID], [TxnAcctId], [TranId], [AuthTranId], [TransactionLifeCycleUniqueID], [GLExternalTranRefNumber], [PostTime], [TransmissionDateTime], [SettlementDate], [TransactionAmount], [TransactionCurrencyCode], [SettlementAmount], [SettlementCurrencyCode], [MessageTypeIdentifier], [TxnSource], [CMTTRANTYPE], [MTCGrpName], [TransactionCode], [ActualTranCode], [GLGroupID], [DebitGL], [DebitGL_Currency], [CreditGL], [CreditGL_Currency], [DebitGL_Settlement], [DebitGL_Settlement_Currency], [CreditGL_Settlement], [CreditGL_Settlement_Currency], [ExchangeRate], [GLProductID], [InstitutionId], [TransactionsLogTime], [SweepStatus], [Reversed], [Authstatus], [TransactionDescription], [PeriodDateTime], [PostingFlag], [ProcCode], [SrcIdentifier], [CardNumber4Digits], [RevTgt], [ReimbursementFee_11], [FreeFormTextJapan], [RowCreatedDate], [RowChangedDate])

SELECT GL.[Skey], GL.[AccountNumber], GL.[BaseAcctid], GL.[WalletAcctID], GL.[TxnAcctId], GL.[TranId], GL.[AuthTranId], GL.[TransactionLifeCycleUniqueID], GL.[GLExternalTranRefNumber], GL.[PostTime], GL.[TransmissionDateTime], GL.[SettlementDate], GL.[TransactionAmount], GL.[TransactionCurrencyCode], GL.[SettlementAmount], GL.[SettlementCurrencyCode], GL.[MessageTypeIdentifier], GL.[TxnSource], GL.[CMTTRANTYPE], GL.[MTCGrpName], GL.[TransactionCode], GL.[ActualTranCode], GL.[GLGroupID], GL.[DebitGL], GL.[DebitGL_Currency], GL.[CreditGL], GL.[CreditGL_Currency], GL.[DebitGL_Settlement], GL.[DebitGL_Settlement_Currency], GL.[CreditGL_Settlement], GL.[CreditGL_Settlement_Currency], GL.[ExchangeRate], GL.[GLProductID], GL.[InstitutionId], GL.[TransactionsLogTime], GL.[SweepStatus], GL.[Reversed], GL.[Authstatus], GL.[TransactionDescription], GL.[PeriodDateTime], GL.[PostingFlag], GL.[ProcCode], GL.[SrcIdentifier], GL.[CardNumber4Digits], GL.[RevTgt], GL.[ReimbursementFee_11], GL.[FreeFormTextJapan],GL.[PostTime], GL.[PostTime]
FROM GLPostingTransactions_OLD GL WITH(NOLOCK) INNER JOIN #GLPostingTransactions CP WITH(NOLOCK) ON (GL.tranid = CP.TranId AND GL.PostTime = CP.PostTime) 
LEFT JOIN GLPostingTransactions CN ON (GL.TranId = CN.TranId AND GL.PostTime = CN.PostTime)
WHERE 
CN.TranId IS NULL
AND CN.PostTime IS NULL

SET IDENTITY_INSERT GLPostingTransactions Off 