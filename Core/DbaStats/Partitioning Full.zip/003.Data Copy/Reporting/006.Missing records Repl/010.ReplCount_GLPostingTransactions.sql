--MUST BE EXECUTED ON REPORTING SIDE
SELECT GLPostingTransactions_PrimarySide FROM OPENQUERY ([CCAZE1PROD1], 'SELECT DISTINCT COUNT(*) AS GLPostingTransactions_PrimarySide FROM CoreIssue.dbo.GLPostingTransactions WITH(NOLOCK) GROUP BY [TranId], [RowCreatedDate]'); 
union all 
SELECT DISTINCT COUNT(*) AS GLPostingTransactions_ReportingSide FROM CoreIssueRPT.dbo.GLPostingTransactions WITH(NOLOCK) GROUP BY [TranId], [RowCreatedDate]