USE [CoreIssueRPT]
GO

--Auth_Primary_OLD
select 'Auth_Primary_OLD' as [Table], count(TranId) as [RowCount] FROM Auth_Primary_OLD WITH(NOLOCK) WHERE PostTime > '2021-12-31 23:59:57.000' 
UNION ALL
select 'Auth_Primary' as [Table], count(TranId) as [RowCount] from Auth_Primary  WITH(NOLOCK)