USE [CoreIssueRPT]
GO

--LetterInterface_OLD
select 'LetterInterface_OLD' as [Table], count(LetterID) as [RowCount] FROM LetterInterface_OLD WITH(NOLOCK) WHERE LetterDraftedDate > '2022-03-31 23:59:57.000' 
UNION ALL
select 'LetterInterface' as [Table], count(LetterID) as [RowCount] from LetterInterface WITH(NOLOCK)