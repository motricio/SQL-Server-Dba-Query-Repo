USE [CoreissueRPT]

--GLPostingTransactions
select 'GLPostingTransactions_OLD' as [Table], count(Skey) as [RowCount] FROM GLPostingTransactions_OLD WITH(NOLOCK) WHERE PostTime > '2022-03-31 23:59:57.000' 
UNION ALL
select 'GLPostingTransactions' as [Table], count(Skey) as [RowCount] from GLPostingTransactions  WITH(NOLOCK)