USE [CoreAuthRPT]
GO

--FraudAuthAccounts_OLD
select 'FraudAuthAccounts_OLD' as [Table], count(AuthScanID) as [RowCount] FROM FraudAuthAccounts_OLD WITH(NOLOCK) WHERE AuthTime > '2022-03-31 23:59:57.000' 
UNION ALL
select 'FraudAuthAccounts' as [Table], count(AuthScanID) as [RowCount] from FraudAuthAccounts WITH(NOLOCK)