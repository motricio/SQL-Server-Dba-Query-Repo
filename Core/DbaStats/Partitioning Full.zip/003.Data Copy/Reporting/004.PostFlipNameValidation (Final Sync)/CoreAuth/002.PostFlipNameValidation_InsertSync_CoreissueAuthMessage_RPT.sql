USE [CoreAuthRPT]
GO

--CoreissueAuthMessage_OLD
select 'CoreissueAuthMessage_OLD' as [Table], count(IdentityField) as [RowCount] FROM CoreissueAuthMessage_OLD WITH(NOLOCK) WHERE Posttime > '2022-03-31 23:59:57.000' 
UNION ALL
select 'CoreissueAuthMessage' as [Table], count(IdentityField) as [RowCount] from CoreissueAuthMessage  WITH(NOLOCK)
