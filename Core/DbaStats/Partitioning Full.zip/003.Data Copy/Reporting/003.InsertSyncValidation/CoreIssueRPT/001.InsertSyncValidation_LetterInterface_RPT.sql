USE [CoreIssueRPT]
GO

--LetterInterface_RPT
select 'LetterInterface' as [Table], count(LetterID) as [RowCount] FROM LetterInterface FRP WITH(NOLOCK) WHERE FRP.LetterDraftedDate > '2022-03-31 23:59:57.000' 
UNION ALL
select 'LetterInterface_RPT' as [Table], count(LetterID) as [RowCount] from LetterInterface_RPT WITH(NOLOCK)