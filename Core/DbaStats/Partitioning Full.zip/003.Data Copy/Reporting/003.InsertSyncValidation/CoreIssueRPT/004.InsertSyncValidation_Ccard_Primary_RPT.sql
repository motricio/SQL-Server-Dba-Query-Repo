USE [CoreIssueRPT]
GO

--Ccard_Primary_RPT
select 'Ccard_Primary' as [Table], count(TranId) as [RowCount] FROM Ccard_Primary FRP WITH(NOLOCK) WHERE FRP.PostTime > '2021-12-31 23:59:57.000' 
UNION ALL
select 'Ccard_Primary_RPT' as [Table], count(TranId) as [RowCount] 
from Ccard_Primary_RPT  WITH(NOLOCK)