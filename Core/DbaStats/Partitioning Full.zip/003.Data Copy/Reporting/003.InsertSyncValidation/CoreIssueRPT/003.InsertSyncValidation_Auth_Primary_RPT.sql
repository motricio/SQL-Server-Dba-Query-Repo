USE [CoreIssueRPT]
GO

--Auth_Primary_RPT
select 'Auth_Primary' as [Table], count(TranId) as [RowCount] FROM Auth_Primary FRP WITH(NOLOCK) WHERE FRP.PostTime > '2021-12-31 23:59:57.000' 
UNION ALL
select 'Auth_Primary_RPT' as [Table], count(TranId) as [RowCount] 
from Auth_Primary_RPT  WITH(NOLOCK)
