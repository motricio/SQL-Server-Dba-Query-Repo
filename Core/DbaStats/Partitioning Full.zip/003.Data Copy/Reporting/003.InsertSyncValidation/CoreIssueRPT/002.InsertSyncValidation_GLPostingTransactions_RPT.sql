USE [CoreissueRPT]

--GLPostingTransactions
select 'GLPostingTransactions' as [Table], count(Skey) as [RowCount] FROM GLPostingTransactions FRP WITH(NOLOCK) WHERE FRP.PostTime > '2022-03-31 23:59:57.000' 
UNION ALL
select 'GLPostingTransactions_RPT' as [Table], count(Skey) as [RowCount] from GLPostingTransactions_RPT  WITH(NOLOCK)


--GLPostingTransactions
--select 'Duplicates' as [Duplicates],count (Skey) as [RowCount] from GLPostingTransactions where --TranId in (SELECT DISTINCT TranId from Admin.dbo.dba_Partition_Duplicates_Control where [table] = --'GLPostingTransactions')
--UNION ALL
--select 'GLPostingTransactions' as [Table], count(Skey) as [RowCount] from GLPostingTransactions --WITH(NOLOCK) where [PostTime] > '2021-12-31 23:59:57.000'
--UNION ALL
--SELECT 'GLPostingTransactions_New' as [Table], count(*) as [RowCount] from --GLPostingTransactions_New  WITH(NOLOCK)