USE [CoreAuthRPT]
GO

--CoreAuthTransactions_RPT
select 'CoreAuthTransactions' as [Table], count(IdentityField) as [RowCount] FROM CoreAuthTransactions FRP WITH(NOLOCK) WHERE FRP.Posttime > '2022-03-31 23:59:57.000' 
UNION ALL
select 'CoreAuthTransactions_RPT' as [Table], count(IdentityField) as [RowCount] from CoreAuthTransactions_RPT  WITH(NOLOCK)