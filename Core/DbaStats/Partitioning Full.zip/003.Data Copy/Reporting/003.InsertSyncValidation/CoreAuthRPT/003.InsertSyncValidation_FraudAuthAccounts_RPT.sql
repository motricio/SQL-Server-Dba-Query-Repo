USE [CoreAuthRPT]
GO

--FraudAuthAccounts_RPT
select 'FraudAuthAccounts' as [Table], count(AuthScanID) as [RowCount] FROM FraudAuthAccounts FRP WITH(NOLOCK) WHERE FRP.Authtime > '2022-03-31 23:59:57.000' 
UNION ALL
select 'FraudAuthAccounts_RPT' as [Table], count(AuthScanID) as [RowCount] from FraudAuthAccounts_RPT WITH(NOLOCK)