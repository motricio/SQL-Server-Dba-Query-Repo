USE [CoreissueRPT]

--GLPostingTransactions
select 'Duplicates' as [Duplicates],count (Skey) as [RowCount] from GLPostingTransactions where TranId in (SELECT DISTINCT TranId from Admin.dbo.dba_Partition_Duplicates_RPT_Control where [table] = 'GLPostingTransactions')
UNION ALL
select 'GLPostingTransactions' as [Table], count(GL.Skey) as [RowCount] from GLPostingTransactions GL WITH(NOLOCK) where [PostTime] > '2021-12-31 23:59:57.000' 
UNION ALL
SELECT 'GLPostingTransactions_RPT' as [Table], count(*) as [RowCount] from GLPostingTransactions_RPT  WITH(NOLOCK)