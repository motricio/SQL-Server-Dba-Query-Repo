---Insert Sync For FraudAuthAccounts_New
USE [CoreAuthRPT]

drop table if exists #FraudAuthAccounts

SELECT FAAT.[AuthScanID], FAAT.[AuthTime]
into #FraudAuthAccounts
FROM CoreAuthRPT24.dbo.FraudAuthAccounts FAAT WITH(NOLOCK)
WHERE FAAT.[AuthTime]> '2024-10-06 23:59:57.000'

SET IDENTITY_INSERT CoreAuthRPT24.dbo.FraudAuthAccounts_RPT ON
INSERT INTO CoreAuthRPT24.dbo.FraudAuthAccounts_RPT 
([AuthScanID],[TranId],[AccountNumber],[EmbAcctid],[TransactionAmount],[ProductID],[AuthTime],[CardAcceptorIdCode],[CardAcceptorTerminalID],[CardAcceptorNameLocation],[MerchantName],[TxnCategory],[ScanStatus],[BadCVVData],[ProcCode],[ApprovalCode],[InternationalTxn],[IncTxnState],[IncTxnCountry],[CardStatus],[PostingRef],[NoOfPinTry],[TxnCode_InternalClr],[TxnCode_Internal],[FeeWaiveIndicator],[AuthStatus],[TranType],[TransactionLifeCycleUniqueID],[RowChangedDate])
SELECT 
FAA.[AuthScanID],FAA.[TranId],FAA.[AccountNumber],FAA.[EmbAcctid],FAA.[TransactionAmount],FAA.[ProductID],FAA.[AuthTime],FAA.[CardAcceptorIdCode],FAA.[CardAcceptorTerminalID],FAA.[CardAcceptorNameLocation],FAA.[MerchantName],FAA.[TxnCategory],FAA.[ScanStatus],FAA.[BadCVVData],FAA.[ProcCode],FAA.[ApprovalCode],FAA.[InternationalTxn],FAA.[IncTxnState],FAA.[IncTxnCountry],FAA.[CardStatus],FAA.[PostingRef],FAA.[NoOfPinTry],FAA.[TxnCode_InternalClr],FAA.[TxnCode_Internal],FAA.[FeeWaiveIndicator],FAA.[AuthStatus],FAA.[TranType],FAA.[TransactionLifeCycleUniqueID],FAA.[AuthTime] as RowChangedDate
FROM  CoreAuthRPT24.dbo.FraudAuthAccounts FAA WITH(NOLOCK) 
INNER JOIN #FraudAuthAccounts CP WITH(NOLOCK) ON (FAA.[AuthScanID] = CP.[AuthScanID] AND FAA.AuthTime = CP.AuthTime) 
LEFT JOIN CoreAuthRPT24.dbo.FraudAuthAccounts_RPT CN ON (FAA.[AuthScanID] = CN.[AuthScanID] AND FAA.AuthTime = CN.AuthTime)
where 
FAA.[AuthScanID] IS NULL AND FAA.[AuthTime] IS NULL
SET IDENTITY_INSERT CoreAuthRPT24.dbo.FraudAuthAccounts_RPT OFF