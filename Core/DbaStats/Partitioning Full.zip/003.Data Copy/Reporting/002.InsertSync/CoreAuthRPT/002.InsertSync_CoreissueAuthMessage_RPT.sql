---Insert Sync For CoreissueAuthMessage_RPT
USE [CoreAuthRPT]

drop table if exists #CoreissueAuthMessage

SELECT CAMT.[IdentityField], CAMT.[PostTime]
into #CoreissueAuthMessage
FROM CoreAuthRPT.dbo.CoreissueAuthMessage CAMT WITH(NOLOCK)
WHERE CAMT.[PostTime]> '2024-01-06 23:59:57.000'

INSERT INTO CoreAuthRPT.dbo.CoreissueAuthMessage_RPT 
([AuthType],[TranId],[NetworkSource],[MessageTypeIdentifierResponse],[MsgDummy],[AuthVarianceException],[TranType],[EffectiveDate_ForAgeOff],[IResponseCode],[TransactionLifeCycleUniqueID],[MsgIndicator],[PurgeDate],[MessageTypeIdentifier],[TranTypeClr],[TxnCategory],[TxnCode_Internal],[TxnCode_InternalClr],[Authstatus],[RevTgt],[calcOTB],[AuthDecisionControlLog],[PostingRef],[ResponseTranType],[OutstandingAmount],[JobStatus],[RequestApprovalCode],[PostTime],[TxnAcctId],[InvoiceNumber],[CurrentBalance],[TotalOutStgAuthAmt],[TransactionAmount],[ReversalAmount],[BufferAddl],[WalletTransaction],[WalletAcctid],[FeeOperation],[BufferNew],[MachineName],[ExecutedADC],[RequestMsgBuffer],[ResponseMsgBuffer],[RowChangedDate])    			
SELECT
CAM.AuthType,CAM.TranId,CAM.NetworkSource,CAM.MessageTypeIdentifierResponse,CAM.MsgDummy,CAM.AuthVarianceException,CAM.TranType,CAM.EffectiveDate_ForAgeOff,CAM.IResponseCode,CAM.TransactionLifeCycleUniqueID,CAM.MsgIndicator,CAM.PurgeDate,CAM.MessageTypeIdentifier,CAM.TranTypeClr,CAM.TxnCategory,CAM.TxnCode_Internal,CAM.TxnCode_InternalClr,CAM.Authstatus,CAM.RevTgt,CAM.calcOTB,CAM.AuthDecisionControlLog,CAM.PostingRef,CAM.ResponseTranType,CAM.OutstandingAmount,CAM.JobStatus,CAM.RequestApprovalCode,CAM.PostTime,CAM.TxnAcctId,CAM.InvoiceNumber,CAM.CurrentBalance,CAM.TotalOutStgAuthAmt,CAM.TransactionAmount,CAM.ReversalAmount,CAM.BufferAddl,CAM.WalletTransaction,CAM.WalletAcctid,CAM.FeeOperation,CAM.BufferNew,CAM.MachineName,CAM.ExecutedADC,CAM.RequestMsgBuffer,CAM.ResponseMsgBuffer, CAM.PostTime as RowChangedDate
FROM CoreAuthRPT.dbo.CoreissueAuthMessage CAM WITH(NOLOCK) 
INNER JOIN #CoreissueAuthMessage CAMT WITH(NOLOCK) ON (CAM.[IdentityField] = CAMT.[IdentityField] 
AND CAM.PostTime = CAMT.PostTime) 
LEFT JOIN CoreAuthRPT.dbo.CoreissueAuthMessage_RPT CN ON (CAM.TranId = CN.TranId 
AND CAM.PostTime = CN.PostTime)
WHERE 
CN.TranId IS NULL
AND CN.PostTime IS NULL