---Insert Sync For GLPostingTransactions_RPT
USE [CoreIssueRPT]

drop table if exists #GLPostingTransactions

SELECT 
GL.Skey, GL.[PostTime]
into #GLPostingTransactions
FROM CoreIssueRPT.dbo.GLPostingTransactions GL WITH(NOLOCK)
WHERE GL.[PostTime]> '2023-01-01 23:59:59.999'

SET IDENTITY_INSERT CoreIssueRPT.dbo.GLPostingTransactions_RPT ON                  

INSERT INTO CoreIssueRPT.dbo.GLPostingTransactions_RPT 
([Skey], [AccountNumber], [BaseAcctid], [WalletAcctID], [TxnAcctId], [TranId], [AuthTranId], [TransactionLifeCycleUniqueID], [GLExternalTranRefNumber], [PostTime], [TransmissionDateTime], [SettlementDate], [TransactionAmount], [TransactionCurrencyCode], [SettlementAmount], [SettlementCurrencyCode], [MessageTypeIdentifier], [TxnSource], [CMTTRANTYPE], [MTCGrpName], [TransactionCode], [ActualTranCode], [GLGroupID], [DebitGL], [DebitGL_Currency], [CreditGL], [CreditGL_Currency], [DebitGL_Settlement], [DebitGL_Settlement_Currency], [CreditGL_Settlement], [CreditGL_Settlement_Currency], [ExchangeRate], [GLProductID], [InstitutionId], [TransactionsLogTime], [SweepStatus], [Reversed], [Authstatus], [TransactionDescription], [PeriodDateTime], [PostingFlag], [ProcCode], [SrcIdentifier], [CardNumber4Digits], [RevTgt], [ReimbursementFee_11], [FreeFormTextJapan], [RowCreatedDate], [RowChangedDate])
SELECT 
GLPT.[Skey], GLPT.[AccountNumber], GLPT.[BaseAcctid], GLPT.[WalletAcctID], GLPT.[TxnAcctId], GLPT.[TranId], GLPT.[AuthTranId], GLPT.[TransactionLifeCycleUniqueID], GLPT.[GLExternalTranRefNumber], GLPT.[PostTime], GLPT.[TransmissionDateTime], GLPT.[SettlementDate], GLPT.[TransactionAmount], GLPT.[TransactionCurrencyCode], GLPT.[SettlementAmount], GLPT.[SettlementCurrencyCode], GLPT.[MessageTypeIdentifier], GLPT.[TxnSource], GLPT.[CMTTRANTYPE], GLPT.[MTCGrpName], GLPT.[TransactionCode], GLPT.[ActualTranCode], GLPT.[GLGroupID], GLPT.[DebitGL], GLPT.[DebitGL_Currency], GLPT.[CreditGL], GLPT.[CreditGL_Currency], GLPT.[DebitGL_Settlement], GLPT.[DebitGL_Settlement_Currency], GLPT.[CreditGL_Settlement], GLPT.[CreditGL_Settlement_Currency], GLPT.[ExchangeRate], GLPT.[GLProductID], GLPT.[InstitutionId], GLPT.[TransactionsLogTime], GLPT.[SweepStatus], GLPT.[Reversed], GLPT.[Authstatus], GLPT.[TransactionDescription], GLPT.[PeriodDateTime], GLPT.[PostingFlag], GLPTGL.[ProcCode], GLPT.[SrcIdentifier], GLPT.[CardNumber4Digits], GLPT.[RevTgt], GLPT.[ReimbursementFee_11], GLPT.[FreeFormTextJapan],GLPT.[PostTime], GLPT.[PostTime]
FROM CoreIssueRPT.dbo.GLPostingTransactions GLPT WITH(NOLOCK) 
INNER JOIN #GLPostingTransactions CP WITH(NOLOCK) ON (GLPT.Skey = CP.Skey 
AND GLPT.PostTime = CP.PostTime) 
LEFT JOIN CoreIssueRPT.dbo.GLPostingTransactions_RPT CN ON GLPT.Skey = CN.Skey 
AND GLPT.PostTime = CN.PostTime
WHERE CN.Skey IS NULL AND CN.PostTime IS NULL

SET IDENTITY_INSERT CoreIssueRPT.dbo.GLPostingTransactions_RPT OFF     
