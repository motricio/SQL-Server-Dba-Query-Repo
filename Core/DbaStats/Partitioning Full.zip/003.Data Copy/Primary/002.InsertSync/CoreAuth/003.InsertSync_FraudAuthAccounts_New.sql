--Insert Sync For FraudAuthAccounts_New
USE [CoreAuth]

drop table if exists #FraudAuthAccounts

SELECT FAA.[AuthScanID], FAA.[AuthTime]
into #FraudAuthAccounts
FROM CoreAuthdbo.FraudAuthAccounts FAA WITH(NOLOCK)
WHERE FAA.[AuthTime]> '2024-01-06 23:59:57.000'

SET IDENTITY_INSERT CoreAuthdbo.FraudAuthAccounts_New ON
INSERT INTO CoreAuthdbo.FraudAuthAccounts_New 
([AuthScanID],[TranId],[AccountNumber],[EmbAcctid],[TransactionAmount],[ProductID],[AuthTime],[CardAcceptorIdCode],[CardAcceptorTerminalID],[CardAcceptorNameLocation],[MerchantName],[TxnCategory],[ScanStatus],[BadCVVData],[ProcCode],[ApprovalCode],[InternationalTxn],[IncTxnState],[IncTxnCountry],[CardStatus],[PostingRef],[NoOfPinTry],[TxnCode_InternalClr],[TxnCode_Internal],[FeeWaiveIndicator],[AuthStatus],[TranType],[TransactionLifeCycleUniqueID],[RowChangedDate])
SELECT 
FAA.[AuthScanID],FAA.[TranId],FAA.[AccountNumber],FAA.[EmbAcctid],FAA.[TransactionAmount],FAA.[ProductID],FAA.[AuthTime],FAA.[CardAcceptorIdCode],FAA.[CardAcceptorTerminalID],FAA.[CardAcceptorNameLocation],FAA.[MerchantName],FAA.[TxnCategory],FAA.[ScanStatus],FAA.[BadCVVData],FAA.[ProcCode],FAA.[ApprovalCode],FAA.[InternationalTxn],FAA.[IncTxnState],FAA.[IncTxnCountry],FAA.[CardStatus],FAA.[PostingRef],FAA.[NoOfPinTry],FAA.[TxnCode_InternalClr],FAA.[TxnCode_Internal],FAA.[FeeWaiveIndicator],FAA.[AuthStatus],FAA.[TranType],FAA.[TransactionLifeCycleUniqueID],FAA.[AuthTime] as RowChangedDate
FROM  CoreAuthdbo.FraudAuthAccounts FAA WITH(NOLOCK) 
INNER JOIN #FraudAuthAccounts CP WITH(NOLOCK) ON (FAA.[AuthScanID] = CP.[AuthScanID] AND FAA.AuthTime = CP.AuthTime) 
LEFT JOIN CoreAuthdbo.FraudAuthAccounts_New CN ON (FAA.TranId = CN.TranId AND FAA.AuthTime = CN.AuthTime)
SET IDENTITY_INSERT CoreAuthdbo.FraudAuthAccounts_New OFF 