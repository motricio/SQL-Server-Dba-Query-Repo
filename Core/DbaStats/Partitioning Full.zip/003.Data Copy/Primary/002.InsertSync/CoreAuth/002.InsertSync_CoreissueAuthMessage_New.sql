---Insert Sync For CoreissueAuthMessage_New
USE [CoreAuth]

drop table if exists #CoreissueAuthMessage

SELECT CAM.[IdentityField], CAM.[PostTime]
into #CoreissueAuthMessage
FROM CoreAuth.dbo.CoreissueAuthMessage CAM WITH(NOLOCK)
WHERE CAM.[PostTime]> '2024-01-06 23:59:57.000'

INSERT INTO CoreAuth.dbo.CoreissueAuthMessage_New 
([AuthType],[TranId],[NetworkSource],[MessageTypeIdentifierResponse],[MsgDummy],[Buffer],[AuthVarianceException],[TranType],[EffectiveDate_ForAgeOff],[IResponseCode],[TransactionLifeCycleUniqueID],[MsgIndicator],[PurgeDate],[MessageTypeIdentifier],[TranTypeClr],[TxnCategory],[TxnCode_Internal],[TxnCode_InternalClr],[Authstatus],[RevTgt],[calcOTB],[AuthDecisionControlLog],[PostingRef],[ResponseTranType],[OutstandingAmount],[JobStatus],[RequestApprovalCode],[PostTime],[TxnAcctId],[InvoiceNumber],[CurrentBalance],[TotalOutStgAuthAmt],[TransactionAmount],[ReversalAmount],[BufferAddl],[WalletTransaction],[WalletAcctid],[FeeOperation],[BufferNew],[MachineName],[ExecutedADC],[RequestMsgBuffer],[ResponseMsgBuffer])     			
SELECT
CAM.AuthType,CAM.TranId,CAM.NetworkSource,CAM.MessageTypeIdentifierResponse,CAM.MsgDummy,CAM.Buffer,CAM.AuthVarianceException,CAM.TranType,CAM.EffectiveDate_ForAgeOff,CAM.IResponseCode,CAM.TransactionLifeCycleUniqueID,CAM.MsgIndicator,CAM.PurgeDate,CAM.MessageTypeIdentifier,CAM.TranTypeClr,CAM.TxnCategory,CAM.TxnCode_Internal,CAM.TxnCode_InternalClr,CAM.Authstatus,CAM.RevTgt,CAM.calcOTB,CAM.AuthDecisionControlLog,CAM.PostingRef,CAM.ResponseTranType,CAM.OutstandingAmount,CAM.JobStatus,CAM.RequestApprovalCode,CAM.PostTime,CAM.TxnAcctId,CAM.InvoiceNumber,CAM.CurrentBalance,CAM.TotalOutStgAuthAmt,CAM.TransactionAmount,CAM.ReversalAmount,CAM.BufferAddl,CAM.WalletTransaction,CAM.WalletAcctid,CAM.FeeOperation,CAM.BufferNew,CAM.MachineName,CAM.ExecutedADC,CAM.RequestMsgBuffer,CAM.ResponseMsgBuffer
FROM CoreAuth.dbo.CoreissueAuthMessage CAM WITH(NOLOCK) 
INNER JOIN #CoreissueAuthMessage CP WITH(NOLOCK) ON (CAM.[IdentityField] = CP.[IdentityField] AND CAM.PostTime = CP.PostTime) 
LEFT JOIN CoreAuth.dbo.CoreissueAuthMessage_New CN ON (CAM.TranId = CN.TranId AND CAM.PostTime = CN.PostTime)
WHERE 
CN.TranId IS NULL
AND CN.PostTime IS NULL