---Insert Sync For LoadTransactionDetail_New 
USE [CoreIssue]

SET IDENTITY_INSERT LoadTransactionDetail_New  ON 

INSERT INTO LoadTransactionDetail_New ([Skey], [TranTime], [PostTime], [TranId], [TxnAcctId], [ATID], [CMTTRANTYPE], [TransactionAmount], [AccountNumber], [PrimaryAccountNumber], [PAN_Hash], [PrimaryCurrencyCode], [BillingCurrencyCode], [TransactionCurrencyCode], [TxnSource], [SrcIdentifier], [AdminPortalMobileSharing], [Reversed], [RevTGT], [ProductID], [InstituteID], [ArTxnType], [ExhangeRate], [MarkupRate], [PostingFlag], [PostingRef], [MemoIndicator], [EmbossingAID], [RowCreatedDate],[RowChangedDate])

SELECT LT.[Skey], LT.[TranTime], LT.[PostTime], LT.[TranId], LT.[TxnAcctId], LT.[ATID], LT.[CMTTRANTYPE], LT.[TransactionAmount], LT.[AccountNumber], LT.[PrimaryAccountNumber], LT.[PAN_Hash], LT.[PrimaryCurrencyCode], LT.[BillingCurrencyCode], LT.[TransactionCurrencyCode], LT.[TxnSource], LT.[SrcIdentifier], LT.[AdminPortalMobileSharing], LT.[Reversed], LT.[RevTGT], LT.[ProductID], LT.[InstituteID], LT.[ArTxnType], LT.[ExhangeRate], LT.[MarkupRate], LT.[PostingFlag], LT.[PostingRef], LT.[MemoIndicator], LT.[EmbossingAID], LT.[PostTime] AS RowCreatedDate, 
LT.[PostTime] AS RowChangedDate
FROM LoadTransactionDetail LT WITH(NOLOCK)
where  LT.[PostTime] > '2022-03-31 23:59:57.000'

SET IDENTITY_INSERT LoadTransactionDetail_New Off