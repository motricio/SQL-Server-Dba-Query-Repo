USE [CoreIssue]
GO

--LetterInterface
select 'LetterInterface' as [Table], count(LetterID) as [RowCount] FROM LetterInterface FRP WITH(NOLOCK) WHERE FRP.LetterDraftedDate > '2022-03-31 23:59:57.000' 
UNION ALL
select 'LetterInterface_New' as [Table], count(LetterID) as [RowCount] from LetterInterface_New  WITH(NOLOCK)