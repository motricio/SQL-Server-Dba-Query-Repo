USE [CoreAuth]
GO

--NetworkMessage
select 'NetworkMessage' as [Table], count(UniqueID) as [RowCount] FROM NetworkMessage FRP WITH(NOLOCK) WHERE FRP.Posttime > '2022-03-31 23:59:57.000' 
UNION ALL
select 'NetworkMessage_New' as [Table], count(UniqueID) as [RowCount] from NetworkMessage_New  WITH(NOLOCK)
