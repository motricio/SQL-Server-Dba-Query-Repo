USE [CoreAuth]
GO

--FraudAuthAccounts
select 'FraudAuthAccounts' as [Table], count(IdentityField) as [RowCount] FROM FraudAuthAccounts FRP WITH(NOLOCK) WHERE FRP.Posttime > '2022-03-31 23:59:57.000' 
UNION ALL
select 'FraudAuthAccounts_New' as [Table], count(IdentityField) as [RowCount] from FraudAuthAccounts_New  WITH(NOLOCK)