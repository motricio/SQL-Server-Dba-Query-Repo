---Insert Sync For GLPostingTransactions
USE [CoreIssue]

--drop table if exists #GLPostingTransactions
--SELECT GL.Skey, GL.[PostTime]
--into #GLPostingTransactions
--FROM CoreIssue22.dbo.GLPostingTransactions GL WITH(NOLOCK)
--WHERE GL.[PostTime]> '2023-01-01 23:59:59.999'

SET IDENTITY_INSERT CoreIssue.dbo.GLPostingTransactions ON                  

INSERT INTO CoreIssue.dbo.GLPostingTransactions ([Skey], [AccountNumber], [BaseAcctid], [WalletAcctID], [TxnAcctId], [TranId], [AuthTranId], [TransactionLifeCycleUniqueID], [GLExternalTranRefNumber], [PostTime], [TransmissionDateTime], [SettlementDate], [TransactionAmount], [TransactionCurrencyCode], [SettlementAmount], [SettlementCurrencyCode], [MessageTypeIdentifier], [TxnSource], [CMTTRANTYPE], [MTCGrpName], [TransactionCode], [ActualTranCode], [GLGroupID], [DebitGL], [DebitGL_Currency], [CreditGL], [CreditGL_Currency], [DebitGL_Settlement], [DebitGL_Settlement_Currency], [CreditGL_Settlement], [CreditGL_Settlement_Currency], [ExchangeRate], [GLProductID], [InstitutionId], [TransactionsLogTime], [SweepStatus], [Reversed], [Authstatus], [TransactionDescription], [PeriodDateTime], [PostingFlag], [ProcCode], [SrcIdentifier], [CardNumber4Digits], [RevTgt], [ReimbursementFee_11], [FreeFormTextJapan], [RowCreatedDate], [RowChangedDate])
SELECT GL.[Skey], GL.[AccountNumber], GL.[BaseAcctid], GL.[WalletAcctID], GL.[TxnAcctId], GL.[TranId], GL.[AuthTranId], GL.[TransactionLifeCycleUniqueID], GL.[GLExternalTranRefNumber], GL.[PostTime], GL.[TransmissionDateTime], GL.[SettlementDate], GL.[TransactionAmount], GL.[TransactionCurrencyCode], GL.[SettlementAmount], GL.[SettlementCurrencyCode], GL.[MessageTypeIdentifier], GL.[TxnSource], GL.[CMTTRANTYPE], GL.[MTCGrpName], GL.[TransactionCode], GL.[ActualTranCode], GL.[GLGroupID], GL.[DebitGL], GL.[DebitGL_Currency], GL.[CreditGL], GL.[CreditGL_Currency], GL.[DebitGL_Settlement], GL.[DebitGL_Settlement_Currency], GL.[CreditGL_Settlement], GL.[CreditGL_Settlement_Currency], GL.[ExchangeRate], GL.[GLProductID], GL.[InstitutionId], GL.[TransactionsLogTime], GL.[SweepStatus], GL.[Reversed], GL.[Authstatus], GL.[TransactionDescription], GL.[PeriodDateTime], GL.[PostingFlag], GL.[ProcCode], GL.[SrcIdentifier], GL.[CardNumber4Digits], GL.[RevTgt], GL.[ReimbursementFee_11], GL.[FreeFormTextJapan],GL.[PostTime], GL.[PostTime]
FROM CoreIssue.dbo.GLPostingTransactions_OLD GL WITH(NOLOCK) 
LEFT JOIN CoreIssue.dbo.GLPostingTransactions CN ON (GL.Skey = CN.Skey 
AND GL.PostTime = CN.PostTime)
WHERE 
GL.PostTime > '2024-01-22 23:59:57.000' /*DATE MUST BE CHANGED BY FLIP TABLE NAME EXECUTION DATE*/
AND CN.Skey IS NULL
AND CN.PostTime IS NULL

SET IDENTITY_INSERT CoreIssue22.dbo.GLPostingTransactions OFF     

