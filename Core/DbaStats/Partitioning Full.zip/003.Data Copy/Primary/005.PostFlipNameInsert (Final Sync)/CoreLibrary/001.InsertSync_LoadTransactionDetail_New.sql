---Insert Sync For LoadTransactionDetail
USE [CoreLibrary]

SET IDENTITY_INSERT CoreLibrary.dbo.LoadTransactionDetail  ON 

INSERT INTO CoreLibrary.dbo.LoadTransactionDetail ([Skey], [TranTime], [PostTime], [TranId], [TxnAcctId], [ATID], [CMTTRANTYPE], [TransactionAmount], [AccountNumber], [PrimaryAccountNumber], [PAN_Hash], [PrimaryCurrencyCode], [BillingCurrencyCode], [TransactionCurrencyCode], [TxnSource], [SrcIdentifier], [AdminPortalMobileSharing], [Reversed], [RevTGT], [ProductID], [InstituteID], [ArTxnType], [ExhangeRate], [MarkupRate], [PostingFlag], [PostingRef], [MemoIndicator], [EmbossingAID], [RowCreatedDate],[RowChangedDate])
SELECT 
LT.[Skey], LT.[TranTime], LT.[PostTime], LT.[TranId], LT.[TxnAcctId], LT.[ATID], LT.[CMTTRANTYPE], LT.[TransactionAmount], LT.[AccountNumber], LT.[PrimaryAccountNumber], LT.[PAN_Hash], LT.[PrimaryCurrencyCode], LT.[BillingCurrencyCode], LT.[TransactionCurrencyCode], LT.[TxnSource], LT.[SrcIdentifier], LT.[AdminPortalMobileSharing], LT.[Reversed], LT.[RevTGT], LT.[ProductID], LT.[InstituteID], LT.[ArTxnType], LT.[ExhangeRate], LT.[MarkupRate], LT.[PostingFlag], LT.[PostingRef], LT.[MemoIndicator], LT.[EmbossingAID], LT.[PostTime] AS RowCreatedDate, 
LT.[PostTime] AS RowChangedDate
FROM CoreLibrary.dbo.LoadTransactionDetail_OLD LT WITH(NOLOCK) 
LEFT JOIN CoreLibrary.dbo.LoadTransactionDetail CN ON (LT.TranId = CN.TranId AND LT.RowCreatedDate = CN.RowCreatedDate)
WHERE 
LT.RowCreatedDate > '2024-01-22 23:59:57.000' /*DATE MUST BE CHANGED BY FLIP TABLE NAME EXECUTION DATE*/
AND CN.TranId IS NULL
AND CN.RowCreatedDate IS NULL

SET IDENTITY_INSERT CoreLibrary.dbo.LoadTransactionDetail Off 
