---Insert Sync For CoreissueAuthMessage
USE [CoreAuth]

--drop table if exists #CoreissueAuthMessage
--SELECT CAM.[IdentityField], CAM.[PostTime]
--into #CoreissueAuthMessage
--FROM CoreAuth.dbo.CoreissueAuthMessage CAM WITH(NOLOCK)
--WHERE CAM.[PostTime]> '2024-01-06 23:59:57.000'

SET IDENTITY_INSERT CoreAuth.dbo.CoreissueAuthMessage ON

INSERT INTO CoreAuth.dbo.CoreissueAuthMessage 
([AuthType],[TranId],[NetworkSource],[MessageTypeIdentifierResponse],[MsgDummy],[Buffer],[AuthVarianceException],[TranType],[EffectiveDate_ForAgeOff],[IResponseCode],[TransactionLifeCycleUniqueID],[MsgIndicator],[PurgeDate],[MessageTypeIdentifier],[TranTypeClr],[TxnCategory],[TxnCode_Internal],[TxnCode_InternalClr],[Authstatus],[RevTgt],[calcOTB],[AuthDecisionControlLog],[PostingRef],[ResponseTranType],[OutstandingAmount],[JobStatus],[RequestApprovalCode],[PostTime],[TxnAcctId],[InvoiceNumber],[CurrentBalance],[TotalOutStgAuthAmt],[TransactionAmount],[ReversalAmount],[BufferAddl],[WalletTransaction],[WalletAcctid],[FeeOperation],[BufferNew],[MachineName],[ExecutedADC],[RequestMsgBuffer],[ResponseMsgBuffer])     			
SELECT
CAM.AuthType,CAM.TranId,CAM.NetworkSource,CAM.MessageTypeIdentifierResponse,CAM.MsgDummy,CAM.Buffer,CAM.AuthVarianceException,CAM.TranType,CAM.EffectiveDate_ForAgeOff,CAM.IResponseCode,CAM.TransactionLifeCycleUniqueID,CAM.MsgIndicator,CAM.PurgeDate,CAM.MessageTypeIdentifier,CAM.TranTypeClr,CAM.TxnCategory,CAM.TxnCode_Internal,CAM.TxnCode_InternalClr,CAM.Authstatus,CAM.RevTgt,CAM.calcOTB,CAM.AuthDecisionControlLog,CAM.PostingRef,CAM.ResponseTranType,CAM.OutstandingAmount,CAM.JobStatus,CAM.RequestApprovalCode,CAM.PostTime,CAM.TxnAcctId,CAM.InvoiceNumber,CAM.CurrentBalance,CAM.TotalOutStgAuthAmt,CAM.TransactionAmount,CAM.ReversalAmount,CAM.BufferAddl,CAM.WalletTransaction,CAM.WalletAcctid,CAM.FeeOperation,CAM.BufferNew,CAM.MachineName,CAM.ExecutedADC,CAM.RequestMsgBuffer,CAM.ResponseMsgBuffer
FROM CoreAuth.dbo.CoreissueAuthMessage_OLD CAM WITH(NOLOCK) 
LEFT JOIN CoreAuth.dbo.CoreissueAuthMessage CN ON (CAM.IdentityField = CN.IdentityField 
AND CAM.PostTime = CN.PostTime)
WHERE 
CAM.PostTime > '2024-01-22 23:59:57.000' /*DATE MUST BE CHANGED BY FLIP TABLE NAME EXECUTION DATE*/
AND CN.IdentityField IS NULL
AND CN.PostTime IS NULL

SET IDENTITY_INSERT CoreAuth.dbo.CoreissueAuthMessage OFF

