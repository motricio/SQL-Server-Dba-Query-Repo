---Insert Sync For NetworkMessage
USE [CoreAuth]

SET IDENTITY_INSERT CoreAuth.dbo.NetworkMessage ON 

INSERT INTO CoreAuth.dbo.NetworkMessage ([MessageTypeIdentifier],[PrimaryAccountNumber],[TransmissionDateTime],[SystemTraceAuditNumber],[ForwardingInsitutionIDCode],[ResponseCode],[AdditionalResponseDataW],[KeyClassIDTK],[KeyIndexNumber],[KeyCycleNumber],[TheFinancialNetworkCode],[NetworkReferenceNumber],[BankNetReferenceNumber],[Acquirerreferencenumber],[GCMSProcDateCycleNum],[NetworkMgmtInfoCode],[MessageSecurityCode],[PrivateData126],[PrivateUse127],[PAN_Hash],[AVSResponse],[CIDResonse],[SourceofAuth],[StandinLimit],[FieldinError],[AddresschangeNoti],[AcquiringInsitutionIDCode],[RetrievalReferenceNumber],[TransportData],[ReceivingInstIDCode],[VersionNumber],[EffectiveYear],[ReleaseNumber],[SecRelControlInfo],[NetwrkMgmtInfoCode],[MDSPrivateData2],[FraudRiskInd],[FraudScore],[CurrencyIndicator],[CrossBorderIndicator],[MDSPrivateData1],[SettlementServiceData],[InterchangeRateIndicator],[InfoTextConnex124W],[IPAddress],[PhysicalSource],[UniqueID],[PostTime],[AuthType],[EmbAcctID],[KeyNetworkID],[KCV],[SourceMachineName],[SinkMachineName],[RowChangedDate])
SELECT 
NM.[MessageTypeIdentifier],NM.[PrimaryAccountNumber],NM.[TransmissionDateTime],NM.[SystemTraceAuditNumber],NM.[ForwardingInsitutionIDCode],NM.[ResponseCode],NM.[AdditionalResponseDataW],NM.[KeyClassIDTK],NM.[KeyIndexNumber],NM.[KeyCycleNumber],NM.[TheFinancialNetworkCode],NM.[NetworkReferenceNumber],NM.[BankNetReferenceNumber],NM.[Acquirerreferencenumber],NM.[GCMSProcDateCycleNum],NM.[NetworkMgmtInfoCode],NM.[MessageSecurityCode],NM.[PrivateData126],NM.[PrivateUse127],NM.[PAN_Hash],NM.[AVSResponse],NM.[CIDResonse],NM.[SourceofAuth],NM.[StandinLimit],NM.[FieldinError],NM.[AddresschangeNoti],NM.[AcquiringInsitutionIDCode],NM.[RetrievalReferenceNumber],NM.[TransportData],NM.[ReceivingInstIDCode],NM.[VersionNumber],NM.[EffectiveYear],NM.[ReleaseNumber],NM.[SecRelControlInfo],NM.[NetwrkMgmtInfoCode],NM.[MDSPrivateData2],NM.[FraudRiskInd],NM.[FraudScore],NM.[CurrencyIndicator],NM.[CrossBorderIndicator],NM.[MDSPrivateData1],NM.[SettlementServiceData],NM.[InterchangeRateIndicator],NM.[InfoTextConnex124W],NM.[IPAddress],NM.[PhysicalSource],NM.[UniqueID],NM.[PostTime],NM.[AuthType],NM.[EmbAcctID],NM.[KeyNetworkID],NM.[KCV],NM.[SourceMachineName],NM.[SinkMachineName],NM.[PostTime]
FROM CoreAuth.dbo.NetworkMessage_OLD NM WITH(NOLOCK) 
LEFT JOIN CoreAuth.dbo.NetworkMessage CN ON (NM.UniqueID = CN.UniqueID 
AND NM.PostTime = CN.PostTime)
WHERE 
NM.PostTime > '2024-01-22 23:59:57.000' /*DATE MUST BE CHANGED BY FLIP TABLE NAME EXECUTION DATE*/
AND CN.UniqueID IS NULL
AND CN.PostTime IS NULL

SET IDENTITY_INSERT CoreAuth.dbo.NetworkMessage Off 
