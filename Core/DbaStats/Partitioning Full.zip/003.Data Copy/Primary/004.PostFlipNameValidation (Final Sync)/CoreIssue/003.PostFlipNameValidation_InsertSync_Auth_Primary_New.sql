USE [CoreIssue]
GO

--Auth_Primary
select 'Auth_Primary_Old' as [Table], count(TranId) as [RowCount] FROM Auth_Primary_Old FRP WITH(NOLOCK) WHERE PostTime > '2021-12-31 23:59:57.000' 
UNION ALL
select 'Auth_Primary' as [Table], count(TranId) as [RowCount] from Auth_Primary  WITH(NOLOCK)