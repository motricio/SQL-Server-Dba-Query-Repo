USE [Coreissue]

--LetterInterface

UNION ALL
select 'LetterInterface_OLD' as [Table], count(LetterId) as [RowCount] from LetterInterface_OLD WITH(NOLOCK) where [PostTime] > '2021-12-31 23:59:57.000'
UNION ALL
SELECT 'LetterInterface' as [Table], count(LetterId) as [RowCount] from LetterInterface  WITH(NOLOCK)