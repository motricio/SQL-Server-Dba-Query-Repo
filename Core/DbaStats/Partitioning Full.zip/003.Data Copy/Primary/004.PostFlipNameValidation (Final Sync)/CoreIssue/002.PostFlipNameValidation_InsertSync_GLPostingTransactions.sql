USE [Coreissue]

--GLPostingTransactions
select 'GLPostingTransactions_Old' as [Table], count(Skey) as [RowCount] FROM GLPostingTransactions_Old WITH(NOLOCK) WHERE PostTime > '2022-03-31 23:59:57.000' 
UNION ALL
select 'GLPostingTransactions' as [Table], count(Skey) as [RowCount] from GLPostingTransactions_NEw  WITH(NOLOCK)