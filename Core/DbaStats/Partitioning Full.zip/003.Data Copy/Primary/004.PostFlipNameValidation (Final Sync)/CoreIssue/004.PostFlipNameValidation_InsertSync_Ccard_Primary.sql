USE [CoreIssue]
GO

--Ccard_Primary
select 'Ccard_Primary_Old' as [Table], count(TranId) as [RowCount] FROM Ccard_Primary_Old  WITH(NOLOCK) WHERE PostTime > '2021-12-31 23:59:57.000' 
UNION ALL
select 'Ccard_Primary' as [Table], count(TranId) as [RowCount] from Ccard_Primary  WITH(NOLOCK)