USE [CoreAuth]
GO

--FraudAuthAccounts
select 'FraudAuthAccounts_Old' as [Table], count(IdentityField) as [RowCount] FROM FraudAuthAccounts_Old WITH(NOLOCK) WHERE Posttime > '2022-03-31 23:59:57.000' 
UNION ALL
select 'FraudAuthAccounts' as [Table], count(IdentityField) as [RowCount] from FraudAuthAccounts  WITH(NOLOCK)