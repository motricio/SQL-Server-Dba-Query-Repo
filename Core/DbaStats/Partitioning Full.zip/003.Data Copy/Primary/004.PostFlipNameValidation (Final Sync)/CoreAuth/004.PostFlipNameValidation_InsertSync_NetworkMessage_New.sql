USE [CoreAuth]
GO

--NetworkMessage
select 'NetworkMessage_Old' as [Table], count(UniqueID) as [RowCount] FROM NetworkMessage_Old WITH(NOLOCK) WHERE Posttime > '2022-03-31 23:59:57.000' 
UNION ALL
select 'NetworkMessage' as [Table], count(UniqueID) as [RowCount] from NetworkMessage  WITH(NOLOCK)
