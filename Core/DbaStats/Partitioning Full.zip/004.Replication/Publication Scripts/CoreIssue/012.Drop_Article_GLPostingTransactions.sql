-- GLPostingTransactions
use [CoreIssue]
exec sp_dropsubscription @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'GLPostingTransactions', @subscriber = N'all', @destination_db = 'CoreIssueRPT'
GO
use [CoreIssue]
exec sp_droparticle @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'GLPostingTransactions', @force_invalidate_snapshot = 1
GO
