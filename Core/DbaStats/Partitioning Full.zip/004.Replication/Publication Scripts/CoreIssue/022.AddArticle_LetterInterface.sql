use [CoreIssue]

EXEC sp_changepublication 
@publication = 'Trans_PUB_CoreissueReportPUB_Partition', -- publication name on which article need to be added
@property = 'allow_anonymous' , 
@value = 'false' 

EXEC sp_changepublication 
@publication = 'Trans_PUB_CoreissueReportPUB_Partition', -- publication name on which article need to be added
@property = 'immediate_sync' , 
@value = 'false'

use [CoreIssue]
exec sp_addarticle @publication = N'Trans_PUB_CoreissueReportPUB_Partition', @article = N'LetterInterface', @source_owner = N'dbo', @source_object = N'LetterInterface', @type = N'logbased', @description = N'', @creation_script = N'', @pre_creation_cmd = N'truncate', @schema_option = 0x0000000008035097, @identityrangemanagementoption = N'manual', @destination_table = N'LetterInterface', @destination_owner = N'dbo', @status = 24, @vertical_partition = N'false', @ins_cmd = N'CALL [dbo].[sp_MSins_dboletterinterface]', @del_cmd = N'CALL [dbo].[sp_MSdel_dboletterinterface]', @upd_cmd = N'SCALL [dbo].[sp_MSupd_dboletterinterface]'
GO

use [CoreIssue]
EXEC SP_REFRESHSUBSCRIPTIONS @publication = N'Trans_PUB_CoreissueReportPUB_Partition'