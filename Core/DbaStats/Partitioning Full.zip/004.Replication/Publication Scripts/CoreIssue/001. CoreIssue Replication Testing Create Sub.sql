-- Adding the transactional pull subscription

/****** Begin: Script to be run at Subscriber ******/
use [CoreIssueRPT24]
exec sp_addpullsubscription @publisher = N'MUMTE-DB01', @publication = N'Trans_PUB_PPGUat_CoreIssue24_PartitionReportPUB', @publisher_db = N'CoreIssue24', @independent_agent = N'True', @subscription_type = N'pull', @description = N'', @update_mode = N'read only', @immediate_sync = 1

exec sp_addpullsubscription_agent @publisher = N'MUMTE-DB01', @publisher_db = N'CoreIssue24', @publication = N'Trans_PUB_PPGUat_CoreIssue24_PartitionReportPUB', @distributor = N'PPGDISTAGL',@subscriber = N'MUMTE-RPTDB01', @distributor_security_mode = 1, @distributor_login = N'', @distributor_password = N'', @enabled_for_syncmgr = N'False', @frequency_type = 64, @frequency_interval = 0, @frequency_relative_interval = 0, @frequency_recurrence_factor = 0, @frequency_subday = 0, @frequency_subday_interval = 0, @active_start_time_of_day = 0, @active_end_time_of_day = 235959, @active_start_date = 0, @active_end_date = 0, @alt_snapshot_folder = N'', @working_directory = N'', @use_ftp = N'False', @job_login = null, @job_password = null, @publication_type = 0
GO


