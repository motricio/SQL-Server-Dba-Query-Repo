use [CoreIssue]
EXEC sp_changepublication 
@publication = 'Trans_PUB_CoreissueReportPUB_Partition', -- publication name on which article need to be added
@property = 'allow_anonymous' , 
@value = 'false' 

EXEC sp_changepublication 
@publication = 'Trans_PUB_CoreissueReportPUB_Partition', -- publication name on which article need to be added
@property = 'immediate_sync' , 
@value = 'false'


use [CoreIssue]
exec sp_addarticle @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @source_owner = N'dbo', @source_object = N'Auth_Primary', @type = N'logbased', @description = N'', @creation_script = N'', @pre_creation_cmd = N'truncate', @schema_option = 0x000000000803509F, @identityrangemanagementoption = N'manual', @destination_table = N'Auth_Primary', @destination_owner = N'dbo', @status = 24, @vertical_partition = N'true', @ins_cmd = N'CALL [sp_MSins_dboAuth_Primary]', @del_cmd = N'CALL [sp_MSdel_dboAuth_Primary]', @upd_cmd = N'SCALL [sp_MSupd_dboAuth_Primary]'

-- Adding the article's partition column(s)
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'UniqueID', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'GroupId', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'TranId', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'TranTime', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'PostTime', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'CMTTRANTYPE', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'TranRef', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'TxnAcctId', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'ATID', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'Reversed', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'RevTgt', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'StateStatus', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'StatementDate', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'priority', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'AccountNumber', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'CPMgroup', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'creditplanmaster', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'TxnCode_Internal', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'PostingFlag', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'PostingReason', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'PostingRef', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'BatchAcctId', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'RejectBatchAcctId', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'ARTxnType', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'TxnSource', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'PaymentCreditFlag', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'AuthStatus', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'PrimaryCurrencyCode', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'SecondaryCurrencyCode', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'TertiaryCurrencyCode', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'tranorig', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'PrimaryAccountNumber', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'ProcCode', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'ProcCodeFromAccType', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'ProcCodeToAccType', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'TransactionAmount', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'TransmissionDateTime', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'SystemTraceAuditNumber', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'TimeLocalTransaction', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'DateLocalTransaction', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'ExpirationDate', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'CaptureDate', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'MerchantType', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'CardDataEntryMode', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'AcquiringInsitutionIDCode', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'RetrievalReferenceNumber', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'AuthorizationResponseCode', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'ResponseCode', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'CardAcceptorTerminalID', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'CardAcceptorNameLocation', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'TransactionCurrencyCode', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'TxnSrcAmt', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'ApprovalCode', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'OriginalAmount_', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'ResponseMTI', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'RequestRC', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'ResponseTranType', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'NetworkName', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'FunctionCode', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'POSCountryCode', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'OriginalDEs', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'IResponseCode', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'CalcOTB', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'PurgeDate', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'AcquiringInstCountryCode', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'ForwardingInstCountryCode', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'AcqTranId', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'AuthDecisionControlLog', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'CustomerId', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'PAN_Hash', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'CardNumber4Digits', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'TransactionLifeCycleUniqueID', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'TxnCategory', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'CoreAuthTranId', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'MessageIndicator', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'OutstandingAmount', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'MessageTypeIdentifier', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'PINExist', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'EffectiveDate_ForAgeOff', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'POSTermOpEnv', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'PhysicalSource', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'InstitutionID', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'ProductID', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'ReconciliationIndicator', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'EffectiveDate', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'AuthMatchedFlag', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'PlusChekIndicator', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'AVReqOptCode', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'CardAcceptorIdCode', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'ReconciliationDate', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'MerchantNameandAddress', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'SKey', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'MatchAgedOffPreAuth', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'MulCountSeqNo', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'BalanceAdjustment', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'AuthInitiatingTime', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'AuthProcessedTime', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'FeeWaiveIndicator', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'TxnCode_InternalClr', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'CountryCode', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'CustomAcctID', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'CrossBorderTxnIndicator', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'AuthType', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'CurrentBalance', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'TotalOutStgAuthAmt', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'WalletAcctID', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'CashBackAmount', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'DrCrIndicator', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'CardVendorId', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'CardProductAID', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'ESource', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'usrId', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'MatchedAdvice', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'AuthDataDetail', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'SettlementServiceSelected', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'TxnLinkId', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'ActualSettlementAmt', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @column = N'ActualBillingAmt', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1

-- Adding 2 new Columns
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB_Partition', @article = N'Auth_Primary', @column = N'RowChangedDate', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreissueReportPUB_Partition', @article = N'Auth_Primary', @column = N'ChangeVersion', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1

-- Adding the article synchronization object
exec sp_articleview @publication = N'Trans_PUB_CoreissueReportPUB', @article = N'Auth_Primary', @view_name = N'syncobj_0x3435393134323231', @filter_clause = N'', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
GO
use [CoreIssue]
exec sp_addsubscription @publication = N'Trans_PUB_CoreissueReportPUB', @subscriber = N'PPGPRDRPTAGL', @destination_db = N'CoreissueRPT', @subscription_type = N'Pull', @sync_type = N'replication support only', @article = N'Auth_Primary', @update_mode = N'read only', @subscriber_type = 0
GO

use [CoreIssue]
EXEC SP_REFRESHSUBSCRIPTIONS @publication = N'Trans_PUB_CoreissueReportPUB_Partition'
GO
