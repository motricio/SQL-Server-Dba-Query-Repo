-- Enabling the replication database
use master

-- Adding the transactional publication
use [CoreAuth]
exec sp_addpublication @publication = N'Trans_PUB_CoreAuthReportPUB_Partition', @description = N'Transactional publication of database ''CoreAuth'' from Publisher ''''.', @sync_method = N'concurrent', @retention = 0, @allow_push = N'true', @allow_pull = N'true', @allow_anonymous = N'true', @enabled_for_internet = N'false', @snapshot_in_defaultfolder = N'true', @compress_snapshot = N'false', @ftp_port = 21, @ftp_login = N'anonymous', @allow_subscription_copy = N'false', @add_to_active_directory = N'false', @repl_freq = N'continuous', @status = N'active', @independent_agent = N'true', @immediate_sync = N'true', @allow_sync_tran = N'false', @autogen_sync_procs = N'false', @allow_queued_tran = N'false', @allow_dts = N'false', @replicate_ddl = 1, @allow_initialize_from_backup = N'false', @enabled_for_p2p = N'false', @enabled_for_het_sub = N'false'
GO


exec sp_addpublication_snapshot @publication = N'Trans_PUB_CoreAuthReportPUB_Partition', @frequency_type = 1, @frequency_interval = 1, @frequency_relative_interval = 1, @frequency_recurrence_factor = 0, @frequency_subday = 1, @frequency_subday_interval = 1, @active_start_time_of_day = 0, @active_end_time_of_day = 235959, @active_start_date = 0, @active_end_date = 0, @job_login = null, @job_password = null, @publisher_security_mode = 1

exec sp_grant_publication_access @publication = N'Trans_PUB_CoreAuthReportPUB_Partition', @login = N'PROCIND\ppglobalcfg'
GO
exec sp_grant_publication_access @publication = N'Trans_PUB_CoreAuthReportPUB_Partition', @login = N'PROCIND\AZWCSQL'
GO
exec sp_grant_publication_access @publication = N'Trans_PUB_CoreAuthReportPUB_Partition', @login = N'NT SERVICE\Winmgmt'
GO
exec sp_grant_publication_access @publication = N'Trans_PUB_CoreAuthReportPUB_Partition', @login = N'NT SERVICE\SQLWriter'
GO
exec sp_grant_publication_access @publication = N'Trans_PUB_CoreAuthReportPUB_Partition', @login = N'NT SERVICE\SQLSERVERAGENT'
GO
exec sp_grant_publication_access @publication = N'Trans_PUB_CoreAuthReportPUB_Partition', @login = N'NT Service\MSSQLSERVER'
GO
exec sp_grant_publication_access @publication = N'Trans_PUB_CoreAuthReportPUB_Partition', @login = N'DBALogin'
GO
exec sp_grant_publication_access @publication = N'Trans_PUB_CoreAuthReportPUB_Partition', @login = N'PROCIND\grpDBAProject'
GO
exec sp_grant_publication_access @publication = N'Trans_PUB_CoreAuthReportPUB_Partition', @login = N'PROCIND\svc_ppgccsql$'
-- Adding
GO
use [CoreAuth]
exec sp_addarticle @publication = N'Trans_PUB_CoreAuthReportPUB_Partition', @article = N'CoreAuthTransactions', @source_owner = N'dbo', @source_object = N'CoreAuthTransactions', @type = N'logbased', @description = N'', @creation_script = N'', @pre_creation_cmd = N'truncate', @schema_option = 0x0000000008035097, @identityrangemanagementoption = N'manual', @destination_table = N'CoreAuthTransactions', @destination_owner = N'dbo', @status = 24, @vertical_partition = N'false', @ins_cmd = N'CALL [dbo].[sp_MSins_dboCoreAuthTransactions]', @del_cmd = N'CALL [dbo].[sp_MSdel_dboCoreAuthTransactions]', @upd_cmd = N'SCALL [dbo].[sp_MSupd_dboCoreAuthTransactions]'
GO
use [CoreAuth]
exec sp_addarticle @publication = N'Trans_PUB_CoreAuthReportPUB_Partition', @article = N'CoreissueAuthMessage', @source_owner = N'dbo', @source_object = N'CoreissueAuthMessage', @type = N'logbased', @description = N'', @creation_script = N'', @pre_creation_cmd = N'truncate', @schema_option = 0x0000000008035097, @identityrangemanagementoption = N'manual', @destination_table = N'CoreissueAuthMessage', @destination_owner = N'dbo', @status = 24, @vertical_partition = N'true', @ins_cmd = N'CALL [sp_MSins_dboCoreissueAuthMessage]', @del_cmd = N'CALL [sp_MSdel_dboCoreissueAuthMessage]', @upd_cmd = N'SCALL [sp_MSupd_dboCoreissueAuthMessage]'

-- Adding the article's partition column(s)
exec sp_articlecolumn @publication = N'Trans_PUB_CoreAuthReportPUB_Partition', @article = N'CoreissueAuthMessage', @column = N'AuthType', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreAuthReportPUB_Partition', @article = N'CoreissueAuthMessage', @column = N'TranId', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreAuthReportPUB_Partition', @article = N'CoreissueAuthMessage', @column = N'NetworkSource', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreAuthReportPUB_Partition', @article = N'CoreissueAuthMessage', @column = N'MessageTypeIdentifierResponse', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreAuthReportPUB_Partition', @article = N'CoreissueAuthMessage', @column = N'MsgDummy', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreAuthReportPUB_Partition', @article = N'CoreissueAuthMessage', @column = N'AuthVarianceException', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreAuthReportPUB_Partition', @article = N'CoreissueAuthMessage', @column = N'TranType', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreAuthReportPUB_Partition', @article = N'CoreissueAuthMessage', @column = N'EffectiveDate_ForAgeOff', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreAuthReportPUB_Partition', @article = N'CoreissueAuthMessage', @column = N'IResponseCode', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreAuthReportPUB_Partition', @article = N'CoreissueAuthMessage', @column = N'TransactionLifeCycleUniqueID', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreAuthReportPUB_Partition', @article = N'CoreissueAuthMessage', @column = N'MsgIndicator', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreAuthReportPUB_Partition', @article = N'CoreissueAuthMessage', @column = N'PurgeDate', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreAuthReportPUB_Partition', @article = N'CoreissueAuthMessage', @column = N'MessageTypeIdentifier', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreAuthReportPUB_Partition', @article = N'CoreissueAuthMessage', @column = N'TranTypeClr', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreAuthReportPUB_Partition', @article = N'CoreissueAuthMessage', @column = N'TxnCategory', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreAuthReportPUB_Partition', @article = N'CoreissueAuthMessage', @column = N'TxnCode_Internal', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreAuthReportPUB_Partition', @article = N'CoreissueAuthMessage', @column = N'TxnCode_InternalClr', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreAuthReportPUB_Partition', @article = N'CoreissueAuthMessage', @column = N'Authstatus', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreAuthReportPUB_Partition', @article = N'CoreissueAuthMessage', @column = N'RevTgt', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreAuthReportPUB_Partition', @article = N'CoreissueAuthMessage', @column = N'calcOTB', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreAuthReportPUB_Partition', @article = N'CoreissueAuthMessage', @column = N'AuthDecisionControlLog', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreAuthReportPUB_Partition', @article = N'CoreissueAuthMessage', @column = N'PostingRef', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreAuthReportPUB_Partition', @article = N'CoreissueAuthMessage', @column = N'ResponseTranType', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreAuthReportPUB_Partition', @article = N'CoreissueAuthMessage', @column = N'OutstandingAmount', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreAuthReportPUB_Partition', @article = N'CoreissueAuthMessage', @column = N'JobStatus', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreAuthReportPUB_Partition', @article = N'CoreissueAuthMessage', @column = N'RequestApprovalCode', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreAuthReportPUB_Partition', @article = N'CoreissueAuthMessage', @column = N'PostTime', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreAuthReportPUB_Partition', @article = N'CoreissueAuthMessage', @column = N'TxnAcctId', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreAuthReportPUB_Partition', @article = N'CoreissueAuthMessage', @column = N'InvoiceNumber', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreAuthReportPUB_Partition', @article = N'CoreissueAuthMessage', @column = N'CurrentBalance', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreAuthReportPUB_Partition', @article = N'CoreissueAuthMessage', @column = N'TotalOutStgAuthAmt', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreAuthReportPUB_Partition', @article = N'CoreissueAuthMessage', @column = N'TransactionAmount', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreAuthReportPUB_Partition', @article = N'CoreissueAuthMessage', @column = N'ReversalAmount', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreAuthReportPUB_Partition', @article = N'CoreissueAuthMessage', @column = N'IdentityField', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreAuthReportPUB_Partition', @article = N'CoreissueAuthMessage', @column = N'BufferAddl', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreAuthReportPUB_Partition', @article = N'CoreissueAuthMessage', @column = N'WalletTransaction', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreAuthReportPUB_Partition', @article = N'CoreissueAuthMessage', @column = N'WalletAcctid', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreAuthReportPUB_Partition', @article = N'CoreissueAuthMessage', @column = N'FeeOperation', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreAuthReportPUB_Partition', @article = N'CoreissueAuthMessage', @column = N'BufferNew', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreAuthReportPUB_Partition', @article = N'CoreissueAuthMessage', @column = N'MachineName', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreAuthReportPUB_Partition', @article = N'CoreissueAuthMessage', @column = N'ExecutedADC', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreAuthReportPUB_Partition', @article = N'CoreissueAuthMessage', @column = N'RequestMsgBuffer', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreAuthReportPUB_Partition', @article = N'CoreissueAuthMessage', @column = N'ResponseMsgBuffer', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1

-- Adding 2 new Columns
exec sp_articlecolumn @publication = N'Trans_PUB_CoreAuthReportPUB_Partition', @article = N'CoreissueAuthMessage', @column = N'RowChangedDate', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articlecolumn @publication = N'Trans_PUB_CoreAuthReportPUB_Partition', @article = N'CoreissueAuthMessage', @column = N'ChangeVersion', @operation = N'add', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1

-- Adding the article synchronization object
exec sp_articleview @publication = N'Trans_PUB_CoreAuthReportPUB_Partition', @article = N'CoreissueAuthMessage', @view_name = N'syncobj_0x4141424345464544', @filter_clause = N'', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
GO
use [CoreAuth]
exec sp_addarticle @publication = N'Trans_PUB_CoreAuthReportPUB_Partition', @article = N'FraudAuthAccounts', @source_owner = N'dbo', @source_object = N'FraudAuthAccounts', @type = N'logbased', @description = N'', @creation_script = N'', @pre_creation_cmd = N'truncate', @schema_option = 0x0000000008035097, @identityrangemanagementoption = N'manual', @destination_table = N'FraudAuthAccounts', @destination_owner = N'dbo', @status = 24, @vertical_partition = N'false', @ins_cmd = N'CALL [sp_MSins_dboFraudAuthAccounts]', @del_cmd = N'CALL [sp_MSdel_dboFraudAuthAccounts]', @upd_cmd = N'SCALL [sp_MSupd_dboFraudAuthAccounts]', @filter_clause = N'[AuthTime] > DATEADD(MONTH, -3, GETDATE())'

-- Adding the article filter
exec sp_articlefilter @publication = N'Trans_PUB_CoreAuthReportPUB_Partition', @article = N'FraudAuthAccounts', @filter_name = N'FLTR_FraudAuthAccounts_1__65', @filter_clause = N'[AuthTime] > DATEADD(MONTH, -3, GETDATE())', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1

-- Adding the article synchronization object
exec sp_articleview @publication = N'Trans_PUB_CoreAuthReportPUB_Partition', @article = N'FraudAuthAccounts', @view_name = N'SYNC_FraudAuthAccounts_1__65', @filter_clause = N'[AuthTime] > DATEADD(MONTH, -3, GETDATE())', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
GO

-- Adding the transactional subscriptions
use [CoreAuth]
exec sp_addsubscription @publication = N'Trans_PUB_CoreAuthReportPUB_Partition', @subscriber = N'PPGPDRPTAGL', @destination_db = N'CoreAuthRPT', @subscription_type = N'Pull', @sync_type = N'Replication Support Only', @article = N'all', @update_mode = N'read only', @subscriber_type = 0
GO

