-- Dropping the transactional articles
use [CoreAuth]
exec sp_dropsubscription @publication = N'Trans_PUB_CoreAuthReportPUB', @article = N'CoreAuthTransactions', @subscriber = N'all', @destination_db = 'CoreAuthRPT'
GO
use [CoreAuth]
exec sp_droparticle @publication = N'Trans_PUB_CoreAuthReportPUB', @article = N'CoreAuthTransactions', @force_invalidate_snapshot = 1
GO
use [CoreAuth]
exec sp_dropsubscription @publication = N'Trans_PUB_CoreAuthReportPUB', @article = N'CoreissueAuthMessage', @subscriber = N'all', @destination_db = 'CoreAuthRPT'
GO
use [CoreAuth]
exec sp_droparticle @publication = N'Trans_PUB_CoreAuthReportPUB', @article = N'CoreissueAuthMessage', @force_invalidate_snapshot = 1
GO
use [CoreAuth]
exec sp_dropsubscription @publication = N'Trans_PUB_CoreAuthReportPUB', @article = N'FraudAuthAccounts', @subscriber = N'all', @destination_db = 'CoreAuthRPT'
GO
use [CoreAuth]
exec sp_droparticle @publication = N'Trans_PUB_CoreAuthReportPUB', @article = N'FraudAuthAccounts', @force_invalidate_snapshot = 1
GO